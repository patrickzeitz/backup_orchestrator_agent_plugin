##### START #####

#cat > /app/config/orchestrator.py <<'PY'


#!/usr/bin/env python3
import json
import logging
import os
import time
import hmac
import hashlib
from typing import Dict, Any, Tuple, List, Optional
from urllib.parse import urlparse, parse_qsl, urlencode, urlunparse

import requests
import yaml
from dotenv import dotenv_values

DATA_ROOT = os.environ.get("DATA_ROOT", "/data")
SITES_YML = os.environ.get("SITES_YML", "/app/config/sites.yml")
SECRETS_ENV = os.environ.get("SECRETS_ENV", "/app/config/secrets.env")
LOG_FILE = os.environ.get("LOG_FILE", "/app/logs/orchestrator.log")
DEFAULT_TIMEOUT = int(os.environ.get("HTTP_TIMEOUT_SECONDS", "30"))
DEFAULT_INTERVAL = int(os.environ.get("POLL_INTERVAL_SECONDS", "300"))
CHUNK_LENGTH = 5 * 1024 * 1024
MAX_ATTEMPTS = 3


def setup_logging() -> logging.Logger:
    logger = logging.getLogger("wp_orchestrator")
    logger.setLevel(logging.INFO)
    fmt = logging.Formatter("%(asctime)s [%(levelname)s] %(message)s")
    if not logger.handlers:
        sh = logging.StreamHandler()
        sh.setFormatter(fmt)
        logger.addHandler(sh)
        fh = logging.FileHandler(LOG_FILE)
        fh.setFormatter(fmt)
        logger.addHandler(fh)
    return logger


def load_sites(path: str) -> Dict[str, Any]:
    with open(path, "r", encoding="utf-8") as f:
        data = yaml.safe_load(f) or {}
    if "sites" not in data or not isinstance(data["sites"], list):
        raise ValueError("sites.yml invalid: expected top-level key 'sites' with a list")
    return data


def normalize_site_env_key(site_id: str) -> str:
    return site_id.upper().replace("-", "_").replace(".", "_")


def load_secrets(env_path: str) -> Dict[str, str]:
    return {k: v for k, v in (dotenv_values(env_path) or {}).items() if v is not None}


def sha256_hex(raw: bytes) -> str:
    return hashlib.sha256(raw).hexdigest()


def canonical_query(parsed) -> str:
    pairs = parse_qsl(parsed.query, keep_blank_values=True)
    pairs.sort(key=lambda kv: (kv[0], kv[1]))
    return urlencode(pairs, doseq=True)


def build_canonical_string(method: str, path: str, query: str, ts: int, body_hash: str) -> str:
    return f"v1\n{method.upper()}\n{path}\n{query}\n{ts}\n{body_hash}"


def sign_request(method: str, url: str, body: bytes, secret: str) -> Tuple[str, int, str]:
    parsed = urlparse(url)
    path = parsed.path or "/"
    query = canonical_query(parsed)
    ts = int(time.time())
    body_hash = sha256_hex(body if body else b"")
    canonical = build_canonical_string(method, path, query, ts, body_hash)
    sig = hmac.new(secret.encode("utf-8"), canonical.encode("utf-8"), hashlib.sha256).hexdigest()
    return sig, ts, body_hash


def build_url_with_params(url: str, params: Optional[Dict[str, Any]]) -> str:
    if not params:
        return url
    parsed = urlparse(url)
    query_pairs = parse_qsl(parsed.query, keep_blank_values=True)
    for k, v in params.items():
        query_pairs.append((k, v))
    query_pairs.sort(key=lambda kv: (kv[0], str(kv[1])))
    query = urlencode(query_pairs, doseq=True)
    return urlunparse((parsed.scheme, parsed.netloc, parsed.path, parsed.params, query, parsed.fragment))


def build_headers(method: str, url: str, body: bytes, token: str, secret: str) -> Dict[str, str]:
    headers = {
        "Accept": "application/json",
        "User-Agent": "wp-pull-orchestrator/0.2",
    }
    if token:
        headers["Authorization"] = f"Bearer {token}"
    if secret:
        sig, ts, body_hash = sign_request(method, url, body, secret)
        headers["X-AB-Timestamp"] = str(ts)
        headers["X-AB-Content-SHA256"] = body_hash
        headers["X-AB-Signature"] = f"v1={sig}"
    return headers


def request_with_retry(session: requests.Session, method: str, url: str, headers: Dict[str, str], site_id: str, logger: logging.Logger, stream: bool = False) -> requests.Response:
    for attempt in range(1, MAX_ATTEMPTS + 1):
        try:
            resp = session.request(method, url, headers=headers, timeout=DEFAULT_TIMEOUT, stream=stream)
            if resp.status_code in (429,) or resp.status_code >= 500:
                if attempt == MAX_ATTEMPTS:
                    return resp
                wait = min(30, 2 ** attempt)
                logger.warning("[%s] %s %s -> %s (retrying in %ss)", site_id, method, url, resp.status_code, wait)
                time.sleep(wait)
                continue
            return resp
        except requests.RequestException as exc:
            if attempt == MAX_ATTEMPTS:
                raise
            wait = min(30, 2 ** attempt)
            logger.warning("[%s] %s %s error '%s' (retrying in %ss)", site_id, method, url, exc, wait)
            time.sleep(wait)
    raise RuntimeError("unreachable")


def read_json(path: str, default: Any) -> Any:
    if not os.path.exists(path):
        return default
    try:
        with open(path, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return default


def write_json(path: str, payload: Any) -> None:
    os.makedirs(os.path.dirname(path), exist_ok=True)
    tmp = f"{path}.tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(payload, f, ensure_ascii=False, indent=2)
    os.replace(tmp, path)


def safe_join(base: str, relative: str) -> str:
    target = os.path.realpath(os.path.join(base, relative))
    base_real = os.path.realpath(base)
    if not target.startswith(base_real):
        raise ValueError("unsafe path")
    return target


def ensure_dirs(site_id: str) -> Dict[str, str]:
    base = os.path.join(DATA_ROOT, site_id)
    paths = {
        "base": base,
        "files": os.path.join(base, "files"),
        "db": os.path.join(base, "db"),
        "meta": os.path.join(base, "meta"),
    }
    for p in paths.values():
        os.makedirs(p, exist_ok=True)
    return paths


def request_json(session: requests.Session, method: str, url: str, token: str, secret: str, site_id: str, logger: logging.Logger) -> Dict[str, Any]:
    headers = build_headers(method, url, b"", token, secret)
    resp = request_with_retry(session, method, url, headers, site_id, logger)
    ct = (resp.headers.get("Content-Type") or "").lower()
    if "application/json" not in ct:
        raise ValueError(f"Expected JSON, got {resp.status_code} {ct}")
    data = resp.json()
    if not (200 <= resp.status_code < 300):
        raise ValueError(f"HTTP {resp.status_code}: {data}")
    return data


def check_status(session: requests.Session, site: Dict[str, Any], token: str, secret: str, logger: logging.Logger) -> None:
    status_endpoint = site["endpoints"].get("status")
    if not status_endpoint:
        raise ValueError("status endpoint missing")
    url = site["base_url"].rstrip("/") + status_endpoint
    payload = request_json(session, "GET", url, token, secret, site["id"], logger)
    logger.info("[%s] STATUS OK -> %s", site["id"], json.dumps(payload, ensure_ascii=False))


def fetch_files_index(session: requests.Session, site: Dict[str, Any], token: str, secret: str, site_paths: Dict[str, str], logger: logging.Logger) -> Dict[str, Any]:
    files_endpoint = site["endpoints"].get("files")
    if not files_endpoint:
        raise ValueError("files endpoint missing")
    base_url = site["base_url"].rstrip("/") + files_endpoint
    cursor = 0
    files: List[Dict[str, Any]] = []
    total_seen = 0
    while True:
        full_url = build_url_with_params(base_url, {"cursor": cursor})
        page = request_json(session, "GET", full_url, token, secret, site["id"], logger)
        page_files = page.get("files") or []
        files.extend(page_files)
        total_seen = page.get("count", total_seen + len(page_files))
        cursor = page.get("next_cursor")
        if cursor is None:
            break
    index_payload = {
        "generated_at": time.time(),
        "files": files,
        "count": total_seen or len(files),
    }
    write_json(os.path.join(site_paths["meta"], "index_latest.json"), index_payload)
    return index_payload


def compute_delta(prev_index: Dict[str, Any], new_index: Dict[str, Any]) -> Tuple[List[Dict[str, Any]], List[str]]:
    prev_map = {(f.get("path") or "").lstrip("/"): (int(f.get("size", 0)), int(f.get("mtime", 0))) for f in prev_index.get("files", [])}
    new_map = {(f.get("path") or "").lstrip("/"): (int(f.get("size", 0)), int(f.get("mtime", 0))) for f in new_index.get("files", [])}

    changed: List[Dict[str, Any]] = []
    for path, meta in new_map.items():
        if path not in prev_map or prev_map[path] != meta:
            changed.append({"path": path, "size": meta[0], "mtime": meta[1]})

    removed = [path for path in prev_map.keys() if path not in new_map]
    return changed, removed


def download_file(session: requests.Session, site: Dict[str, Any], token: str, secret: str, site_paths: Dict[str, str], file_meta: Dict[str, Any], logger: logging.Logger) -> int:
    file_endpoint = site["endpoints"].get("file")
    if not file_endpoint:
        raise ValueError("file endpoint missing")

    rel_path = (file_meta.get("path") or "").lstrip("/")
    remote_size = int(file_meta.get("size", 0))
    target_path = safe_join(site_paths["files"], rel_path)
    os.makedirs(os.path.dirname(target_path), exist_ok=True)

    existing_size = os.path.getsize(target_path) if os.path.exists(target_path) else 0
    offset = existing_size if existing_size < remote_size else 0
    if offset == 0 and existing_size:
        with open(target_path, "wb"):
            pass

    bytes_downloaded = 0
    base_url = site["base_url"].rstrip("/") + file_endpoint

    while offset < remote_size:
        length = min(CHUNK_LENGTH, remote_size - offset)
        full_url = build_url_with_params(base_url, {"path": rel_path, "offset": offset, "length": length})
        headers = build_headers("GET", full_url, b"", token, secret)
        resp = request_with_retry(session, "GET", full_url, headers, site["id"], logger, stream=True)
        if not (200 <= resp.status_code < 300):
            raise ValueError(f"/file HTTP {resp.status_code}")

        mode = "r+b" if os.path.exists(target_path) else "wb"
        with open(target_path, mode) as fh:
            fh.seek(offset)
            for chunk in resp.iter_content(chunk_size=8192):
                if not chunk:
                    continue
                fh.write(chunk)
                bytes_downloaded += len(chunk)
        offset += length

    if remote_size == 0:
        with open(target_path, "wb"):
            pass

    return bytes_downloaded


def delete_removed_files(site_paths: Dict[str, str], removed: List[str], logger: logging.Logger, site_id: str) -> int:
    deleted = 0
    for rel_path in removed:
        try:
            local_path = safe_join(site_paths["files"], rel_path)
        except ValueError:
            logger.warning("[%s] Skipping unsafe delete for %s", site_id, rel_path)
            continue
        if os.path.exists(local_path) and os.path.isfile(local_path):
            os.remove(local_path)
            deleted += 1
    return deleted


def fetch_db(session: requests.Session, site: Dict[str, Any], token: str, secret: str, site_paths: Dict[str, str], logger: logging.Logger) -> str:
    db_endpoint = site["endpoints"].get("db")
    if not db_endpoint:
        raise ValueError("db endpoint missing")
    filename = f"db_{time.strftime('%Y-%m-%d_%H%M')}.sql.gz"
    target = os.path.join(site_paths["db"], filename)
    # Request plain SQL (gzip=0) to avoid bad gzip streams if server cannot gzip; we compress locally.
    url = build_url_with_params(site["base_url"].rstrip("/") + db_endpoint, {"gzip": 0})
    headers = build_headers("GET", url, b"", token, secret)
    resp = request_with_retry(session, "GET", url, headers, site["id"], logger, stream=True)
    if not (200 <= resp.status_code < 300):
        raise ValueError(f"/db HTTP {resp.status_code}")
    with open(target, "wb") as fh:
        for chunk in resp.iter_content(chunk_size=8192):
            if chunk:
                fh.write(chunk)
    # gzip locally
    import gzip
    gz_target = target + ".tmp.gz"
    with open(target, "rb") as src, gzip.open(gz_target, "wb") as dst:
        while True:
            data = src.read(8192)
            if not data:
                break
            dst.write(data)
    os.replace(gz_target, target)
    return target


def process_site(session: requests.Session, site: Dict[str, Any], secrets: Dict[str, str], logger: logging.Logger) -> None:
    site_id = site["id"]
    env_key = normalize_site_env_key(site_id)
    token = (secrets.get(f"SITE_{env_key}_TOKEN") or "").strip().strip('"')
    secret = (secrets.get(f"SITE_{env_key}_SECRET") or "").strip().strip('"')

    site_paths = ensure_dirs(site_id)
    last_run_path = os.path.join(site_paths["meta"], "last_run.json")
    prev_index_path = os.path.join(site_paths["meta"], "index_latest.json")
    prev_index = read_json(prev_index_path, {})
    last_run_prev = read_json(last_run_path, {})

    start_ts = time.time()
    db_last_ts = int(last_run_prev.get("db_last_ts", 0))
    counts = {
        "total_files_remote": 0,
        "changed_files": 0,
        "downloaded_files": 0,
        "deleted_files": 0,
    }
    bytes_downloaded = 0
    db_dump_written = False
    db_dump_path = ""
    last_error = None

    try:
        check_status(session, site, token, secret, logger)
        new_index = fetch_files_index(session, site, token, secret, site_paths, logger)
        counts["total_files_remote"] = len(new_index.get("files", []))
        changed, removed = compute_delta(prev_index, new_index)
        counts["changed_files"] = len(changed)

        for file_meta in changed:
            bytes_downloaded += download_file(session, site, token, secret, site_paths, file_meta, logger)
            counts["downloaded_files"] += 1

        backup_cfg = site.get("backup", {}) or {}
        if backup_cfg.get("delete_removed_files"):
            counts["deleted_files"] = delete_removed_files(site_paths, removed, logger, site_id)

        interval_min = int(backup_cfg.get("db_every_minutes", 1440))
        if time.time() - db_last_ts >= interval_min * 60:
            db_dump_path = fetch_db(session, site, token, secret, site_paths, logger)
            db_dump_written = True
            db_last_ts = int(time.time())
        else:
            db_dump_written = False

    except Exception as exc:
        last_error = str(exc)
        logger.error("[%s] run failed: %s", site_id, exc)

    end_ts = time.time()
    last_run = {
        "start_ts": start_ts,
        "end_ts": end_ts,
        "duration_seconds": round(end_ts - start_ts, 3),
        "counts": counts,
        "bytes_downloaded": bytes_downloaded,
        "db_dump_written": db_dump_written,
        "db_dump_path": db_dump_path,
        "db_last_ts": int(db_last_ts),
        "last_error": last_error,
    }
    write_json(last_run_path, last_run)

    if last_error:
        raise RuntimeError(last_error)
    logger.info(
        "[%s] files_remote=%s changed=%s downloaded=%s deleted=%s bytes=%s db_written=%s",
        site_id,
        counts["total_files_remote"],
        counts["changed_files"],
        counts["downloaded_files"],
        counts["deleted_files"],
        bytes_downloaded,
        db_dump_written,
    )


def run_once(logger: logging.Logger) -> int:
    sites_data = load_sites(SITES_YML)
    secrets = load_secrets(SECRETS_ENV)
    ok = 0
    total = 0
    session = requests.Session()

    for site in sites_data["sites"]:
        if not site or not isinstance(site, dict):
            continue
        if not site.get("enabled", True):
            continue
        total += 1
        site_id = site.get("id")
        if not site_id or not site.get("base_url"):
            logger.error("Skipping site without id/base_url: %s", site)
            continue
        try:
            process_site(session, site, secrets, logger)
            ok += 1
        except Exception as exc:
            logger.error("[%s] run error: %s", site_id, exc)

    logger.info("Run summary: %d/%d sites OK", ok, total)
    return 0 if ok == total else 2


def main():
    logger = setup_logging()
    import argparse

    p = argparse.ArgumentParser()
    p.add_argument("--once", action="store_true")
    p.add_argument("--interval", type=int, default=DEFAULT_INTERVAL)
    args = p.parse_args()

    if args.once:
        raise SystemExit(run_once(logger))

    logger.info("Starting loop interval=%ss", args.interval)
    while True:
        run_once(logger)
        time.sleep(max(5, args.interval))


if __name__ == "__main__":
    main()



#### END #####


#PY

#chmod +x /app/config/orchestrator.py
