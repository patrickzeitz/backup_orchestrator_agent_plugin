# WordPress Backup Connector + Orchestrator

## Projektübersicht

Ziel dieses Projekts ist der Aufbau eines **stabilen, agentur-tauglichen Backup-Systems** für WordPress-Websites ohne SSH-Zugriff.  
Das System besteht aus zwei Komponenten:

1) **WordPress Connector (Agent Plugin)**  
   Liefert REST-API-Routen, die ein zentraler Orchestrator nutzt.

2) **Orchestrator (Python)**  
   Läuft als Container auf **TrueNAS SCALE**, holt Daten über die REST API, speichert Backups und nutzt ZFS-Snapshots.

---

## Architektur

```
WordPress Sites
↓ (REST API: /wp-json/agent-backup/v1/)
TrueNAS SCALE Container: Orchestrator
↓
ZFS Dataset: wp-backups
Snapshots (stündlich/täglich/monatlich)
```

---

## Systemkomponenten

### 1) WordPress Connector (Agent Plugin)

#### Aufgaben

- Endpoints:
  - `GET /status`
  - `GET /files`
  - `GET /file`
  - `GET /db`
  - `POST /rescan`

- Authentifizierung:
  1) IP-Allowlist
  2) Bearer Token
  3) HMAC (SHA256) + Timestamp + Body Hash

- Sicherheit:
  - keine Write-Operationen
  - Pfad-Traversal Schutz
  - keine Secrets im Log

---

## API Specification (REST Endpoints)

**Namespace:** `/wp-json/agent-backup/v1`

### GET /status

**Antwort (200):**
```json
{
  "ok": true,
  "ts": 1700000000,
  "site": "https://example.com",
  "agent_version": "0.1.0"
}
```

### GET /files

**Query-Parameter:**
- `cursor` (optional)
- `limit` (optional, default 5000)
- `root` (optional, default wp-content)

**Antwort:**
```json
{
  "generated_at": "2026-01-02T16:00:00Z",
  "root": "wp-content",
  "files": [
    {
      "path": "uploads/2026/01/a.jpg",
      "size": 12345,
      "mtime": 1700000000
    }
  ],
  "next_cursor": "5000"
}
```

### GET /file

**Query-Parameter:**
- `path`
- `offset`
- `length`

**Antwort:**
- HTTP 206 Partial Content
- Bytes des Dateiinhalts

### GET /db

**Query-Parameter:**
- `gzip=1` (standard)

**Antwort:**
- SQL-Dump (.sql.gz) ohne RAM-Last

### POST /rescan

**Antwort:**
```json
{
  "ok": true
}
```

---

## Authentifizierungs-Workflow

### Headers

```
Authorization: Bearer <token>
X-AB-Timestamp: <unix>
X-AB-Content-SHA256: <hex>
X-AB-Signature: v1=<hex>
```

### Canonischer String

```
v1
<METHOD>
<PATH>
<QUERY(sorted RFC3986)>
<TIMESTAMP>
<BODY_HASH>
```

---

## 2) Orchestrator (Python)

### Konfiguration

Dateien in `/app/config`:
- `sites.yml` – Sites Liste
- `secrets.env` – Tokens + Secrets

### Verzeichnislayout (TrueNAS)

```
/mnt/backup-pool/wp-backups/
  patrick-zeitz-de/
    files/
    db/
    meta/
    logs/

/mnt/backup-pool/wp-orchestrator/
  config/
  logs/
```

### Snapshots

- stündlich (24h)
- täglich (14 Tage)
- monatlich (6 Monate)

---

## Orchestrator Workflow

1. `/status` prüfen
2. `/files` paginiert abrufen
3. Delta berechnen (mtime + size)
4. `/file` lesen (Chunk)
5. `/db` download (gzip)
6. Speichern unter:
   - `/data/<site-id>/files/…`
   - `/data/<site-id>/db/db_TIMESTAMP.sql.gz`
7. Loggen:
   - Erfolge
   - Fehler
   - Laufzeiten
   - Counts

---

## Sicherheitsregeln (Must-Haves)

- IP-Allowlist
- Bearer Token
- HMAC + Timestamp ±300s
- Pfad-Traversal Schutz (.., Null bytes)
- Log keine Secrets

---

## Milestones

### M1 – Connector Plugin v0.2
- Auth Middleware
- `/status`
- `/files`
- `/file`
- `/db`
- `/rescan`

### M2 – Orchestrator v0.2
- `/files` Index Processing
- Chunked Downloads
- Delta Logic
- DB Dumps

### M3 – Operations
- Snapshot Policy
- Monitoring / Logs

---

## Dev Setup (VSCode + Codex/IDE)

### Projektstruktur

```
wp-agent-plugin/
  agent-backup.php
  includes/
    auth.php
    routes.php
    utils.php

orchestrator/
  orchestrator.py
  signing.py
  fetch_files.py
  fetch_db.py
  delta.py
  storage.py
```

### Requirements

**WP Plugin:**
- PHP 7.4+
- WP REST API

**Python:**
- `requests`
- `pyyaml`
- `python-dotenv`

---

## Testing & Debugging

### Curl Beispiele

**Status:**
```bash
curl -H "Authorization: Bearer <token>" \
     -H "X-AB-Timestamp: <ts>" \
     -H "X-AB-Content-SHA256: <hash>" \
     -H "X-AB-Signature: v1=<sig>" \
  https://example.com/wp-json/agent-backup/v1/status
```

**Files:**
```bash
curl … https://…/wp-json/agent-backup/v1/files?limit=5000
```

---

## VSCode/Codex Prompt

```
You are a senior engineer implementing a WordPress backup connector plugin 
and a Python pull-orchestrator.

Goal: initial full backup of wp-content + DB, then incremental (mtime + size). 
No SSH required. Secure with IP allowlist, per-site bearer token, and 
HMAC+timestamp+body-sha256 signing.

Requirements:
- Plugin: PHP 7.4+, WP REST API, no write operations
- Orchestrator: Python 3, TrueNAS SCALE container
- Auth: IP-Allowlist, Bearer Token, HMAC-SHA256 signing with timestamp validation (±300s)
- Security: Prevent path traversal, no secrets in logs
- API: Paginated /files, chunked /file download, /db as gzip without RAM stress
- Storage: Delta detection via mtime + size, ZFS snapshots (hourly/daily/monthly)
- Logging: Track success, errors, runtime, file/DB counts

Use WordPress Coding Standards for PHP.
Use snake_case for Python functions, follow PEP 8.
Assume TrueNAS SCALE container runtime with /app and /data mount points.
Update after every change the version number from the plugin.
```

---

## Deployment

### TrueNAS SCALE

- **App:** Orchestrator (Python Script)
- **Dataset:** wp-backups
- **Dataset:** wp-orchestrator
- **Paths:**
  - `/data` → Backups
  - `/app/config` → Config
  - `/app/logs` → Logs
