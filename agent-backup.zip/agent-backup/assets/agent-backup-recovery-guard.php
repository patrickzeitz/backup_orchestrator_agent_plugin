<?php
/**
 * Agent Backup recovery guard.
 *
 * This file is copied verbatim to wp-content/mu-plugins. It is intentionally
 * standalone so it loads before every regular plugin, including Agent Backup.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'AGENT_BACKUP_RECOVERY_GUARD_VERSION', '1.2.0' );
define( 'AGENT_BACKUP_RECOVERY_GUARD_SCHEMA', 1 );
define( 'AGENT_BACKUP_RECOVERY_GUARD_CAPABILITY_VERSION', 1 );
define( 'AGENT_BACKUP_RECOVERY_GUARD_MAX_STATE_BYTES', 16384 );

function agent_backup_recovery_guard_state_directory() {
	return trailingslashit( WP_CONTENT_DIR ) . '.agent-backup-recovery';
}

function agent_backup_recovery_guard_state_path( $kind ) {
	if ( 'armed' === $kind ) {
		return trailingslashit( agent_backup_recovery_guard_state_directory() ) . 'armed.json';
	}
	if ( 'quarantine' === $kind ) {
		return trailingslashit( agent_backup_recovery_guard_state_directory() ) . 'quarantine.json';
	}
	return '';
}

function agent_backup_recovery_guard_hmac_secret() {
	$settings = get_option( 'agent_backup_settings', array() );
	if ( ! is_array( $settings ) || ! isset( $settings['secret'] ) ) {
		return '';
	}
	return trim( (string) $settings['secret'] );
}

function agent_backup_recovery_guard_state_message( $state ) {
	$canonical = (array) $state;
	unset( $canonical['hmac'] );
	ksort( $canonical, SORT_STRING );
	$encoded = json_encode( $canonical, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE );
	return is_string( $encoded ) ? $encoded : '';
}

function agent_backup_recovery_guard_plugin_is_safe( $plugin ) {
	$plugin = (string) $plugin;
	if ( '' === $plugin || $plugin !== trim( $plugin ) || false !== strpos( $plugin, "\0" ) ) {
		return false;
	}
	if ( false !== strpos( $plugin, '\\' ) || '/' === substr( $plugin, 0, 1 ) ) {
		return false;
	}
	if ( function_exists( 'validate_file' ) && 0 !== validate_file( $plugin ) ) {
		return false;
	}
	return '.php' === strtolower( substr( $plugin, -4 ) ) && ! preg_match( '/[\x00-\x1F\x7F]/', $plugin );
}

function agent_backup_recovery_guard_transaction_is_safe( $transaction_id ) {
	return 1 === preg_match( '/^[A-Za-z0-9][A-Za-z0-9._:-]{15,127}$/', (string) $transaction_id );
}

function agent_backup_recovery_guard_version_is_safe( $version ) {
	$version = (string) $version;
	return '' !== $version
		&& $version === trim( $version )
		&& strlen( $version ) <= 64
		&& ! preg_match( '/[\x00-\x1F\x7F]/', $version );
}

function agent_backup_recovery_guard_verify_state( $state, $kind, $secret ) {
	if ( ! is_array( $state ) || '' === $secret ) {
		return false;
	}
	if ( AGENT_BACKUP_RECOVERY_GUARD_SCHEMA !== (int) ( $state['schema'] ?? 0 ) || $kind !== (string) ( $state['kind'] ?? '' ) ) {
		return false;
	}
	$provided = strtolower( (string) ( $state['hmac'] ?? '' ) );
	if ( ! preg_match( '/^[a-f0-9]{64}$/', $provided ) ) {
		return false;
	}
	$message = agent_backup_recovery_guard_state_message( $state );
	if ( '' === $message || ! hash_equals( hash_hmac( 'sha256', $message, $secret ), $provided ) ) {
		return false;
	}
	if (
		! agent_backup_recovery_guard_plugin_is_safe( (string) ( $state['plugin'] ?? '' ) )
		|| ! agent_backup_recovery_guard_transaction_is_safe( (string) ( $state['transaction_id'] ?? '' ) )
		|| AGENT_BACKUP_RECOVERY_GUARD_CAPABILITY_VERSION !== (int) ( $state['capability_version'] ?? 0 )
		|| ! agent_backup_recovery_guard_version_is_safe( (string) ( $state['expected_from_version'] ?? '' ) )
		|| ! agent_backup_recovery_guard_version_is_safe( (string) ( $state['expected_target_version'] ?? '' ) )
	) {
		return false;
	}
	$issued_at = (int) ( $state['issued_at'] ?? 0 );
	if ( $issued_at <= 0 ) {
		return false;
	}
	if ( 'armed' === $kind ) {
		return (int) ( $state['expires_at'] ?? 0 ) >= $issued_at;
	}
	if ( 'quarantine' === $kind ) {
		return (int) ( $state['quarantined_at'] ?? 0 ) >= $issued_at;
	}
	return false;
}

function agent_backup_recovery_guard_read_state( $kind, $secret ) {
	$path = agent_backup_recovery_guard_state_path( $kind );
	if ( '' === $path || ! is_file( $path ) ) {
		return null;
	}
	$size = @filesize( $path );
	if ( false === $size || $size <= 0 || $size > AGENT_BACKUP_RECOVERY_GUARD_MAX_STATE_BYTES ) {
		return null;
	}
	$raw = @file_get_contents( $path );
	if ( ! is_string( $raw ) || '' === $raw ) {
		return null;
	}
	$state = json_decode( $raw, true );
	return agent_backup_recovery_guard_verify_state( $state, $kind, $secret ) ? $state : null;
}

function agent_backup_recovery_guard_sign_state( $state, $secret ) {
	$message = agent_backup_recovery_guard_state_message( $state );
	if ( '' === $message || '' === $secret ) {
		return array();
	}
	$state['hmac'] = hash_hmac( 'sha256', $message, $secret );
	return $state;
}

function agent_backup_recovery_guard_atomic_quarantine_write( $state, $secret ) {
	$path   = agent_backup_recovery_guard_state_path( 'quarantine' );
	$signed = agent_backup_recovery_guard_sign_state( $state, $secret );
	if ( '' === $path || empty( $signed ) || ! is_dir( agent_backup_recovery_guard_state_directory() ) ) {
		return false;
	}
	$encoded = json_encode( $signed, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE );
	if ( ! is_string( $encoded ) || strlen( $encoded ) > AGENT_BACKUP_RECOVERY_GUARD_MAX_STATE_BYTES ) {
		return false;
	}
	try {
		$suffix = bin2hex( random_bytes( 8 ) );
	} catch ( Throwable $error ) {
		$suffix = str_replace( '.', '', uniqid( '', true ) );
	}
	$temp_path = $path . '.' . $suffix . '.tmp';
	$written   = @file_put_contents( $temp_path, $encoded, LOCK_EX );
	if ( ! is_int( $written ) || $written !== strlen( $encoded ) ) {
		if ( is_file( $temp_path ) ) {
			@unlink( $temp_path );
		}
		return false;
	}
	@chmod( $temp_path, 0600 );
	if ( ! @rename( $temp_path, $path ) ) {
		@unlink( $temp_path );
		return false;
	}
	return true;
}

function agent_backup_recovery_guard_normalize_path( $path ) {
	$normalized = str_replace( '\\', '/', (string) $path );
	if ( '\\' === DIRECTORY_SEPARATOR ) {
		$normalized = strtolower( $normalized );
	}
	return rtrim( $normalized, '/' );
}

/**
 * Confirm that the fatal source file belongs to the exact pre-authorized plugin.
 */
function agent_backup_recovery_guard_fatal_belongs_to_plugin( $plugin, $error_file ) {
	if ( ! agent_backup_recovery_guard_plugin_is_safe( $plugin ) || '' === (string) $error_file ) {
		return false;
	}
	$plugin_directory = dirname( $plugin );
	if ( '.' === $plugin_directory ) {
		$target = trailingslashit( WP_PLUGIN_DIR ) . $plugin;
		$target = realpath( $target ) ?: $target;
		$error  = realpath( $error_file ) ?: $error_file;
		return hash_equals(
			agent_backup_recovery_guard_normalize_path( $target ),
			agent_backup_recovery_guard_normalize_path( $error )
		);
	}

	$target_root = trailingslashit( WP_PLUGIN_DIR ) . $plugin_directory;
	$target_root = realpath( $target_root ) ?: $target_root;
	$error_file  = realpath( $error_file ) ?: $error_file;
	$target_root = agent_backup_recovery_guard_normalize_path( $target_root );
	$error_file  = agent_backup_recovery_guard_normalize_path( $error_file );
	return $error_file === $target_root || 0 === strpos( $error_file, $target_root . '/' );
}

$agent_backup_recovery_guard_secret     = agent_backup_recovery_guard_hmac_secret();
$agent_backup_recovery_guard_quarantine = agent_backup_recovery_guard_read_state( 'quarantine', $agent_backup_recovery_guard_secret );

if ( is_array( $agent_backup_recovery_guard_quarantine ) ) {
	$agent_backup_recovery_guard_plugin = (string) $agent_backup_recovery_guard_quarantine['plugin'];
	add_filter(
		'option_active_plugins',
		static function ( $plugins ) use ( $agent_backup_recovery_guard_plugin ) {
			if ( ! is_array( $plugins ) ) {
				return $plugins;
			}
			return array_values(
				array_filter(
					$plugins,
					static function ( $plugin ) use ( $agent_backup_recovery_guard_plugin ) {
						return ! is_string( $plugin ) || ! hash_equals( $agent_backup_recovery_guard_plugin, $plugin );
					}
				)
			);
		},
		PHP_INT_MAX,
		1
	);
	add_filter(
		'site_option_active_sitewide_plugins',
		static function ( $plugins ) use ( $agent_backup_recovery_guard_plugin ) {
			if ( ! is_array( $plugins ) ) {
				return $plugins;
			}
			$filtered = $plugins;
			if ( array_key_exists( $agent_backup_recovery_guard_plugin, $filtered ) ) {
				unset( $filtered[ $agent_backup_recovery_guard_plugin ] );
			}
			return $filtered;
		},
		PHP_INT_MAX,
		1
	);
}

$agent_backup_recovery_guard_armed = agent_backup_recovery_guard_read_state( 'armed', $agent_backup_recovery_guard_secret );
if (
	is_array( $agent_backup_recovery_guard_armed )
	&& ! is_array( $agent_backup_recovery_guard_quarantine )
	&& (int) ( $agent_backup_recovery_guard_armed['expires_at'] ?? 0 ) >= time()
) {
	$agent_backup_recovery_guard_memory_reserve = str_repeat( 'R', 65536 );
	register_shutdown_function(
		static function () use ( $agent_backup_recovery_guard_armed, $agent_backup_recovery_guard_secret, &$agent_backup_recovery_guard_memory_reserve ) {
			$agent_backup_recovery_guard_memory_reserve = null;
			if ( (int) ( $agent_backup_recovery_guard_armed['expires_at'] ?? 0 ) < time() ) {
				return;
			}
			$error = error_get_last();
			if ( ! is_array( $error ) ) {
				return;
			}
			$fatal_types = array( E_ERROR, E_PARSE, E_CORE_ERROR, E_COMPILE_ERROR, E_USER_ERROR, E_RECOVERABLE_ERROR );
			if ( ! in_array( (int) ( $error['type'] ?? 0 ), $fatal_types, true ) ) {
				return;
			}
			$plugin = (string) $agent_backup_recovery_guard_armed['plugin'];
			if ( ! agent_backup_recovery_guard_fatal_belongs_to_plugin( $plugin, (string) ( $error['file'] ?? '' ) ) ) {
				return;
			}
			$quarantine = array(
				'schema'                  => AGENT_BACKUP_RECOVERY_GUARD_SCHEMA,
				'kind'                    => 'quarantine',
				'capability_version'      => (int) $agent_backup_recovery_guard_armed['capability_version'],
				'transaction_id'          => (string) $agent_backup_recovery_guard_armed['transaction_id'],
				'plugin'                  => $plugin,
				'expected_from_version'   => (string) $agent_backup_recovery_guard_armed['expected_from_version'],
				'expected_target_version' => (string) $agent_backup_recovery_guard_armed['expected_target_version'],
				'issued_at'               => (int) $agent_backup_recovery_guard_armed['issued_at'],
				'quarantined_at'          => time(),
				'error_type'              => (int) $error['type'],
			);
			agent_backup_recovery_guard_atomic_quarantine_write( $quarantine, $agent_backup_recovery_guard_secret );
		}
	);
}
