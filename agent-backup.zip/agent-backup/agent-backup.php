<?php
/**
 * Plugin Name: Agent Backup - by Jung und Wild design
 * Description: Backup connector for orchestrator (read-only REST API).
 * Author: Patrick Zeitz
 * Version: 0.3.4
 * Update URI: https://github.com/patrickzeitz/backup_orchestrator_agent_plugin
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'AGENT_BACKUP_VERSION', '0.3.4' );
define( 'AGENT_BACKUP_PATH', plugin_dir_path( __FILE__ ) );
define( 'AGENT_BACKUP_URL', plugin_dir_url( __FILE__ ) );
define( 'AGENT_BACKUP_BASENAME', plugin_basename( __FILE__ ) );
define( 'AGENT_BACKUP_DEFAULT_UPDATE_METADATA_URL', 'https://raw.githubusercontent.com/patrickzeitz/backup_orchestrator_agent_plugin/main/agent-backup-update.json' );
define( 'AGENT_BACKUP_OPTION_SETTINGS', 'agent_backup_settings' );
define( 'AGENT_BACKUP_LOG_OPTION', 'agent_backup_logs' );
define( 'AGENT_BACKUP_PAIRING_OPTION', 'agent_backup_pairing' );
define( 'AGENT_BACKUP_PAIRING_NOTICE_OPTION', 'agent_backup_pairing_notice' );
define( 'AGENT_BACKUP_ACTIVATION_REDIRECT_OPTION', 'agent_backup_activation_redirect' );

require_once AGENT_BACKUP_PATH . 'includes/helpers.php';
require_once AGENT_BACKUP_PATH . 'includes/logging.php';
require_once AGENT_BACKUP_PATH . 'includes/pairing.php';
require_once AGENT_BACKUP_PATH . 'includes/auth.php';
require_once AGENT_BACKUP_PATH . 'includes/admin-login.php';
require_once AGENT_BACKUP_PATH . 'includes/files.php';
require_once AGENT_BACKUP_PATH . 'includes/db.php';
require_once AGENT_BACKUP_PATH . 'includes/maintenance.php';
require_once AGENT_BACKUP_PATH . 'includes/update-source.php';
require_once AGENT_BACKUP_PATH . 'includes/settings.php';
require_once AGENT_BACKUP_PATH . 'includes/routes.php';

register_activation_hook( __FILE__, 'agent_backup_handle_activation' );
