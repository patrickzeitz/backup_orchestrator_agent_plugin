# Agent Backup – ToDo 1.0

- Optional: Parallelität im Orchestrator (z. B. `--workers 2`), Standard 1, konservative Limits.
- Optional: Nur bestimmte Site syncen (`--site <id>`).
- Optional: Force-DB-Flag im Orchestrator (Timer ignorieren, Dump sofort).
- Admin-UI: Export/Import der Agent-Settings (ohne Token/Secret); Anzeige der letzten Runs je Site (meta/last_run.json).
- Health/Status: Self-Check erweitern (Hinweise zu Limits/Timeouts/Chunks).
- Monitoring: Optionaler Webhook/Email bei fehlgeschlagenen Runs.
- Optional: Datei-Hashes im /files-Index (sha256) für verlässlicheres Delta.
- Optional: File-Index-Cache + POST /rescan zum Invalidieren (falls nötig).
- Orchestrator: Chunk-/Limit-Overrides pro Site (falls abweichend vom Agent); optional JSON-Log-Format.
