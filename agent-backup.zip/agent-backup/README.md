# Agent Backup – Technische Doku

Dieses System besteht aus einem WordPress-Agent-Plugin (REST-Connector) und einem Python-Orchestrator auf TrueNAS SCALE. Ziel: wp-content + DB per Pull sichern, ohne SSH, mit IP-Allowlist + Agent-Token + HMAC.

## Architektur
- WP-Seite mit Agent-Plugin, REST-Namespace `/wp-json/agent-backup/v1`
- TrueNAS-Container mit Orchestrator (Python)
- Storage: `/data/<site-id>/files|db|meta` (Dataset z. B. `backup-pool/wp-backups/<site-id>`)

## Sicherheit / Auth
- IP-Allowlist (Plugin-Settings)
- Agent-Token pro Site (Plugin-Settings, in `/app/config/secrets.env`)
- HMAC: bevorzugt über `X-Agent-Timestamp`, `X-Agent-Content-SHA256`, `X-Agent-Signature` (v1=<hex>), Zeitfenster ±300s
- Legacy-Kompatibilität: ältere Agenten akzeptieren weiter `Authorization: Bearer ...` sowie `X-AB-*`
- Canonical String: `v1\n<METHOD>\n<PATH>\n<QUERY(sorted RFC3986)>\n<TS>\n<BODY_HASH>`
- Pfad-Traversal-Schutz bei `/file`

## REST-Endpunkte (Plugin)
- `GET /status` → `{ok, ts, site, agent_version}`
- `GET /files?cursor=&limit=&root=wp-content` (paginiert, default 5k, max 20k; Excludes konfigurierbar)
- `GET /file?path=&offset=&length=` (Partial Content 206, default 5MB, max 20MB)
- `GET /db?gzip=1` (streamt Dump; nutzt mysqldump mit Host/Port/Socket, Fallback via WPDB, gzip optional)
- `POST /rescan` (Hook-Stelle für Cache-Invalidation)
- Auth-Middleware auf allen Routen

## Plugin-Settings (WP-Admin → Einstellungen → Agent Backup)
- Agent Token / HMAC Secret (rotierbar)
- Allowlisted IPs, Trust Proxy
- Exclude-Prefixes für `/files`
- Log-Retention
- Debug DB Logging (optional, schreibt in PHP-Errorlog)

## Orchestrator (Python)
Pfad: `/app/config/orchestrator.py`
- Config: `/app/config/sites.yml` (IDs, base_url, Endpoints, Backup-Intervalle)  
  Secrets: `/app/config/secrets.env` (`SITE_<ID>_TOKEN`, `SITE_<ID>_SECRET`, ID normalisiert: `-`/`.` → `_`)
- Ablauf pro Run:
  1. `/status` prüfen
  2. `/files` paginiert laden → `meta/index_latest.json`
  3. Delta mtime+size vs. vorher → geänderte Dateien via `/file` chunked (Resume) nach `/data/<id>/files/…`
  4. Entfernte Dateien optional löschen (`delete_removed_files`)
  5. DB-Dump, wenn fällig (`db_every_minutes`), nach `/data/<id>/db/db_YYYY-mm-dd_HHMM.sql.gz`
  6. `meta/last_run.json` schreiben (Counts, Bytes, Dauer, Fehler)
- Robustheit: 3 Retries bei 429/5xx/Timeout, Chunk-Download 5MB, Pfad-Safety, keine Secrets in Logs

## Verzeichnis-Layout (TrueNAS-Container)
- `/data/<site-id>/files`  – wp-content-Struktur
- `/data/<site-id>/db`     – Dumps (`db_*.sql.gz`)
- `/data/<site-id>/meta`   – `index_latest.json`, `last_run.json`
- `/app/config/sites.yml`, `/app/config/secrets.env`, Logs unter `/app/logs/orchestrator.log`

## Quick-Start / Pflege
1) Plugin auf WP installieren/aktivieren, IP-Allowlist setzen, Agent-Token+Secret rotieren und notieren.
2) `secrets.env` füllen:
   ```
   SITE_<ID>_TOKEN="..."
   SITE_<ID>_SECRET="..."
   ```
3) `sites.yml` pflegen (base_url ohne Slash am Ende, Endpoints wie oben).
4) Test: `python /app/config/orchestrator.py --once` und `tail -n 50 /app/logs/orchestrator.log`.
5) Inhalte prüfen: `ls -lah /data/<id>/{files,db,meta}`, `gzip -l /data/<id>/db/db_*.sql.gz`.

## Häufige Stolpersteine
- 401 Missing token: Env-Key falsch benannt (`-` vs `_`), Agent-Token/Secret nicht aktualisiert.
- 500 /db: mysqldump nicht verfügbar oder DB_HOST mit Port → jetzt Port/Socket-Support; Debug DB Logging einschalten und PHP-Errorlog prüfen.
- 0-Byte-Dumps: behoben ab Agent 0.3.x (Tempfile-Stream, Fallback).
- PATH kaputt in Shell: nie `PATH=...` mit API-URL überschreiben; neuen Shell-Tab öffnen.

## Beispiel: neue Site hinzufügen
- `sites.yml` erweitern (siehe Quick-Start)
- `secrets.env` um `SITE_NEUE_ID_TOKEN/SECRET` ergänzen (ID normalisiert)
- Plugin auf neuer WP-Site konfigurieren (Allowlist + Token/Secret)
- Testlauf `--once`, Logs prüfen.

## Manuelle curl-Checks (Status)
```bash
TS=$(date +%s)
BODY=e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855
TOKEN="…"
SECRET='…'
SIG=$(python3 - "$SECRET" "$TS" "$BODY" "/wp-json/agent-backup/v1/status" "" <<'PY'
import hmac, hashlib, sys
secret, ts, body, path, query = sys.argv[1:6]
canonical = f"v1\nGET\n{path}\n{query}\n{ts}\n{body}"
print(hmac.new(secret.encode(), canonical.encode(), hashlib.sha256).hexdigest())
PY
)
curl -i \
  -H "Authorization: Bearer $TOKEN" \
  -H "X-AB-Timestamp: $TS" \
  -H "X-AB-Content-SHA256: $BODY" \
  -H "X-AB-Signature: v1=$SIG" \
  https://example.com/wp-json/agent-backup/v1/status
```

## Backups ohne SSH?
Ja. Alles läuft über HTTPS/REST mit signierten Requests, kein SSH-Zugang nötig.
