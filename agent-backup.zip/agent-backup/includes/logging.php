<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Store log entries in an option with retention.
 */
function agent_backup_log( $message ) {
	$settings  = agent_backup_get_settings();
	$retention = max( 1, absint( $settings['log_retention'] ) );
	$logs      = get_option( AGENT_BACKUP_LOG_OPTION, array() );

	$logs[] = array(
		'ts'  => time(),
		'msg' => sanitize_text_field( $message ),
	);

	$cutoff = time() - ( $retention * DAY_IN_SECONDS );
	$logs   = array_filter(
		$logs,
		function ( $entry ) use ( $cutoff ) {
			return isset( $entry['ts'] ) && (int) $entry['ts'] >= $cutoff;
		}
	);

	update_option( AGENT_BACKUP_LOG_OPTION, array_values( $logs ), false );
}

