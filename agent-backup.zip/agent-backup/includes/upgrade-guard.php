<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/** Server metadata describes the PHP origin, including Apache behind an nginx proxy. */
function agent_backup_upgrade_guard_server() {
	$software = isset( $_SERVER['SERVER_SOFTWARE'] ) ? (string) $_SERVER['SERVER_SOFTWARE'] : '';
	$type = 'unknown';
	if ( ! empty( $GLOBALS['is_apache'] ) || false !== stripos( $software, 'apache' ) ) {
		$type = 'apache';
	} elseif ( ! empty( $GLOBALS['is_nginx'] ) || false !== stripos( $software, 'nginx' ) ) {
		$type = 'nginx';
	} elseif ( '' !== $software ) {
		$type = 'other';
	}
	return array( 'type' => $type, 'software' => $software );
}

/** Write a complete replacement on the same filesystem, preserving file permissions. */
function agent_backup_upgrade_guard_write( $path, $contents, $mode ) {
	$temp = @tempnam( dirname( $path ), '.agent-upgrade-' );
	if ( false === $temp ) {
		return false;
	}
	if ( dirname( $temp ) !== dirname( $path ) ) {
		@unlink( $temp );
		return false;
	}
	$written = strlen( $contents ) === @file_put_contents( $temp, $contents );
	$written = $written && @chmod( $temp, $mode & 0777 );
	$written = $written && @rename( $temp, $path );
	if ( file_exists( $temp ) ) {
		@unlink( $temp );
	}
	return $written;
}

/** A positive control prevents a 403 caused by an incorrect URL mapping from passing. */
function agent_backup_upgrade_guard_probe() {
	$nonce = bin2hex( random_bytes( 16 ) );
	$execution_token = bin2hex( random_bytes( 16 ) );
	$control = WP_CONTENT_DIR . '/agent-upgrade-control-' . $nonce;
	$protected = WP_CONTENT_DIR . '/upgrade/agent-upgrade-probe-' . $nonce;
	$created = array();
	try {
		foreach ( array( $control, $protected ) as $directory ) {
			if ( ! wp_mkdir_p( $directory ) ) {
				return new WP_Error( 'upgrade_guard_probe_write_failed', 'Cannot create the upgrade protection probe.' );
			}
			$created[] = $directory;
			$php = '<?php file_put_contents(__DIR__ . "/executed", ' . var_export( $execution_token, true ) . '); echo ' . var_export( $execution_token, true ) . ';';
			foreach ( array( 'txt' => $nonce, 'php' => $php ) as $extension => $contents ) {
				if ( strlen( $contents ) !== @file_put_contents( $directory . '/probe.' . $extension, $contents ) ) {
					return new WP_Error( 'upgrade_guard_probe_write_failed', 'Cannot write the upgrade protection probe.' );
				}
			}
		}
		foreach ( array( 'txt', 'php' ) as $extension ) {
			foreach ( array( false, true ) as $blocked ) {
				$relative = $blocked ? 'upgrade/agent-upgrade-probe-' : 'agent-upgrade-control-';
				$url = content_url( $relative . $nonce . '/probe.' . $extension );
				$response = wp_remote_get( add_query_arg( 'guard_probe', $nonce, $url ), array(
					'timeout' => 15, 'redirection' => 0,
					'headers' => array( 'Cache-Control' => 'no-cache, no-store' ),
				) );
				if ( is_wp_error( $response ) ) {
					return new WP_Error( 'upgrade_guard_probe_unreachable', 'Upgrade protection HTTP probe failed: ' . $response->get_error_message() );
				}
				$status = (int) wp_remote_retrieve_response_code( $response );
				if ( 'php' === $extension ) {
					if ( $blocked && ( file_exists( $protected . '/executed' ) || false !== strpos( wp_remote_retrieve_body( $response ), $execution_token ) ) ) {
						return new WP_Error( 'upgrade_guard_php_executed', 'The upgrade-directory PHP probe executed. The update was not started.' );
					}
					if ( ! $blocked && @file_get_contents( $control . '/executed' ) !== $execution_token ) {
						return new WP_Error( 'upgrade_guard_control_failed', 'The PHP positive-control execution marker could not be verified.' );
					}
				}
				$expected = 'php' === $extension ? $execution_token : $nonce;
				if ( $blocked ? 403 !== $status : ( 200 !== $status || $expected !== wp_remote_retrieve_body( $response ) ) ) {
					return new WP_Error( 'upgrade_guard_not_effective', 'Upgrade protection could not be verified for ' . $extension . ' files (HTTP ' . $status . '). The update was not started.' );
				}
			}
		}
		return true;
	} finally {
		foreach ( $created as $directory ) {
			@unlink( $directory . '/executed' );
			@unlink( $directory . '/probe.txt' );
			@unlink( $directory . '/probe.php' );
			@rmdir( $directory );
		}
	}
}

/** Install a root rule on Apache; every server must pass the real HTTP probes. */
function agent_backup_ensure_upgrade_guard() {
	$path = rtrim( ABSPATH, '/\\' ) . '/.htaccess';
	$lock = @fopen( get_temp_dir() . 'agent-upgrade-' . md5( $path ) . '.lock', 'c' );
	if ( false === $lock || ! flock( $lock, LOCK_EX | LOCK_NB ) ) {
		if ( is_resource( $lock ) ) { fclose( $lock ); }
		return new WP_Error( 'upgrade_guard_busy', 'Another upgrade protection check is running.' );
	}
	$changed = false;
	$original = '';
	$replacement = '';
	$existed = false;
	$mode = 0644;
	try {
		$server = agent_backup_upgrade_guard_server();
		if ( 'apache' === $server['type'] ) {
			$root = trailingslashit( wp_normalize_path( ABSPATH ) );
			$content = wp_normalize_path( WP_CONTENT_DIR );
			if ( 0 !== strpos( $content . '/', $root ) || is_link( $path ) ) {
				return new WP_Error( 'upgrade_guard_unsupported_path', 'Automatic Apache protection requires wp-content inside the WordPress directory and a regular .htaccess file.' );
			}
			$existed = file_exists( $path );
			if ( $existed && ( ! is_file( $path ) || ! is_readable( $path ) || filesize( $path ) > 1048576 ) ) {
				return new WP_Error( 'upgrade_guard_unreadable', 'The existing .htaccess cannot be safely read.' );
			}
			$original = $existed ? @file_get_contents( $path ) : '';
			if ( false === $original ) {
				return new WP_Error( 'upgrade_guard_unreadable', 'Cannot read .htaccess.' );
			}
			$mode = $existed ? fileperms( $path ) & 0777 : 0644;
			$begin = '# BEGIN Agent Backup Upgrade Guard';
			$end = '# END Agent Backup Upgrade Guard';
			if ( substr_count( $original, $begin ) !== substr_count( $original, $end ) || substr_count( $original, $begin ) > 1 ) {
				return new WP_Error( 'upgrade_guard_invalid_markers', 'The existing upgrade protection block needs manual review.' );
			}
			$remaining = preg_replace( '/^# BEGIN Agent Backup Upgrade Guard\R.*?^# END Agent Backup Upgrade Guard\R?/ms', '', $original );
			if ( false !== strpos( $remaining, $begin ) || false !== strpos( $remaining, $end ) ) {
				return new WP_Error( 'upgrade_guard_invalid_markers', 'The existing upgrade protection markers are malformed.' );
			}
			$relative = substr( $content, strlen( $root ) ) . '/upgrade';
			if ( ! preg_match( '~^[a-zA-Z0-9_./-]+$~D', $relative ) ) {
				return new WP_Error( 'upgrade_guard_unsupported_path', 'This content directory needs a manually configured server rule.' );
			}
			$rule = 'RewriteRule "^' . preg_quote( $relative, '~' ) . '(?:/|$)" - [F,L,NC]';
			$replacement = $begin . "\n<IfModule mod_rewrite.c>\nRewriteEngine On\n" . $rule . "\n</IfModule>\n" . $end . "\n" . $remaining;
			if ( $replacement !== $original ) {
				if ( ! is_writable( dirname( $path ) ) || ( $existed && ! is_writable( $path ) ) ) {
					return new WP_Error( 'upgrade_guard_write_failed', 'The .htaccess file or its directory is not writable. The update was not started.' );
				}
				$backup = array( 'path' => $path, 'existed' => $existed, 'contents' => $original, 'sha256' => hash( 'sha256', $original ), 'created_at' => gmdate( 'c' ) );
				if ( ! get_option( 'agent_backup_upgrade_guard_backup', false ) ) {
					update_option( 'agent_backup_upgrade_guard_backup', $backup, false );
					if ( get_option( 'agent_backup_upgrade_guard_backup', false ) !== $backup ) {
						return new WP_Error( 'upgrade_guard_backup_failed', 'Cannot save the original .htaccess backup.' );
					}
				}
				if ( $existed !== file_exists( $path ) || ( $existed ? @file_get_contents( $path ) : '' ) !== $original || ! agent_backup_upgrade_guard_write( $path, $replacement, $mode ) ) {
					return new WP_Error( 'upgrade_guard_write_failed', 'Cannot safely write .htaccess. The update was not started.' );
				}
				$changed = true;
			}
		}
		$result = agent_backup_upgrade_guard_probe();
		if ( is_wp_error( $result ) && $changed && @file_get_contents( $path ) === $replacement ) {
			$restored = $existed ? agent_backup_upgrade_guard_write( $path, $original, $mode ) : @unlink( $path );
			if ( ! $restored ) {
				return new WP_Error( 'upgrade_guard_rollback_failed', 'Protection verification failed and .htaccess could not be restored. Manual review is required.' );
			}
		}
		return $result;
	} finally {
		flock( $lock, LOCK_UN );
		fclose( $lock );
	}
}

/** Also gate WordPress-admin and automatic core upgrades before package extraction. */
function agent_backup_upgrade_guard_before_download( $reply, $package, $upgrader, $hook_extra ) {
	if ( is_wp_error( $reply ) || ! ( $upgrader instanceof Core_Upgrader ) ) {
		return $reply;
	}
	$result = agent_backup_ensure_upgrade_guard();
	return is_wp_error( $result ) ? $result : $reply;
}

add_filter( 'upgrader_pre_download', 'agent_backup_upgrade_guard_before_download', -1000, 4 );
