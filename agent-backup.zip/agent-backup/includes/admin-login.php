<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'AGENT_BACKUP_ADMIN_LOGIN_OPTION', 'agent_backup_admin_login_tokens' );

function agent_backup_get_admin_login_tokens() {
	$tokens = get_option( AGENT_BACKUP_ADMIN_LOGIN_OPTION, array() );
	return is_array( $tokens ) ? $tokens : array();
}

function agent_backup_save_admin_login_tokens( $tokens ) {
	update_option( AGENT_BACKUP_ADMIN_LOGIN_OPTION, $tokens, false );
}

function agent_backup_cleanup_admin_login_tokens( $tokens ) {
	$now     = time();
	$changed = false;
	foreach ( $tokens as $hash => $token ) {
		$expires_at = isset( $token['expires_at'] ) ? absint( $token['expires_at'] ) : 0;
		if ( $expires_at > 0 && $expires_at < $now ) {
			unset( $tokens[ $hash ] );
			$changed = true;
		}
	}
	if ( $changed ) {
		agent_backup_save_admin_login_tokens( $tokens );
	}
	return $tokens;
}

function agent_backup_admin_login_candidates() {
	$users      = get_users(
		array(
			'orderby' => 'login',
			'order'   => 'ASC',
		)
	);
	$candidates = array();
	foreach ( $users as $user ) {
		if ( ! ( $user instanceof WP_User ) ) {
			continue;
		}
		if ( ! user_can( $user, 'manage_options' ) ) {
			continue;
		}
		$candidates[] = array(
			'user_login'   => $user->user_login,
			'display_name' => $user->display_name,
			'roles'        => array_values( array_map( 'strval', (array) $user->roles ) ),
		);
	}
	return $candidates;
}

function agent_backup_route_admin_login_users() {
	return new WP_REST_Response(
		array(
			'ok'    => true,
			'users' => agent_backup_admin_login_candidates(),
		),
		200
	);
}

function agent_backup_route_admin_login_create( WP_REST_Request $request ) {
	$user_login = sanitize_user( (string) $request->get_param( 'user_login' ), true );
	if ( '' === $user_login ) {
		return new WP_Error( 'bad_request', __( 'user_login is required', 'agent-backup' ), array( 'status' => 400 ) );
	}

	$user = get_user_by( 'login', $user_login );
	if ( ! ( $user instanceof WP_User ) || ! user_can( $user, 'manage_options' ) ) {
		return new WP_Error( 'bad_request', __( 'The selected WordPress admin user is not available.', 'agent-backup' ), array( 'status' => 400 ) );
	}

	$tokens = agent_backup_cleanup_admin_login_tokens( agent_backup_get_admin_login_tokens() );
	$token  = wp_generate_password( 64, false, false );
	$hash   = hash_hmac( 'sha256', $token, wp_salt( 'auth' ) );
	$expiry = time() + 120;

	$tokens[ $hash ] = array(
		'user_id'    => (int) $user->ID,
		'expires_at' => $expiry,
		'created_at' => time(),
	);
	agent_backup_save_admin_login_tokens( $tokens );

	return new WP_REST_Response(
		array(
			'ok'         => true,
			'login_url'  => home_url( '/?agent_backup_autologin=' . rawurlencode( $token ) ),
			'expires_at' => gmdate( DATE_ATOM, $expiry ),
		),
		200
	);
}

function agent_backup_admin_login_failure_key() {
	$ip = isset( $_SERVER['REMOTE_ADDR'] ) ? wp_privacy_anonymize_ip( wp_unslash( $_SERVER['REMOTE_ADDR'] ), 3 ) : 'unknown';
	return 'agent_backup_autologin_fail_' . md5( $ip );
}

function agent_backup_admin_login_rate_limit_exceeded() {
	return (int) get_transient( agent_backup_admin_login_failure_key() ) >= 10;
}

function agent_backup_admin_login_note_failure() {
	$key   = agent_backup_admin_login_failure_key();
	$fails = (int) get_transient( $key );
	set_transient( $key, $fails + 1, 10 * MINUTE_IN_SECONDS );
}

function agent_backup_admin_login_reset_failures() {
	delete_transient( agent_backup_admin_login_failure_key() );
}

function agent_backup_maybe_handle_admin_autologin() {
	if ( ! isset( $_GET['agent_backup_autologin'] ) ) {
		return;
	}
	if ( agent_backup_admin_login_rate_limit_exceeded() ) {
		wp_die( __( 'Too many failed auto-login attempts. Please try again later.', 'agent-backup' ), 429 );
	}

	$token = sanitize_text_field( wp_unslash( $_GET['agent_backup_autologin'] ) );
	if ( '' === $token ) {
		agent_backup_admin_login_note_failure();
		wp_die( __( 'The auto-login token is missing.', 'agent-backup' ), 400 );
	}

	$tokens = agent_backup_cleanup_admin_login_tokens( agent_backup_get_admin_login_tokens() );
	$hash   = hash_hmac( 'sha256', $token, wp_salt( 'auth' ) );
	if ( empty( $tokens[ $hash ] ) || ! is_array( $tokens[ $hash ] ) ) {
		agent_backup_admin_login_note_failure();
		wp_die( __( 'This auto-login link is invalid or already used.', 'agent-backup' ), 403 );
	}

	$token_info = $tokens[ $hash ];
	unset( $tokens[ $hash ] );
	agent_backup_save_admin_login_tokens( $tokens );

	$expires_at = isset( $token_info['expires_at'] ) ? absint( $token_info['expires_at'] ) : 0;
	if ( $expires_at <= 0 || $expires_at < time() ) {
		agent_backup_admin_login_note_failure();
		wp_die( __( 'This auto-login link has expired.', 'agent-backup' ), 403 );
	}

	$user_id = isset( $token_info['user_id'] ) ? absint( $token_info['user_id'] ) : 0;
	$user    = $user_id > 0 ? get_user_by( 'id', $user_id ) : false;
	if ( ! ( $user instanceof WP_User ) || ! user_can( $user, 'manage_options' ) ) {
		agent_backup_admin_login_note_failure();
		wp_die( __( 'The selected WordPress admin user is no longer available.', 'agent-backup' ), 403 );
	}

	agent_backup_admin_login_reset_failures();
	wp_clear_auth_cookie();
	wp_set_current_user( $user->ID );
	wp_set_auth_cookie( $user->ID, true );
	wp_safe_redirect( admin_url() );
	exit;
}
add_action( 'init', 'agent_backup_maybe_handle_admin_autologin' );
