<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Read the orchestrator pairing manifest bundled into the site-specific ZIP.
 */
function agent_backup_read_pairing_manifest() {
	$path = AGENT_BACKUP_PATH . 'pairing-manifest.json';
	if ( ! file_exists( $path ) ) {
		return null;
	}

	$payload = json_decode( file_get_contents( $path ), true );
	if ( ! is_array( $payload ) ) {
		return null;
	}

	return $payload;
}

/**
 * Default pairing state kept in a dedicated option.
 */
function agent_backup_default_pairing_state() {
	return array(
		'status'          => 'unpaired',
		'last_message'    => '',
		'paired_at'       => '',
		'pair_site_id'    => '',
		'orchestrator_url'=> '',
		'agent_url'       => '',
	);
}

function agent_backup_get_pairing_state() {
	$stored = get_option( AGENT_BACKUP_PAIRING_OPTION, array() );
	return wp_parse_args( $stored, agent_backup_default_pairing_state() );
}

function agent_backup_save_pairing_state( $state ) {
	$merged = wp_parse_args( $state, agent_backup_default_pairing_state() );
	update_option( AGENT_BACKUP_PAIRING_OPTION, $merged, false );
	return $merged;
}

function agent_backup_set_pairing_notice( $message, $type = 'notice-warning' ) {
	update_option(
		AGENT_BACKUP_PAIRING_NOTICE_OPTION,
		array(
			'message' => (string) $message,
			'type'    => (string) $type,
		),
		false
	);
}

function agent_backup_render_pairing_notice() {
	if ( ! current_user_can( 'manage_options' ) ) {
		return;
	}

	$notice = get_option( AGENT_BACKUP_PAIRING_NOTICE_OPTION, array() );
	if ( empty( $notice['message'] ) ) {
		return;
	}

	delete_option( AGENT_BACKUP_PAIRING_NOTICE_OPTION );
	$type = ! empty( $notice['type'] ) ? $notice['type'] : 'notice-warning';
	?>
	<div class="notice <?php echo esc_attr( $type ); ?> is-dismissible">
		<p><?php echo esc_html( $notice['message'] ); ?></p>
	</div>
	<?php
}
add_action( 'admin_notices', 'agent_backup_render_pairing_notice' );

/**
 * Attempt pairing against the orchestrator using the bundled one-time token.
 */
function agent_backup_attempt_pairing( $trigger = 'manual' ) {
	$manifest = agent_backup_read_pairing_manifest();
	if ( empty( $manifest['pair_url'] ) || empty( $manifest['pair_token'] ) ) {
		return false;
	}

	$state = agent_backup_get_pairing_state();
	if ( 'paired' === $state['status'] ) {
		return true;
	}

	$response = wp_remote_post(
		esc_url_raw( $manifest['pair_url'] ),
		array(
			'timeout' => 20,
			'body'    => array(
				'pair_token'    => (string) $manifest['pair_token'],
				'site_url'      => home_url(),
				'agent_version' => AGENT_BACKUP_VERSION,
			),
			'headers' => array(
				'Accept' => 'application/json',
			),
		)
	);

	if ( is_wp_error( $response ) ) {
		$message = sprintf(
			/* translators: %s is the HTTP error message */
			__( 'Pairing request failed: %s', 'agent-backup' ),
			$response->get_error_message()
		);
		agent_backup_save_pairing_state(
			array(
				'status'       => 'failed',
				'last_message' => $message,
			)
		);
		agent_backup_set_pairing_notice( $message, 'notice-error' );
		return false;
	}

	$status_code = wp_remote_retrieve_response_code( $response );
	$payload     = json_decode( wp_remote_retrieve_body( $response ), true );
	if ( $status_code >= 400 || empty( $payload['ok'] ) ) {
		$message = is_array( $payload ) && ! empty( $payload['error'] )
			? (string) $payload['error']
			: __( 'The orchestrator rejected the pairing request.', 'agent-backup' );
		agent_backup_save_pairing_state(
			array(
				'status'       => 'failed',
				'last_message' => $message,
			)
		);
		agent_backup_set_pairing_notice( $message, 'notice-error' );
		return false;
	}

	$settings = agent_backup_get_settings();
	$settings['token'] = isset( $payload['token'] ) ? (string) $payload['token'] : $settings['token'];
	$settings['secret'] = isset( $payload['secret'] ) ? (string) $payload['secret'] : $settings['secret'];
	if ( ! empty( $payload['allow_ips'] ) && is_array( $payload['allow_ips'] ) ) {
		$settings['allow_ips'] = array_values(
			array_filter(
				array_map(
					static function ( $value ) {
						return trim( (string) $value );
					},
					$payload['allow_ips']
				)
			)
		);
	}
	$settings['trust_proxy'] = ! empty( $payload['trust_proxy'] );
	agent_backup_save_settings( $settings );

	$orchestrator_url = wp_parse_url( (string) $manifest['pair_url'], PHP_URL_SCHEME ) . '://' . wp_parse_url( (string) $manifest['pair_url'], PHP_URL_HOST );
	$port             = wp_parse_url( (string) $manifest['pair_url'], PHP_URL_PORT );
	if ( $port ) {
		$orchestrator_url .= ':' . $port;
	}

	$state = agent_backup_save_pairing_state(
		array(
			'status'           => 'paired',
			'last_message'     => __( 'The agent is connected to the orchestrator.', 'agent-backup' ),
			'paired_at'        => current_time( 'mysql' ),
			'pair_site_id'     => isset( $payload['site_id'] ) ? (string) $payload['site_id'] : '',
			'orchestrator_url' => $orchestrator_url,
			'agent_url'        => home_url(),
		)
	);

	if ( 'activation' === $trigger ) {
		agent_backup_set_pairing_notice( __( 'Agent Backup connected successfully during activation.', 'agent-backup' ), 'notice-success' );
	} else {
		agent_backup_set_pairing_notice( $state['last_message'], 'notice-success' );
	}

	return true;
}

/**
 * Activation hook entrypoint.
 */
function agent_backup_handle_activation() {
	agent_backup_attempt_pairing( 'activation' );
	update_option( AGENT_BACKUP_ACTIVATION_REDIRECT_OPTION, 1, false );
}
