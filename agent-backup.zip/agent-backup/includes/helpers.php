<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * IPs that must stay allowed for orchestrator access.
 */
function agent_backup_default_allow_ips() {
	return array( '127.0.0.1', '85.183.147.199', '82.165.238.71' );
}

/**
 * Normalize and append required default IPs without dropping custom entries.
 */
function agent_backup_merge_default_allow_ips( $allow_ips ) {
	$merged = array();
	foreach ( array_merge( (array) $allow_ips, agent_backup_default_allow_ips() ) as $ip ) {
		$ip = trim( (string) $ip );
		if ( '' === $ip || in_array( $ip, $merged, true ) ) {
			continue;
		}
		$merged[] = $ip;
	}
	return $merged;
}

/**
 * Default settings for the plugin.
 */
function agent_backup_default_settings() {
	return array(
		'token'            => '',
		'secret'           => '',
		'allow_ips'        => agent_backup_default_allow_ips(),
		'trust_proxy'      => false,
		'debug_db_log'     => false,
		'update_metadata_url' => '',
		'excludes'         => array(
			'cache',
			'updraft',
			'backup',
			'backups',
			'.git',
			'.svn',
			'node_modules',
		),
		'max_file_length'  => 20 * 1024 * 1024,
		'default_limit'    => 5000,
		'max_limit'        => 20000,
		'timestamp_window' => 300,
		'log_retention'    => 7,
		'last_backup_meta' => array(),
	);
}

/**
 * Retrieve settings merged with defaults.
 */
function agent_backup_get_settings() {
	$stored   = get_option( AGENT_BACKUP_OPTION_SETTINGS, array() );
	$settings = wp_parse_args( $stored, agent_backup_default_settings() );
	$settings['allow_ips'] = agent_backup_merge_default_allow_ips( $settings['allow_ips'] ?? array() );

	if ( empty( $settings['token'] ) || empty( $settings['secret'] ) ) {
		$settings['token']  = wp_generate_password( 64, false, false );
		$settings['secret'] = wp_generate_password( 64, true, true );
		update_option( AGENT_BACKUP_OPTION_SETTINGS, $settings, false );
	} elseif ( $settings !== $stored ) {
		update_option( AGENT_BACKUP_OPTION_SETTINGS, $settings, false );
	}

	return $settings;
}

/**
 * Persist settings.
 */
function agent_backup_save_settings( $settings ) {
	$merged = wp_parse_args( $settings, agent_backup_default_settings() );
	$merged['allow_ips'] = agent_backup_merge_default_allow_ips( $merged['allow_ips'] ?? array() );
	update_option( AGENT_BACKUP_OPTION_SETTINGS, $merged, false );
	return $merged;
}

/**
 * Detect client IP with optional proxy trust.
 */
function agent_backup_client_ip( $trust_proxy ) {
	$ip = '';

	if ( $trust_proxy && ! empty( $_SERVER['HTTP_X_FORWARDED_FOR'] ) ) {
		$parts = explode( ',', wp_unslash( $_SERVER['HTTP_X_FORWARDED_FOR'] ) );
		$ip    = trim( $parts[0] );
	}

	if ( empty( $ip ) && ! empty( $_SERVER['REMOTE_ADDR'] ) ) {
		$ip = wp_unslash( $_SERVER['REMOTE_ADDR'] );
	}

	return $ip;
}

/**
 * Build canonical query string (sorted, RFC3986).
 */
function agent_backup_canonical_query( $params ) {
	if ( empty( $params ) || ! is_array( $params ) ) {
		return '';
	}
	ksort( $params );
	return http_build_query( $params, '', '&', PHP_QUERY_RFC3986 );
}

/**
 * Validate a relative path under wp-content.
 */
function agent_backup_validate_path( $relative_path ) {
	$relative_path = ltrim( str_replace( array( '../', '..\\', "\0" ), '', $relative_path ), '/\\' );
	$base          = trailingslashit( WP_CONTENT_DIR );
	$full          = $base . $relative_path;
	$real_base     = realpath( $base );
	$real_target   = realpath( $full );

	if ( false === $real_base || false === $real_target ) {
		return false;
	}

	if ( 0 !== strpos( $real_target, $real_base ) ) {
		return false;
	}

	return $real_target;
}

/**
 * Minimal stream response wrapper.
 */
class Agent_Backup_Stream_Response {
	public $headers;
	public $status;
	public $streamer;

	public function __construct( $streamer, $headers = array(), $status = 200 ) {
		$this->streamer = $streamer;
		$this->headers  = $headers;
		$this->status   = $status;
	}
}

/**
 * Prepare PHP/runtime state for long streamed responses.
 */
function agent_backup_prepare_stream_environment() {
	if ( function_exists( 'ignore_user_abort' ) ) {
		ignore_user_abort( true );
	}
	if ( function_exists( 'set_time_limit' ) ) {
		@set_time_limit( 0 );
	}
	if ( function_exists( 'apache_setenv' ) ) {
		@apache_setenv( 'no-gzip', '1' );
	}
	@ini_set( 'zlib.output_compression', '0' );
	@ini_set( 'output_buffering', '0' );
	@ini_set( 'implicit_flush', '1' );

	while ( ob_get_level() > 0 ) {
		ob_end_clean();
	}

	if ( function_exists( 'nocache_headers' ) ) {
		nocache_headers();
	}
}

/**
 * Flush stream buffers if possible.
 */
function agent_backup_flush_stream_buffers() {
	if ( function_exists( 'flush' ) ) {
		flush();
	}
}

/**
 * Send stream immediately (bypass REST wrapping) and exit.
 */
function agent_backup_send_stream_now( $streamer, $headers = array(), $status = 200 ) {
	agent_backup_prepare_stream_environment();
	if ( ! headers_sent() ) {
		http_response_code( $status );
		foreach ( (array) $headers as $name => $value ) {
			header( $name . ': ' . $value );
		}
	}
	call_user_func( $streamer );
	agent_backup_flush_stream_buffers();
	if ( function_exists( 'fastcgi_finish_request' ) ) {
		fastcgi_finish_request();
	}
	exit;
}
