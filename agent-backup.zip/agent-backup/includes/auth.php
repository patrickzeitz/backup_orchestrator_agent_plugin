<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Permission callback: IP allowlist + agent token + HMAC signature.
 */
function agent_backup_authenticate_request( WP_REST_Request $request ) {
	$settings  = agent_backup_get_settings();
	$client_ip = agent_backup_client_ip( ! empty( $settings['trust_proxy'] ) );

	if ( ! in_array( $client_ip, (array) $settings['allow_ips'], true ) ) {
		return new WP_Error( 'forbidden_ip', __( 'IP not allowed', 'agent-backup' ), array( 'status' => 403 ) );
	}

	$token = trim( (string) $request->get_header( 'x-agent-token' ) );
	if ( '' === $token ) {
		$auth_header = $request->get_header( 'authorization' ) ?: '';
		if ( preg_match( '/Bearer\\s+(.*)$/i', $auth_header, $m ) ) {
			$token = trim( $m[1] );
		}
	}
	if ( '' === $token ) {
		return new WP_Error( 'missing_token', __( 'Missing agent token', 'agent-backup' ), array( 'status' => 401 ) );
	}

	if ( empty( $settings['token'] ) || ! hash_equals( $settings['token'], $token ) ) {
		return new WP_Error( 'bad_token', __( 'Invalid agent token', 'agent-backup' ), array( 'status' => 401 ) );
	}

	$ts               = (int) ( $request->get_header( 'x-agent-timestamp' ) ?: $request->get_header( 'x-ab-timestamp' ) );
	$timestamp_window = max( 60, absint( $settings['timestamp_window'] ?? 300 ) );
	if ( $ts <= 0 || abs( time() - $ts ) > $timestamp_window ) {
		return new WP_Error( 'timestamp_out_of_window', __( 'Timestamp out of window', 'agent-backup' ), array( 'status' => 401 ) );
	}

	$raw_body      = file_get_contents( 'php://input' );
	$body_hash     = hash( 'sha256', $raw_body ?: '' );
	$body_hash_hdr = strtolower( (string) ( $request->get_header( 'x-agent-content-sha256' ) ?: $request->get_header( 'x-ab-content-sha256' ) ) );
	if ( '' === $body_hash_hdr || ! hash_equals( $body_hash, $body_hash_hdr ) ) {
		return new WP_Error( 'bad_request', __( 'Body hash mismatch', 'agent-backup' ), array( 'status' => 400 ) );
	}

	$sig_hdr = (string) ( $request->get_header( 'x-agent-signature' ) ?: $request->get_header( 'x-ab-signature' ) );
	if ( ! preg_match( '/^v1=([a-f0-9]{64})$/i', trim( $sig_hdr ), $m_sig ) ) {
		return new WP_Error( 'invalid_signature', __( 'Missing signature', 'agent-backup' ), array( 'status' => 401 ) );
	}
	$provided_sig = strtolower( $m_sig[1] );

	$params    = $request->get_query_params();
	$query     = agent_backup_canonical_query( $params );
	$path      = '/wp-json' . $request->get_route();
	$method    = strtoupper( $request->get_method() );
	$canonical = "v1\n{$method}\n{$path}\n{$query}\n{$ts}\n{$body_hash}";

	$expected_sig = hash_hmac( 'sha256', $canonical, $settings['secret'] );
	if ( ! hash_equals( $expected_sig, $provided_sig ) ) {
		return new WP_Error( 'invalid_signature', __( 'Invalid signature', 'agent-backup' ), array( 'status' => 401 ) );
	}

	return true;
}
