<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Permission callback: IP allowlist + agent token + HMAC signature.
 */
function agent_backup_authenticate_request( WP_REST_Request $request ) {
	return agent_backup_authenticate_signed_request(
		strtoupper( $request->get_method() ),
		'/wp-json' . $request->get_route(),
		$request->get_query_params(),
		static function ( $name ) use ( $request ) {
			return $request->get_header( $name );
		}
	);
}

/**
 * Permission helper for the admin-ajax maintenance fallback.
 */
function agent_backup_authenticate_ajax_request() {
	$request_uri = isset( $_SERVER['REQUEST_URI'] ) ? wp_unslash( $_SERVER['REQUEST_URI'] ) : '';
	$path        = wp_parse_url( $request_uri, PHP_URL_PATH );
	if ( empty( $path ) ) {
		$path = wp_parse_url( admin_url( 'admin-ajax.php' ), PHP_URL_PATH );
	}
	if ( empty( $path ) ) {
		$path = '/wp-admin/admin-ajax.php';
	}

	return agent_backup_authenticate_signed_request(
		isset( $_SERVER['REQUEST_METHOD'] ) ? strtoupper( sanitize_key( wp_unslash( $_SERVER['REQUEST_METHOD'] ) ) ) : 'POST',
		$path,
		wp_unslash( $_GET ),
		static function ( $name ) {
			return agent_backup_get_http_header( $name );
		}
	);
}

/**
 * Shared signature validator for REST and admin-ajax entry points.
 */
function agent_backup_authenticate_signed_request( $method, $path, $query_params, $header_resolver ) {
	$settings  = agent_backup_get_settings();
	$client_ip = agent_backup_client_ip( ! empty( $settings['trust_proxy'] ) );

	if ( ! in_array( $client_ip, (array) $settings['allow_ips'], true ) ) {
		return new WP_Error( 'forbidden_ip', __( 'IP not allowed', 'agent-backup' ), array( 'status' => 403 ) );
	}

	$token = trim( (string) call_user_func( $header_resolver, 'x-agent-token' ) );
	if ( '' === $token ) {
		$auth_header = call_user_func( $header_resolver, 'authorization' ) ?: '';
		if ( preg_match( '/Bearer\\s+(.*)$/i', $auth_header, $m ) ) {
			$token = trim( $m[1] );
		}
	}
	if ( '' === $token ) {
		return new WP_Error( 'missing_token', __( 'Missing agent token', 'agent-backup' ), array( 'status' => 401 ) );
	}

	if ( empty( $settings['token'] ) || ! hash_equals( $settings['token'], $token ) ) {
		return new WP_Error( 'bad_token', __( 'Invalid agent token', 'agent-backup' ), array( 'status' => 401 ) );
	}

	$ts               = (int) ( call_user_func( $header_resolver, 'x-agent-timestamp' ) ?: call_user_func( $header_resolver, 'x-ab-timestamp' ) );
	$timestamp_window = max( 60, absint( $settings['timestamp_window'] ?? 300 ) );
	if ( $ts <= 0 || abs( time() - $ts ) > $timestamp_window ) {
		return new WP_Error( 'timestamp_out_of_window', __( 'Timestamp out of window', 'agent-backup' ), array( 'status' => 401 ) );
	}

	$raw_body      = file_get_contents( 'php://input' );
	$body_hash     = hash( 'sha256', $raw_body ?: '' );
	$body_hash_hdr = strtolower( (string) ( call_user_func( $header_resolver, 'x-agent-content-sha256' ) ?: call_user_func( $header_resolver, 'x-ab-content-sha256' ) ) );
	if ( '' === $body_hash_hdr || ! hash_equals( $body_hash, $body_hash_hdr ) ) {
		return new WP_Error( 'bad_request', __( 'Body hash mismatch', 'agent-backup' ), array( 'status' => 400 ) );
	}

	$sig_hdr = (string) ( call_user_func( $header_resolver, 'x-agent-signature' ) ?: call_user_func( $header_resolver, 'x-ab-signature' ) );
	if ( ! preg_match( '/^v1=([a-f0-9]{64})$/i', trim( $sig_hdr ), $m_sig ) ) {
		return new WP_Error( 'invalid_signature', __( 'Missing signature', 'agent-backup' ), array( 'status' => 401 ) );
	}
	$provided_sig = strtolower( $m_sig[1] );

	$query     = agent_backup_canonical_query( $query_params );
	$method    = strtoupper( $method );
	$canonical = "v1\n{$method}\n{$path}\n{$query}\n{$ts}\n{$body_hash}";

	$expected_sig = hash_hmac( 'sha256', $canonical, $settings['secret'] );
	if ( ! hash_equals( $expected_sig, $provided_sig ) ) {
		return new WP_Error( 'invalid_signature', __( 'Invalid signature', 'agent-backup' ), array( 'status' => 401 ) );
	}

	return true;
}

/**
 * Read HTTP headers outside the REST request abstraction.
 */
function agent_backup_get_http_header( $name ) {
	$normalized = strtoupper( str_replace( '-', '_', (string) $name ) );
	$server_key = 'HTTP_' . $normalized;
	if ( isset( $_SERVER[ $server_key ] ) ) {
		return wp_unslash( $_SERVER[ $server_key ] );
	}
	if ( 'AUTHORIZATION' === $normalized ) {
		if ( isset( $_SERVER['HTTP_AUTHORIZATION'] ) ) {
			return wp_unslash( $_SERVER['HTTP_AUTHORIZATION'] );
		}
		if ( isset( $_SERVER['REDIRECT_HTTP_AUTHORIZATION'] ) ) {
			return wp_unslash( $_SERVER['REDIRECT_HTTP_AUTHORIZATION'] );
		}
	}
	return '';
}
