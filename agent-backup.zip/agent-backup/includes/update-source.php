<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

function agent_backup_get_update_metadata_url() {
	$settings = agent_backup_get_settings();
	$override = '';

	if ( ! empty( $settings['update_metadata_url'] ) ) {
		$override = trim( (string) $settings['update_metadata_url'] );
	}
	if ( '' !== $override ) {
		return esc_url_raw( $override );
	}

	if ( defined( 'AGENT_BACKUP_DEFAULT_UPDATE_METADATA_URL' ) && '' !== AGENT_BACKUP_DEFAULT_UPDATE_METADATA_URL ) {
		return esc_url_raw( AGENT_BACKUP_DEFAULT_UPDATE_METADATA_URL );
	}

	$pairing = agent_backup_get_pairing_state();
	if ( ! empty( $pairing['orchestrator_url'] ) ) {
		return trailingslashit( untrailingslashit( (string) $pairing['orchestrator_url'] ) ) . 'agent-plugin/update';
	}

	return '';
}

function agent_backup_fetch_update_metadata( $force = false ) {
	$metadata_url = agent_backup_get_update_metadata_url();
	if ( '' === $metadata_url ) {
		return null;
	}

	$cache_key = 'agent_backup_update_' . md5( $metadata_url . '|' . AGENT_BACKUP_VERSION );
	if ( ! $force ) {
		$cached = get_site_transient( $cache_key );
		if ( is_array( $cached ) ) {
			if ( ! empty( $cached['error'] ) ) {
				return null;
			}
			return $cached;
		}
	}

	$request_url = add_query_arg(
		array(
			'plugin'          => AGENT_BACKUP_BASENAME,
			'current_version' => AGENT_BACKUP_VERSION,
			'site_url'        => home_url(),
			'wp_version'      => get_bloginfo( 'version' ),
			'php_version'     => PHP_VERSION,
		),
		$metadata_url
	);

	$response = wp_remote_get(
		$request_url,
		array(
			'timeout' => 15,
			'headers' => array(
				'Accept' => 'application/json',
			),
		)
	);

	if ( is_wp_error( $response ) ) {
		agent_backup_log( sprintf( 'Agent update metadata request failed: %s', $response->get_error_message() ) );
		set_site_transient(
			$cache_key,
			array(
				'error' => $response->get_error_message(),
			),
			15 * MINUTE_IN_SECONDS
		);
		return null;
	}

	$status_code = wp_remote_retrieve_response_code( $response );
	$payload     = json_decode( wp_remote_retrieve_body( $response ), true );
	if ( $status_code >= 400 || ! is_array( $payload ) || empty( $payload['version'] ) || empty( $payload['download_url'] ) ) {
		agent_backup_log( sprintf( 'Agent update metadata rejected: HTTP %d', $status_code ) );
		set_site_transient(
			$cache_key,
			array(
				'error' => 'invalid_response',
			),
			15 * MINUTE_IN_SECONDS
		);
		return null;
	}

	set_site_transient( $cache_key, $payload, 6 * HOUR_IN_SECONDS );
	return $payload;
}

function agent_backup_filter_plugin_updates( $transient ) {
	if ( ! is_object( $transient ) ) {
		$transient = new stdClass();
	}

	if ( empty( $transient->checked ) || ! is_array( $transient->checked ) ) {
		return $transient;
	}

	$metadata = agent_backup_fetch_update_metadata();
	if ( ! is_array( $metadata ) ) {
		return $transient;
	}

	$plugin_file = AGENT_BACKUP_BASENAME;
	$entry       = (object) array(
		'slug'         => ! empty( $metadata['slug'] ) ? (string) $metadata['slug'] : 'agent-backup',
		'plugin'       => $plugin_file,
		'new_version'  => (string) $metadata['version'],
		'package'      => (string) $metadata['download_url'],
		'url'          => ! empty( $metadata['homepage'] ) ? (string) $metadata['homepage'] : '',
		'tested'       => ! empty( $metadata['tested'] ) ? (string) $metadata['tested'] : '',
		'requires'     => ! empty( $metadata['requires'] ) ? (string) $metadata['requires'] : '',
		'requires_php' => ! empty( $metadata['requires_php'] ) ? (string) $metadata['requires_php'] : '',
	);

	if ( version_compare( (string) $metadata['version'], AGENT_BACKUP_VERSION, '>' ) ) {
		if ( ! isset( $transient->response ) || ! is_array( $transient->response ) ) {
			$transient->response = array();
		}
		$transient->response[ $plugin_file ] = $entry;
		if ( isset( $transient->no_update[ $plugin_file ] ) ) {
			unset( $transient->no_update[ $plugin_file ] );
		}
		return $transient;
	}

	if ( ! isset( $transient->no_update ) || ! is_array( $transient->no_update ) ) {
		$transient->no_update = array();
	}
	$transient->no_update[ $plugin_file ] = $entry;
	if ( isset( $transient->response[ $plugin_file ] ) ) {
		unset( $transient->response[ $plugin_file ] );
	}

	return $transient;
}
add_filter( 'pre_set_site_transient_update_plugins', 'agent_backup_filter_plugin_updates' );
add_filter( 'site_transient_update_plugins', 'agent_backup_filter_plugin_updates' );

function agent_backup_plugins_api( $result, $action, $args ) {
	if ( 'plugin_information' !== $action || empty( $args->slug ) || 'agent-backup' !== $args->slug ) {
		return $result;
	}

	$metadata = agent_backup_fetch_update_metadata();
	if ( ! is_array( $metadata ) ) {
		return $result;
	}

	return (object) array(
		'name'          => ! empty( $metadata['name'] ) ? (string) $metadata['name'] : 'Agent Backup - by Jung und Wild design',
		'slug'          => ! empty( $metadata['slug'] ) ? (string) $metadata['slug'] : 'agent-backup',
		'version'       => ! empty( $metadata['version'] ) ? (string) $metadata['version'] : AGENT_BACKUP_VERSION,
		'author'        => ! empty( $metadata['author'] ) ? (string) $metadata['author'] : 'Patrick Zeitz',
		'homepage'      => ! empty( $metadata['homepage'] ) ? (string) $metadata['homepage'] : '',
		'download_link' => ! empty( $metadata['download_url'] ) ? (string) $metadata['download_url'] : '',
		'requires'      => ! empty( $metadata['requires'] ) ? (string) $metadata['requires'] : '',
		'tested'        => ! empty( $metadata['tested'] ) ? (string) $metadata['tested'] : '',
		'requires_php'  => ! empty( $metadata['requires_php'] ) ? (string) $metadata['requires_php'] : '',
		'last_updated'  => ! empty( $metadata['last_updated'] ) ? (string) $metadata['last_updated'] : '',
		'sections'      => ! empty( $metadata['sections'] ) && is_array( $metadata['sections'] )
			? $metadata['sections']
			: array(),
	);
}
add_filter( 'plugins_api', 'agent_backup_plugins_api', 20, 3 );

function agent_backup_get_check_updates_url() {
	return wp_nonce_url(
		add_query_arg(
			array(
				'action' => 'agent_backup_check_updates',
			),
			self_admin_url( 'admin-post.php' )
		),
		'agent_backup_check_updates'
	);
}

function agent_backup_handle_check_updates_action() {
	if ( ! current_user_can( 'manage_options' ) ) {
		wp_die( esc_html__( 'You are not allowed to check plugin updates.', 'agent-backup' ) );
	}

	check_admin_referer( 'agent_backup_check_updates' );

	delete_site_transient( 'update_plugins' );
	$metadata = agent_backup_fetch_update_metadata( true );
	wp_update_plugins();

	$redirect_args = array(
		'agent_backup_update_check' => '1',
	);
	if ( is_array( $metadata ) && ! empty( $metadata['version'] ) ) {
		$redirect_args['agent_backup_latest_version'] = rawurlencode( (string) $metadata['version'] );
	}

	wp_safe_redirect(
		add_query_arg(
			$redirect_args,
			self_admin_url( 'plugins.php' )
		)
	);
	exit;
}
add_action( 'admin_post_agent_backup_check_updates', 'agent_backup_handle_check_updates_action' );

function agent_backup_plugin_action_links( $actions ) {
	$check_link = sprintf(
		'<a href="%s">%s</a>',
		esc_url( agent_backup_get_check_updates_url() ),
		esc_html__( 'Check updates now', 'agent-backup' )
	);

	$updated_actions = array(
		'agent_backup_check_updates' => $check_link,
	);

	foreach ( $actions as $key => $action ) {
		$updated_actions[ $key ] = $action;
	}

	return $updated_actions;
}
add_filter( 'plugin_action_links_' . AGENT_BACKUP_BASENAME, 'agent_backup_plugin_action_links' );

function agent_backup_render_update_check_notice() {
	if ( ! is_admin() || ! current_user_can( 'manage_options' ) ) {
		return;
	}

	if ( ! isset( $_GET['agent_backup_update_check'] ) || '1' !== (string) $_GET['agent_backup_update_check'] ) {
		return;
	}

	$latest_version = '';
	if ( isset( $_GET['agent_backup_latest_version'] ) ) {
		$latest_version = sanitize_text_field( wp_unslash( $_GET['agent_backup_latest_version'] ) );
	}

	$message = __( 'Agent Backup update check completed.', 'agent-backup' );
	if ( '' !== $latest_version ) {
		$message = sprintf(
			/* translators: %s: latest version from the update feed */
			__( 'Agent Backup update check completed. Latest feed version: %s', 'agent-backup' ),
			$latest_version
		);
	}

	printf(
		'<div class="notice notice-success is-dismissible"><p>%s</p></div>',
		esc_html( $message )
	);
}
add_action( 'admin_notices', 'agent_backup_render_update_check_notice' );
