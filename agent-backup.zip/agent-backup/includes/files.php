<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! function_exists( 'agent_backup_file_sha256' ) ) {
	/**
	 * Calculate a stable file hash for on-demand payload revalidation.
	 */
	function agent_backup_file_sha256( $path ) {
		$hash = hash_file( 'sha256', $path );
		if ( false === $hash ) {
			return null;
		}
		return strtolower( $hash );
	}
}

/**
 * Iterate files with pagination and excludes.
 */
function agent_backup_paginated_files( $root, $cursor, $limit, $excludes, $include_hashes = false ) {
	$files       = array();
	$count_seen  = 0;
	$next_cursor = null;

	$flags = \FilesystemIterator::SKIP_DOTS | \FilesystemIterator::FOLLOW_SYMLINKS;
	$iter  = new \RecursiveIteratorIterator(
		new \RecursiveDirectoryIterator( $root, $flags ),
		\RecursiveIteratorIterator::SELF_FIRST
	);

	foreach ( $iter as $file ) {
		if ( $file->isDir() ) {
			continue;
		}

		$relative = ltrim( str_replace( $root, '', $file->getPathname() ), '/\\' );
		$is_excluded = false;
		foreach ( (array) $excludes as $prefix ) {
			$prefix = trim( $prefix );
			if ( '' === $prefix ) {
				continue;
			}
			if ( 0 === stripos( $relative, $prefix ) ) {
				$is_excluded = true;
				break;
			}
		}
		if ( $is_excluded ) {
			continue;
		}

		if ( $count_seen < $cursor ) {
			$count_seen++;
			continue;
		}

		$item = array(
			'path'  => str_replace( '\\', '/', $relative ),
			'size'  => (int) $file->getSize(),
			'mtime' => (int) $file->getMTime(),
		);
		if ( $include_hashes ) {
			$item['sha256'] = agent_backup_file_sha256( $file->getPathname() );
		}
		$files[] = $item;
		$count_seen++;

		if ( count( $files ) >= $limit ) {
			$next_cursor = $count_seen;
			break;
		}
	}

	return array( $files, $next_cursor, $count_seen );
}

/**
 * /files route handler.
 */
function agent_backup_route_files( WP_REST_Request $request ) {
	$settings = agent_backup_get_settings();
	$limit    = (int) $request->get_param( 'limit' );
	$cursor   = (int) $request->get_param( 'cursor' );
	$include_hashes = ! empty( $request->get_param( 'include_hashes' ) );

	if ( $limit <= 0 ) {
		$limit = $settings['default_limit'];
	}
	$limit  = min( $limit, (int) $settings['max_limit'] );
	$cursor = max( 0, $cursor );

	$root_param = $request->get_param( 'root' );
	if ( 'wp-content' !== $root_param ) {
		return new WP_Error( 'invalid_root', __( 'Only wp-content is supported', 'agent-backup' ), array( 'status' => 400 ) );
	}

	$root = realpath( WP_CONTENT_DIR );
	if ( false === $root || ! is_dir( $root ) ) {
		return new WP_Error( 'root_missing', __( 'Content root missing', 'agent-backup' ), array( 'status' => 500 ) );
	}
	$root = trailingslashit( $root );

	list( $files, $next_cursor, $count_seen ) = agent_backup_paginated_files(
		$root,
		$cursor,
		$limit,
		(array) $settings['excludes'],
		$include_hashes
	);

	return new WP_REST_Response(
		array(
			'generated_at' => gmdate( 'c' ),
			'root'         => 'wp-content',
			'count'        => $count_seen,
			'include_hashes' => $include_hashes,
			'files'        => $files,
			'next_cursor'  => $next_cursor,
		),
		200
	);
}

/**
 * /file route handler.
 */
function agent_backup_route_file( WP_REST_Request $request ) {
	$settings   = agent_backup_get_settings();
	$path_param = $request->get_param( 'path' );
	$offset     = max( 0, (int) $request->get_param( 'offset' ) );
	$length     = (int) $request->get_param( 'length' );
	$verify_hash = ! empty( $request->get_param( 'verify_hash' ) );

	if ( $length <= 0 ) {
		$length = 5 * 1024 * 1024;
	}
	$length = min( $length, (int) $settings['max_file_length'] );

	$full_path = agent_backup_validate_path( $path_param );
	if ( ! $full_path || ! is_file( $full_path ) ) {
		return new WP_Error( 'file_not_found', __( 'File not found', 'agent-backup' ), array( 'status' => 404 ) );
	}

	$size = filesize( $full_path );
	if ( $offset >= $size ) {
		return new WP_Error( 'range_invalid', __( 'Offset beyond file size', 'agent-backup' ), array( 'status' => 416 ) );
	}

	$streamer = function () use ( $full_path, $offset, $length, $size ) {
		agent_backup_prepare_stream_environment();
		$fh = fopen( $full_path, 'rb' );
		if ( ! $fh ) {
			agent_backup_log( sprintf( 'File stream open failed: %s', $full_path ) );
			return;
		}
		fseek( $fh, $offset );

		$remaining = min( $length, $size - $offset );
		$sent      = 0;
		$target    = $remaining;
		while ( $remaining > 0 && ! feof( $fh ) ) {
			$chunk_size = min( 8192, $remaining );
			$chunk      = fread( $fh, $chunk_size );
			if ( false === $chunk ) {
				$error = function_exists( 'error_get_last' ) ? error_get_last() : null;
				agent_backup_log(
					sprintf(
						'File stream fread failed: %s offset=%d sent=%d target=%d error=%s',
						$full_path,
						$offset,
						$sent,
						$target,
						is_array( $error ) && ! empty( $error['message'] ) ? $error['message'] : 'unknown'
					)
				);
				break;
			}
			$chunk_length = strlen( $chunk );
			if ( 0 === $chunk_length ) {
				agent_backup_log(
					sprintf(
						'File stream short read: %s offset=%d sent=%d target=%d remaining=%d',
						$full_path,
						$offset,
						$sent,
						$target,
						$remaining
					)
				);
				break;
			}
			$remaining -= $chunk_length;
			$sent      += $chunk_length;
			echo $chunk; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
			agent_backup_flush_stream_buffers();
		}
		fclose( $fh );
		if ( $remaining > 0 ) {
			agent_backup_log(
				sprintf(
					'File stream incomplete: %s offset=%d sent=%d target=%d remaining=%d size=%d',
					$full_path,
					$offset,
					$sent,
					$target,
					$remaining,
					$size
				)
			);
			return;
		}
		agent_backup_log(
			sprintf(
				'File stream complete: %s offset=%d bytes=%d size=%d',
				$full_path,
				$offset,
				$sent,
				$size
			)
		);
	};

	$bytes_to_send = min( $length, $size - $offset );
	$headers       = array(
		'Content-Type'   => 'application/octet-stream',
		'Accept-Ranges'  => 'bytes',
		'Content-Length' => $bytes_to_send,
		'Content-Range'  => 'bytes ' . $offset . '-' . ( $offset + $bytes_to_send - 1 ) . '/' . $size,
		'Cache-Control'  => 'no-store, no-cache, must-revalidate, max-age=0',
		'Pragma'         => 'no-cache',
		'X-Accel-Buffering' => 'no',
	);
	if ( $verify_hash ) {
		$file_hash = agent_backup_file_sha256( $full_path );
		if ( ! empty( $file_hash ) ) {
			$headers['X-Agent-File-SHA256'] = $file_hash;
		}
	}

	return new Agent_Backup_Stream_Response( $streamer, $headers, 206 );
}
