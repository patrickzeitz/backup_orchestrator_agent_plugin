<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Parse DB_HOST into host/port/socket.
 */
function agent_backup_db_host_parts( $db_host_raw ) {
	$host   = $db_host_raw;
	$port   = null;
	$socket = null;

	// If it looks like a socket path.
	if ( strpos( $db_host_raw, '/' ) === 0 ) {
		$socket = $db_host_raw;
		$host   = 'localhost';
	} elseif ( strpos( $db_host_raw, ':' ) !== false ) {
		$bits = explode( ':', $db_host_raw );
		$host = $bits[0];
		$port = isset( $bits[1] ) ? (int) $bits[1] : null;
	}

	return array(
		'host'   => $host,
		'port'   => $port,
		'socket' => $socket,
	);
}

/**
 * /db route handler.
 */
function agent_backup_has_mysqldump() {
	$path = '';
	if ( function_exists( 'shell_exec' ) ) {
		$path = trim( shell_exec( 'command -v mysqldump 2>/dev/null' ) );
	}
	return ! empty( $path );
}

function agent_backup_route_db( WP_REST_Request $request ) {
	global $wpdb;
	$gzip = (bool) $request->get_param( 'gzip' );
	$settings = agent_backup_get_settings();
	$dbg = ! empty( $settings['debug_db_log'] );

	$host_parts = agent_backup_db_host_parts( DB_HOST );

	$creds = array(
		'DB_NAME'     => DB_NAME,
		'DB_USER'     => DB_USER,
		'DB_PASSWORD' => DB_PASSWORD,
		'DB_HOST'     => $host_parts['host'],
		'DB_PORT'     => $host_parts['port'],
		'DB_SOCKET'   => $host_parts['socket'],
	);

	$cmd = null;
	if ( function_exists( 'proc_open' ) && agent_backup_has_mysqldump() ) {
		if ( $dbg ) {
			error_log( 'agent-backup db: using mysqldump' );
		}
		$cmd = sprintf(
			"mysqldump --single-transaction --quick --lock-tables=false --host=%s --user=%s --password=%s",
			escapeshellarg( $creds['DB_HOST'] ),
			escapeshellarg( $creds['DB_USER'] ),
			escapeshellarg( $creds['DB_PASSWORD'] )
		);
		if ( $creds['DB_SOCKET'] ) {
			$cmd .= ' --socket=' . escapeshellarg( $creds['DB_SOCKET'] );
		} elseif ( $creds['DB_PORT'] ) {
			$cmd .= ' --port=' . (int) $creds['DB_PORT'];
		}
		$cmd .= ' ' . escapeshellarg( $creds['DB_NAME'] );
		if ( $gzip ) {
			$cmd .= ' | gzip -c';
		}
	}

	if ( $cmd ) {
		if ( ! function_exists( 'wp_tempnam' ) ) {
			require_once ABSPATH . 'wp-admin/includes/file.php';
		}
		$tmp = function_exists( 'wp_tempnam' ) ? wp_tempnam( 'agent-backup-mysqldump' ) : tempnam( sys_get_temp_dir(), 'agent-backup-mysqldump' );
		$stderr_buf = '';
		if ( $tmp ) {
			$spec = array(
				0 => array( 'pipe', 'r' ),
				1 => array( 'pipe', 'w' ),
				2 => array( 'pipe', 'w' ),
			);
			$process = proc_open( $cmd, $spec, $pipes );
			if ( is_resource( $process ) ) {
				fclose( $pipes[0] );
				$out = fopen( $tmp, 'wb' );
				if ( $out ) {
					while ( ! feof( $pipes[1] ) ) {
						$chunk = fread( $pipes[1], 8192 );
						if ( false === $chunk ) {
							break;
						}
						fwrite( $out, $chunk );
					}
					fclose( $out );
				}
				$stderr_buf = stream_get_contents( $pipes[2] );
				fclose( $pipes[1] );
				fclose( $pipes[2] );
				$exit = proc_close( $process );
				$size = filesize( $tmp );

				if ( $dbg ) {
					error_log( 'agent-backup db: mysqldump exit=' . $exit . ' size=' . (int) $size . ' stderr_len=' . strlen( (string) $stderr_buf ) );
					if ( $stderr_buf ) {
						error_log( 'agent-backup db stderr: ' . $stderr_buf );
					}
				}

				if ( 0 === $exit && $size > 0 ) {
					$headers = array(
						'Content-Type'        => $gzip ? 'application/gzip' : 'application/sql',
						'Content-Disposition' => 'attachment; filename="db_dump.sql' . ( $gzip ? '.gz' : '' ) . '"',
						'Content-Length'      => $size,
					);
					agent_backup_send_stream_now(
						function () use ( $tmp ) {
							$fh = fopen( $tmp, 'rb' );
							if ( $fh ) {
								while ( ! feof( $fh ) ) {
									$chunk = fread( $fh, 8192 );
									if ( false === $chunk ) {
										break;
									}
									echo $chunk; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
								}
								fclose( $fh );
							}
							@unlink( $tmp );
						},
						$headers,
						200
					);
					return null; // streamed
				}
			}
			@unlink( $tmp );
		}
		// If mysqldump produced nothing, fall through to fallback exporter.
	}

	$tables = $wpdb->get_col( 'SHOW TABLES' );
	if ( empty( $tables ) ) {
		$fallback_tables = $wpdb->tables( 'all' );
		if ( is_array( $fallback_tables ) && ! empty( $fallback_tables ) ) {
			$tables = array_values( $fallback_tables );
		}
	}
	if ( empty( $tables ) ) {
		if ( $dbg ) {
			error_log( 'agent-backup db: no tables found' );
		}
		return new WP_Error( 'db_empty', __( 'No tables found', 'agent-backup' ), array( 'status' => 500 ) );
	}

	// Fallback: write dump to temp file, then stream it.
	$streamer = function () use ( $tables, $wpdb, $gzip, $settings ) {
		if ( ! function_exists( 'wp_tempnam' ) ) {
			require_once ABSPATH . 'wp-admin/includes/file.php';
		}

		if ( function_exists( 'ignore_user_abort' ) ) {
			ignore_user_abort( true );
		}
		if ( function_exists( 'set_time_limit' ) ) {
			@set_time_limit( 0 );
		}

		$tmp = function_exists( 'wp_tempnam' ) ? wp_tempnam( 'agent-backup-db' ) : tempnam( sys_get_temp_dir(), 'agent-backup-db' );
		if ( ! $tmp ) {
			http_response_code( 500 );
			return;
		}

		$writer = null;
		$gz     = null;

		if ( $gzip && function_exists( 'gzopen' ) ) {
			$gz = gzopen( $tmp, 'wb' );
			if ( $gz ) {
				$writer = $gz;
			}
		}

		if ( ! $writer ) {
			$writer = fopen( $tmp, 'wb' );
		}

		if ( ! $writer ) {
			http_response_code( 500 );
			@unlink( $tmp );
			return;
		}

		$write = function ( $string ) use ( $writer, $gz ) {
			if ( '' === $string ) {
				return;
			}
			if ( $gz ) {
				gzwrite( $writer, $string );
			} else {
				fwrite( $writer, $string );
			}
		};

		// Header to avoid empty output and mark source.
		$write( "-- Agent Backup SQL dump\n" );
		$write( "-- Generated at: " . gmdate( 'c' ) . "\n" );
		$write( "-- Tables: " . count( $tables ) . "\n\n" );

		foreach ( $tables as $table ) {
			$create = $wpdb->get_row( "SHOW CREATE TABLE `{$table}`", ARRAY_N );
			if ( $create ) {
				$write( "DROP TABLE IF EXISTS `{$table}`;\n" );
				$write( $create[1] . ";\n\n" );
			}

			$offset = 0;
			$limit  = 500;
			while ( true ) {
				$rows = $wpdb->get_results( $wpdb->prepare( "SELECT * FROM `{$table}` LIMIT %d OFFSET %d", $limit, $offset ), ARRAY_A );
				if ( empty( $rows ) ) {
					break;
				}
				foreach ( $rows as $row ) {
					$values = array_map(
						static function ( $value ) use ( $wpdb ) {
							if ( null === $value ) {
								return 'NULL';
							}
							return "'" . esc_sql( $value ) . "'";
						},
						$row
					);
					$columns = array_map(
						static function ( $col ) {
							return '`' . str_replace( '`', '``', $col ) . '`';
						},
						array_keys( $row )
					);
					$write( 'INSERT INTO `' . $table . '` (' . implode( ',', $columns ) . ') VALUES (' . implode( ',', $values ) . ");\n" );
				}
				$offset += $limit;
			}
			$write( "\n" );
		}

		if ( $gz ) {
			gzclose( $writer );
		} else {
			fclose( $writer );
		}

		// Stream file content and clean up.
		$read_handle = fopen( $tmp, 'rb' );
		if ( ! $read_handle ) {
			http_response_code( 500 );
			@unlink( $tmp );
			return;
		}
		$size = filesize( $tmp );
		if ( $size <= 0 ) {
			fclose( $read_handle );
			@unlink( $tmp );
			http_response_code( 500 );
			echo 'Empty dump'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
			return;
		}

		if ( ! empty( $settings['debug_db_log'] ) ) {
			error_log( 'agent-backup db: fallback dump size bytes=' . $size . ' gzip=' . ( $gzip ? '1' : '0' ) . ' tables=' . count( $tables ) );
		}

		$headers = array(
			'Content-Type'        => $gzip ? 'application/gzip' : 'application/sql',
			'Content-Disposition' => 'attachment; filename="db_dump_fallback.sql' . ( $gzip ? '.gz' : '' ) . '"',
			'Content-Length'      => $size,
		);

		agent_backup_send_stream_now(
			function () use ( $read_handle, $tmp ) {
				while ( ! feof( $read_handle ) ) {
					$chunk = fread( $read_handle, 8192 );
					if ( false === $chunk ) {
						break;
					}
					echo $chunk; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
				}
				fclose( $read_handle );
				@unlink( $tmp );
			},
			$headers,
			200
		);
	};

	return new Agent_Backup_Stream_Response( $streamer, array(), 200 );
}
