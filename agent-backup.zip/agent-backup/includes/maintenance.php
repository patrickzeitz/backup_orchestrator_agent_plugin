<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Build a maintenance inventory payload for the orchestrator.
 */
function agent_backup_get_maintenance_inventory( $force = false ) {
	require_once ABSPATH . 'wp-admin/includes/plugin.php';
	require_once ABSPATH . 'wp-admin/includes/update.php';
	require_once ABSPATH . 'wp-admin/includes/theme.php';

	if ( $force ) {
		delete_site_transient( 'update_core' );
		delete_site_transient( 'update_plugins' );
		delete_site_transient( 'update_themes' );
	}

	wp_version_check();
	wp_update_plugins();
	wp_update_themes();

	$current_version = (string) get_bloginfo( 'version' );
	$core_updates = get_core_updates(
		array(
			'available' => true,
			'dismissed' => false,
		)
	);
	$core_update  = null;
	if ( is_array( $core_updates ) && ! empty( $core_updates ) ) {
		$candidate = $core_updates[0];
		if ( is_object( $candidate ) && ! empty( $candidate->current ) ) {
			$target_version   = (string) $candidate->current;
			$has_real_upgrade = '' !== $target_version && version_compare( $target_version, $current_version, '>' );
			$core_update = array(
				'update_available' => $has_real_upgrade,
				'current_version'  => $current_version,
				'update_version'   => $has_real_upgrade ? $target_version : '',
				'locale'           => isset( $candidate->locale ) ? (string) $candidate->locale : '',
				'response'         => isset( $candidate->response ) ? (string) $candidate->response : '',
				'package_available'=> $has_real_upgrade && ! empty( $candidate->download ),
			);
		}
	}
	if ( null === $core_update ) {
		$core_update = array(
			'update_available' => false,
			'current_version'  => $current_version,
			'update_version'   => '',
			'locale'           => '',
			'response'         => 'latest',
			'package_available'=> false,
		);
	}

	$active_plugins  = get_option( 'active_plugins', array() );
	if ( ! is_array( $active_plugins ) ) {
		$active_plugins = array();
	}
	$plugin_updates  = get_plugin_updates();
	$plugins         = array();
	foreach ( get_plugins() as $plugin_file => $plugin_data ) {
		$update = isset( $plugin_updates[ $plugin_file ] ) ? $plugin_updates[ $plugin_file ]->update : null;
		$slug   = dirname( $plugin_file );
		$site_active    = in_array( $plugin_file, $active_plugins, true );
		$network_active = is_plugin_active_for_network( $plugin_file );
		if ( '.' === $slug || '' === $slug ) {
			$slug = basename( $plugin_file, '.php' );
		}
		$plugins[] = array(
			'file'             => $plugin_file,
			'slug'             => $slug,
			'name'             => isset( $plugin_data['Name'] ) ? (string) $plugin_data['Name'] : $plugin_file,
			'version'          => isset( $plugin_data['Version'] ) ? (string) $plugin_data['Version'] : '',
			'active'           => $site_active || $network_active,
			'site_active'      => $site_active,
			'network_active'   => $network_active,
			'update_available' => is_object( $update ) && ! empty( $update->new_version ),
			'update_version'   => is_object( $update ) && ! empty( $update->new_version ) ? (string) $update->new_version : '',
		);
	}
	usort(
		$plugins,
		static function ( $left, $right ) {
			return strcasecmp( $left['name'], $right['name'] );
		}
	);

	$stylesheet     = get_stylesheet();
	$template       = get_template();
	$theme_updates  = get_theme_updates();
	$themes         = array();
	foreach ( wp_get_themes() as $theme_stylesheet => $theme ) {
		$update = isset( $theme_updates[ $theme_stylesheet ] ) ? $theme_updates[ $theme_stylesheet ]->update : null;
		$themes[] = array(
			'stylesheet'       => $theme_stylesheet,
			'name'             => (string) $theme->get( 'Name' ),
			'version'          => (string) $theme->get( 'Version' ),
			'active'           => $theme_stylesheet === $stylesheet || $theme_stylesheet === $template,
			'template'         => (string) $theme->get_template(),
			'update_available' => is_array( $update ) && ! empty( $update['new_version'] ),
			'update_version'   => is_array( $update ) && ! empty( $update['new_version'] ) ? (string) $update['new_version'] : '',
		);
	}
	usort(
		$themes,
		static function ( $left, $right ) {
			return strcasecmp( $left['name'], $right['name'] );
		}
	);

	return array(
		'checked_at'         => gmdate( 'c' ),
		'wordpress_version'  => get_bloginfo( 'version' ),
		'php_version'        => PHP_VERSION,
		'capability_versions' => array(
			'guarded_plugin_update' => AGENT_BACKUP_RECOVERY_CAPABILITY_VERSION,
		),
		'core'               => $core_update,
		'plugins'            => $plugins,
		'themes'             => $themes,
		'counts'             => array(
			'plugins_total'        => count( $plugins ),
			'plugins_with_updates' => count(
				array_filter(
					$plugins,
					static function ( $plugin ) {
						return ! empty( $plugin['update_available'] );
					}
				)
			),
			'themes_total'         => count( $themes ),
			'themes_with_updates'  => count(
				array_filter(
					$themes,
					static function ( $theme ) {
						return ! empty( $theme['update_available'] );
					}
				)
			),
		),
	);
}

/**
 * REST route callback for maintenance inventory.
 */
function agent_backup_route_maintenance( WP_REST_Request $request ) {
	$force = (bool) $request->get_param( 'force' );

	return new WP_REST_Response(
		array(
			'ok'            => true,
			'ts'            => time(),
			'site'          => home_url(),
			'agent_version' => AGENT_BACKUP_VERSION,
			'maintenance'   => agent_backup_get_maintenance_inventory( $force ),
		),
		200
	);
}

/**
 * REST route callback for maintenance actions.
 */
function agent_backup_route_maintenance_action( WP_REST_Request $request ) {
	$action = sanitize_key( (string) $request->get_param( 'action' ) );

	return new WP_REST_Response( agent_backup_build_maintenance_action_payload( $action, $request ), 200 );
}

/**
 * admin-ajax fallback for hosts that block REST write actions.
 */
function agent_backup_ajax_maintenance_action() {
	$action = sanitize_key( (string) ( isset( $_POST['agent_action'] ) ? wp_unslash( $_POST['agent_action'] ) : '' ) );
	$auth = agent_backup_authenticate_ajax_request();
	if ( is_wp_error( $auth ) ) {
		$status = 500;
		$data   = $auth->get_error_data();
		if ( is_array( $data ) && isset( $data['status'] ) ) {
			$status = (int) $data['status'];
		}
		if ( 'plugin_update_guarded' !== $action ) {
			agent_backup_log(
				sprintf(
					'AJAX maintenance auth failed %d %s: %s',
					$status,
					$auth->get_error_code(),
					$auth->get_error_message()
				)
			);
		}
		wp_send_json(
			array(
				'code'    => $auth->get_error_code(),
				'message' => $auth->get_error_message(),
				'data'    => array(
					'status' => $status,
				),
			),
			$status
		);
	}

	$params = array(
		'action'                  => $action,
		'plugin'                  => isset( $_POST['plugin'] ) ? wp_unslash( $_POST['plugin'] ) : '',
		'theme'                   => isset( $_POST['theme'] ) ? wp_unslash( $_POST['theme'] ) : '',
		'transaction_id'          => isset( $_POST['transaction_id'] ) ? wp_unslash( $_POST['transaction_id'] ) : '',
		'expected_from_version'   => isset( $_POST['expected_from_version'] ) ? wp_unslash( $_POST['expected_from_version'] ) : '',
		'expected_target_version' => isset( $_POST['expected_target_version'] ) ? wp_unslash( $_POST['expected_target_version'] ) : '',
		'capability_version'      => isset( $_POST['capability_version'] ) ? wp_unslash( $_POST['capability_version'] ) : '',
	);

	if ( 'plugin_update_guarded' !== $action ) {
		agent_backup_log( sprintf( 'AJAX maintenance action accepted: %s', $action ) );
	}
	wp_send_json( agent_backup_build_maintenance_action_payload( $action, $params ), 200 );
}
add_action( 'wp_ajax_agent_backup_maintenance_action', 'agent_backup_ajax_maintenance_action' );
add_action( 'wp_ajax_nopriv_agent_backup_maintenance_action', 'agent_backup_ajax_maintenance_action' );

/**
 * Build a standard maintenance action response payload.
 */
function agent_backup_build_maintenance_action_payload( $action, $request ) {
	try {
		$result = agent_backup_execute_maintenance_action( $action, $request );
	} catch ( Throwable $error ) {
		if ( 'plugin_update_guarded' !== $action ) {
			agent_backup_log( sprintf( 'Maintenance action crashed: %s', $error->getMessage() ) );
		}
		$result = array(
			'ok'            => false,
			'status'        => 'failed',
			'error_code'    => 'maintenance_action_crash',
			'error_message' => $error->getMessage(),
			'messages'      => array(),
			'from_version'  => '',
			'to_version'    => '',
		);
	}

	$payload = array(
		'ok'            => ! empty( $result['ok'] ),
		'ts'            => time(),
		'site'          => home_url(),
		'agent_version' => AGENT_BACKUP_VERSION,
		'result'        => $result,
	);
	$payload['maintenance'] = 'plugin_update_guarded' === $action ? null : agent_backup_get_maintenance_inventory( true );
	return $payload;
}

/**
 * Execute a maintenance action via WordPress core upgraders.
 */
function agent_backup_execute_maintenance_action( $action, $request ) {
	agent_backup_require_maintenance_upgrader_dependencies();

	switch ( $action ) {
		case 'refresh_update_checks':
			return agent_backup_execute_refresh_update_checks();
		case 'core_update':
			return agent_backup_execute_core_update();
		case 'plugin_update':
			return agent_backup_execute_plugin_update( sanitize_text_field( (string) agent_backup_maintenance_request_param( $request, 'plugin' ) ) );
		case 'plugin_update_guarded':
			return agent_backup_execute_guarded_plugin_update(
				(string) agent_backup_maintenance_request_param( $request, 'plugin' ),
				(string) agent_backup_maintenance_request_param( $request, 'transaction_id' ),
				(string) agent_backup_maintenance_request_param( $request, 'expected_from_version' ),
				(string) agent_backup_maintenance_request_param( $request, 'expected_target_version' ),
				(int) agent_backup_maintenance_request_param( $request, 'capability_version' )
			);
		case 'plugin_update_all':
			return agent_backup_execute_plugin_update_all();
		case 'theme_update':
			return agent_backup_execute_theme_update( sanitize_text_field( (string) agent_backup_maintenance_request_param( $request, 'theme' ) ) );
		case 'theme_update_all':
			return agent_backup_execute_theme_update_all();
		default:
			return agent_backup_failed_maintenance_result(
				'invalid_action',
				'Unsupported maintenance action.'
			);
	}
}

/**
 * Read maintenance parameters from REST requests or the admin-ajax fallback array.
 */
function agent_backup_maintenance_request_param( $request, $key ) {
	if ( $request instanceof WP_REST_Request ) {
		return $request->get_param( $key );
	}
	if ( is_array( $request ) && array_key_exists( $key, $request ) ) {
		return $request[ $key ];
	}
	return '';
}

/**
 * Refresh core, plugin, and theme update caches without installing anything.
 */
function agent_backup_execute_refresh_update_checks() {
	delete_site_transient( 'update_core' );
	delete_site_transient( 'update_plugins' );
	delete_site_transient( 'update_themes' );

	wp_version_check();
	wp_update_plugins();
	wp_update_themes();

	$core_updates   = get_core_updates( array( 'dismissed' => false ) );
	$plugin_updates = get_site_transient( 'update_plugins' );
	$theme_updates  = get_site_transient( 'update_themes' );

	$core_count   = is_array( $core_updates ) ? count( $core_updates ) : 0;
	$plugin_count = ( is_object( $plugin_updates ) && ! empty( $plugin_updates->response ) && is_array( $plugin_updates->response ) )
		? count( $plugin_updates->response )
		: 0;
	$theme_count = ( is_object( $theme_updates ) && ! empty( $theme_updates->response ) && is_array( $theme_updates->response ) )
		? count( $theme_updates->response )
		: 0;

	return agent_backup_ok_maintenance_result(
		'succeeded',
		'',
		'',
		array(
			sprintf(
				'WordPress update checks refreshed. Core: %d, plugins: %d, themes: %d.',
				$core_count,
				$plugin_count,
				$theme_count
			),
		)
	);
}

/**
 * Load the upgrader classes needed for maintenance actions.
 */
function agent_backup_require_maintenance_upgrader_dependencies() {
	require_once ABSPATH . 'wp-admin/includes/file.php';
	require_once ABSPATH . 'wp-admin/includes/plugin.php';
	require_once ABSPATH . 'wp-admin/includes/update.php';
	require_once ABSPATH . 'wp-admin/includes/theme.php';
	require_once ABSPATH . 'wp-admin/includes/class-wp-upgrader.php';
	require_once ABSPATH . 'wp-admin/includes/class-automatic-upgrader-skin.php';
	require_once ABSPATH . 'wp-admin/includes/class-plugin-upgrader.php';
	require_once ABSPATH . 'wp-admin/includes/class-theme-upgrader.php';
	require_once ABSPATH . 'wp-admin/includes/class-core-upgrader.php';
}

/**
 * Update a single plugin.
 */
function agent_backup_execute_plugin_update( $plugin_file ) {
	if ( '' === $plugin_file ) {
		return agent_backup_failed_maintenance_result( 'missing_plugin', 'No plugin identifier was supplied.' );
	}

	delete_site_transient( 'update_plugins' );
	wp_update_plugins();

	$plugins = get_plugins();
	if ( ! isset( $plugins[ $plugin_file ] ) ) {
		return agent_backup_failed_maintenance_result( 'unknown_plugin', 'The requested plugin is not installed.' );
	}

	$before_version = isset( $plugins[ $plugin_file ]['Version'] ) ? (string) $plugins[ $plugin_file ]['Version'] : '';
	$was_network_active = is_plugin_active_for_network( $plugin_file );
	$was_active         = is_plugin_active( $plugin_file );
	$current        = get_site_transient( 'update_plugins' );
	if ( ! isset( $current->response[ $plugin_file ] ) ) {
		return agent_backup_ok_maintenance_result(
			'noop',
			$before_version,
			$before_version,
			array( 'The plugin is already up to date.' )
		);
	}

	$skin     = new Automatic_Upgrader_Skin();
	$upgrader = new Plugin_Upgrader( $skin );
	$result   = $upgrader->upgrade( $plugin_file, array( 'clear_update_cache' => true ) );
	$messages = agent_backup_maintenance_messages( $skin );

	if ( is_wp_error( $result ) ) {
		return agent_backup_failed_maintenance_result(
			$result->get_error_code(),
			$result->get_error_message(),
			$before_version,
			'',
			$messages
		);
	}

	if ( false === $result ) {
		return agent_backup_failed_maintenance_result(
			'filesystem_access_failed',
			agent_backup_filesystem_update_error_message(),
			$before_version,
			'',
			$messages
		);
	}

	wp_clean_plugins_cache( true );
	delete_site_transient( 'update_plugins' );
	wp_update_plugins();
	$plugins       = get_plugins();
	$after_version = isset( $plugins[ $plugin_file ]['Version'] ) ? (string) $plugins[ $plugin_file ]['Version'] : '';
	$reactivation  = agent_backup_restore_plugin_activation_state( $plugin_file, $was_active, $was_network_active );
	if ( is_wp_error( $reactivation ) ) {
		$messages[] = sprintf(
			'Plugin update succeeded, but reactivation failed: %s',
			$reactivation->get_error_message()
		);
		return array(
			'ok'            => true,
			'status'        => 'warning',
			'error_code'    => 'plugin_reactivation_failed',
			'error_message' => 'The plugin update succeeded, but the plugin could not be reactivated automatically.',
			'messages'      => array_values( $messages ),
			'from_version'  => (string) $before_version,
			'to_version'    => (string) $after_version,
		);
	}

	return agent_backup_ok_maintenance_result(
		'succeeded',
		$before_version,
		$after_version,
		$messages
	);
}

/**
 * Read one activation option directly from its database table without filters.
 *
 * The guarded updater must compare the persisted bytes, not values that plugins
 * can rewrite through option filters.
 */
function agent_backup_read_raw_activation_option( $option_name, $network_option = false ) {
	global $wpdb;

	if ( $network_option && is_multisite() ) {
		$query = $wpdb->prepare(
			"SELECT meta_value AS raw_value FROM {$wpdb->sitemeta} WHERE site_id = %d AND meta_key = %s LIMIT 1",
			get_current_network_id(),
			$option_name
		);
	} else {
		$query = $wpdb->prepare(
			"SELECT option_value AS raw_value FROM {$wpdb->options} WHERE option_name = %s LIMIT 1",
			$option_name
		);
	}

	$previous_suppress_errors = $wpdb->suppress_errors( true );
	$wpdb->last_error         = '';
	$row                      = $wpdb->get_row( $query, ARRAY_A );
	$read_ok                  = '' === (string) $wpdb->last_error;
	$wpdb->suppress_errors( $previous_suppress_errors );
	if ( ! $read_ok ) {
		return array(
			'read_ok' => false,
			'exists'  => false,
			'bytes'   => '',
			'value'   => array(),
		);
	}
	if ( ! is_array( $row ) || ! array_key_exists( 'raw_value', $row ) ) {
		return array(
			'read_ok' => true,
			'exists'  => false,
			'bytes'   => '',
			'value'   => array(),
		);
	}

	$bytes = (string) $row['raw_value'];
	return array(
		'read_ok' => true,
		'exists'  => true,
		'bytes'   => $bytes,
		'value'   => maybe_unserialize( $bytes ),
	);
}

/**
 * Capture both persisted WordPress activation options without modifying them.
 */
function agent_backup_plugin_activation_options_snapshot( $plugin_file ) {
	$active_option  = agent_backup_read_raw_activation_option( 'active_plugins' );
	$network_option = agent_backup_read_raw_activation_option( 'active_sitewide_plugins', true );
	$active_plugins  = $active_option['value'];
	$network_plugins = $network_option['value'];

	return array(
		'read_ok'                => $active_option['read_ok'] && $network_option['read_ok'],
		'active_plugins_exists'  => $active_option['exists'],
		'active_plugins_bytes'   => $active_option['bytes'],
		'network_plugins_exists' => $network_option['exists'],
		'network_plugins_bytes'  => $network_option['bytes'],
		'site_active'            => is_array( $active_plugins ) && in_array( $plugin_file, $active_plugins, true ),
		'network_active'         => is_array( $network_plugins ) && array_key_exists( $plugin_file, $network_plugins ),
	);
}

/**
 * Normalize guarded failures without hiding whether the upgrader already ran.
 */
function agent_backup_guarded_plugin_update_failure( $error_code, $error_message, $transaction_id, $plugin_file, $expected_from_version, $expected_target_version, $capability_version, $observed_version = '', $messages = array(), $upgrader_started = false, $recovery = null ) {
	$result = agent_backup_failed_maintenance_result(
		$error_code,
		$error_message,
		$expected_from_version,
		$observed_version,
		$messages
	);
	$result['transaction_id']          = (string) $transaction_id;
	$result['plugin']                  = (string) $plugin_file;
	$result['capability_version']      = (int) $capability_version;
	$result['expected_from_version']   = (string) $expected_from_version;
	$result['expected_target_version'] = (string) $expected_target_version;
	$result['upgrader_started']        = (bool) $upgrader_started;
	$result['mutation_started']        = (bool) $upgrader_started;
	$result['requires_health_check']   = (bool) $upgrader_started;
	if ( is_array( $recovery ) ) {
		$result['recovery'] = $recovery;
	}
	return $result;
}

/**
 * Update one exactly pinned plugin while a matching filesystem recovery state is armed.
 *
 * The updater deliberately runs in WordPress cron mode so Plugin_Upgrader does not
 * persistently remove the plugin from either activation option during the upgrade.
 */
function agent_backup_execute_guarded_plugin_update( $plugin_file, $transaction_id, $expected_from_version, $expected_target_version, $capability_version ) {
	if ( AGENT_BACKUP_RECOVERY_CAPABILITY_VERSION !== (int) $capability_version ) {
		return agent_backup_guarded_plugin_update_failure( 'unsupported_capability_version', 'Guarded update capability version is not supported.', $transaction_id, $plugin_file, $expected_from_version, $expected_target_version, $capability_version );
	}
	if ( ! agent_backup_recovery_transaction_id_is_safe( $transaction_id ) ) {
		return agent_backup_guarded_plugin_update_failure( 'invalid_transaction_id', 'Transaction identifier is invalid.', $transaction_id, $plugin_file, $expected_from_version, $expected_target_version, $capability_version );
	}
	if ( ! agent_backup_recovery_plugin_basename_is_safe( $plugin_file ) ) {
		return agent_backup_guarded_plugin_update_failure( 'invalid_plugin', 'Plugin must be an exact, safe plugin basename.', $transaction_id, $plugin_file, $expected_from_version, $expected_target_version, $capability_version );
	}
	if ( defined( 'AGENT_BACKUP_BASENAME' ) && hash_equals( AGENT_BACKUP_BASENAME, $plugin_file ) ) {
		return agent_backup_guarded_plugin_update_failure( 'agent_plugin_not_allowed', 'The Agent Backup plugin cannot update itself through guarded maintenance.', $transaction_id, $plugin_file, $expected_from_version, $expected_target_version, $capability_version );
	}
	if ( ! agent_backup_recovery_version_is_safe( $expected_from_version ) || ! agent_backup_recovery_version_is_safe( $expected_target_version ) ) {
		return agent_backup_guarded_plugin_update_failure( 'invalid_version_contract', 'Expected plugin versions are invalid.', $transaction_id, $plugin_file, $expected_from_version, $expected_target_version, $capability_version );
	}

	$guard = agent_backup_recovery_guard_info();
	if ( empty( $guard['current'] ) ) {
		return agent_backup_guarded_plugin_update_failure( 'guard_not_current', 'The current recovery guard is not installed.', $transaction_id, $plugin_file, $expected_from_version, $expected_target_version, $capability_version );
	}
	$quarantine = agent_backup_recovery_read_state( 'quarantine' );
	if ( 'invalid' === $quarantine['status'] ) {
		return agent_backup_guarded_plugin_update_failure( 'quarantine_state_invalid', $quarantine['error'], $transaction_id, $plugin_file, $expected_from_version, $expected_target_version, $capability_version );
	}
	if ( 'valid' === $quarantine['status'] ) {
		return agent_backup_guarded_plugin_update_failure( 'plugin_already_quarantined', 'A quarantined plugin cannot be updated automatically.', $transaction_id, $plugin_file, $expected_from_version, $expected_target_version, $capability_version );
	}

	$armed = agent_backup_recovery_read_state( 'armed' );
	if ( 'valid' !== $armed['status'] ) {
		$error = 'invalid' === $armed['status'] ? $armed['error'] : 'No recovery transaction is armed.';
		return agent_backup_guarded_plugin_update_failure( 'recovery_not_armed', $error, $transaction_id, $plugin_file, $expected_from_version, $expected_target_version, $capability_version );
	}
	if ( (int) $armed['state']['expires_at'] < time() ) {
		return agent_backup_guarded_plugin_update_failure( 'recovery_state_expired', 'The armed recovery transaction has expired.', $transaction_id, $plugin_file, $expected_from_version, $expected_target_version, $capability_version );
	}
	if ( ! agent_backup_recovery_state_matches_update( $armed['state'], $transaction_id, $plugin_file, $expected_from_version, $expected_target_version, $capability_version ) ) {
		return agent_backup_guarded_plugin_update_failure( 'recovery_contract_mismatch', 'The armed recovery state does not match the guarded update request.', $transaction_id, $plugin_file, $expected_from_version, $expected_target_version, $capability_version );
	}

	$plugins = get_plugins();
	if ( ! array_key_exists( $plugin_file, $plugins ) ) {
		return agent_backup_guarded_plugin_update_failure( 'unknown_plugin', 'The exact plugin basename is not installed.', $transaction_id, $plugin_file, $expected_from_version, $expected_target_version, $capability_version );
	}
	$installed_version = isset( $plugins[ $plugin_file ]['Version'] ) ? (string) $plugins[ $plugin_file ]['Version'] : '';
	if ( ! hash_equals( $expected_from_version, $installed_version ) ) {
		return agent_backup_guarded_plugin_update_failure( 'installed_version_drift', 'Installed plugin version no longer matches the guarded update contract.', $transaction_id, $plugin_file, $expected_from_version, $expected_target_version, $capability_version, $installed_version );
	}

	$activation_before = agent_backup_plugin_activation_options_snapshot( $plugin_file );
	if ( empty( $activation_before['read_ok'] ) ) {
		return agent_backup_guarded_plugin_update_failure( 'activation_options_read_failed', 'WordPress activation options could not be read directly before the guarded update.', $transaction_id, $plugin_file, $expected_from_version, $expected_target_version, $capability_version, $installed_version );
	}
	if ( ! $activation_before['site_active'] && ! $activation_before['network_active'] ) {
		return agent_backup_guarded_plugin_update_failure( 'plugin_activation_drift', 'The armed plugin is no longer active.', $transaction_id, $plugin_file, $expected_from_version, $expected_target_version, $capability_version, $installed_version );
	}

	$current = get_site_transient( 'update_plugins' );
	if ( ! is_object( $current ) || ! isset( $current->checked ) || ! is_array( $current->checked ) || ! array_key_exists( $plugin_file, $current->checked ) ) {
		return agent_backup_guarded_plugin_update_failure( 'update_offer_unavailable', 'The existing plugin update check does not contain the exact plugin.', $transaction_id, $plugin_file, $expected_from_version, $expected_target_version, $capability_version, $installed_version );
	}
	$checked_version = (string) $current->checked[ $plugin_file ];
	if ( ! hash_equals( $expected_from_version, $checked_version ) ) {
		return agent_backup_guarded_plugin_update_failure( 'update_check_version_drift', 'The update offer was checked against a different installed version.', $transaction_id, $plugin_file, $expected_from_version, $expected_target_version, $capability_version, $installed_version );
	}
	if ( ! isset( $current->response ) || ! is_array( $current->response ) || ! isset( $current->response[ $plugin_file ] ) || ! is_object( $current->response[ $plugin_file ] ) ) {
		return agent_backup_guarded_plugin_update_failure( 'update_offer_unavailable', 'The exact plugin update offer is unavailable.', $transaction_id, $plugin_file, $expected_from_version, $expected_target_version, $capability_version, $installed_version );
	}
	$offer           = $current->response[ $plugin_file ];
	$offered_version = isset( $offer->new_version ) ? (string) $offer->new_version : '';
	if ( ! hash_equals( $expected_target_version, $offered_version ) ) {
		return agent_backup_guarded_plugin_update_failure( 'update_target_version_drift', 'Offered plugin version no longer matches the guarded update contract.', $transaction_id, $plugin_file, $expected_from_version, $expected_target_version, $capability_version, $installed_version );
	}
	if ( ! isset( $offer->package ) || '' === trim( (string) $offer->package ) ) {
		return agent_backup_guarded_plugin_update_failure( 'update_package_unavailable', 'The exact plugin update offer has no installable package.', $transaction_id, $plugin_file, $expected_from_version, $expected_target_version, $capability_version, $installed_version );
	}
	if ( (int) $armed['state']['expires_at'] < time() ) {
		return agent_backup_guarded_plugin_update_failure( 'recovery_state_expired', 'The armed recovery transaction expired during preflight.', $transaction_id, $plugin_file, $expected_from_version, $expected_target_version, $capability_version, $installed_version );
	}

	if ( defined( 'DOING_CRON' ) && ! DOING_CRON ) {
		return agent_backup_guarded_plugin_update_failure( 'cron_mode_unavailable', 'WordPress cron mode is explicitly disabled for this request.', $transaction_id, $plugin_file, $expected_from_version, $expected_target_version, $capability_version, $installed_version );
	}
	if ( ! defined( 'DOING_CRON' ) ) {
		define( 'DOING_CRON', true );
	}
	if ( ! wp_doing_cron() ) {
		return agent_backup_guarded_plugin_update_failure( 'cron_mode_unavailable', 'WordPress did not enter the required cron update mode.', $transaction_id, $plugin_file, $expected_from_version, $expected_target_version, $capability_version, $installed_version );
	}

	$skin     = new Automatic_Upgrader_Skin();
	$upgrader = new Plugin_Upgrader( $skin );
	$result   = $upgrader->upgrade( $plugin_file, array( 'clear_update_cache' => true ) );
	$messages = agent_backup_maintenance_messages( $skin );
	if ( is_wp_error( $result ) ) {
		return agent_backup_guarded_plugin_update_failure( $result->get_error_code(), $result->get_error_message(), $transaction_id, $plugin_file, $expected_from_version, $expected_target_version, $capability_version, '', $messages, true );
	}
	if ( false === $result ) {
		return agent_backup_guarded_plugin_update_failure( 'filesystem_access_failed', agent_backup_filesystem_update_error_message(), $transaction_id, $plugin_file, $expected_from_version, $expected_target_version, $capability_version, '', $messages, true );
	}

	wp_clean_plugins_cache( false );
	$plugins_after    = get_plugins();
	$after_version    = isset( $plugins_after[ $plugin_file ]['Version'] ) ? (string) $plugins_after[ $plugin_file ]['Version'] : '';
	$activation_after = agent_backup_plugin_activation_options_snapshot( $plugin_file );
	if ( ! hash_equals( $expected_target_version, $after_version ) ) {
		return agent_backup_guarded_plugin_update_failure( 'target_version_postcheck_failed', 'Installed plugin version does not match the pinned target after the upgrader.', $transaction_id, $plugin_file, $expected_from_version, $expected_target_version, $capability_version, $after_version, $messages, true );
	}
	if ( empty( $activation_after['read_ok'] ) ) {
		return agent_backup_guarded_plugin_update_failure( 'activation_options_read_failed', 'WordPress activation options could not be read directly after the guarded update.', $transaction_id, $plugin_file, $expected_from_version, $expected_target_version, $capability_version, $after_version, $messages, true );
	}
	if (
		$activation_before['active_plugins_exists'] !== $activation_after['active_plugins_exists']
		|| $activation_before['network_plugins_exists'] !== $activation_after['network_plugins_exists']
		|| ! hash_equals( $activation_before['active_plugins_bytes'], $activation_after['active_plugins_bytes'] )
		|| ! hash_equals( $activation_before['network_plugins_bytes'], $activation_after['network_plugins_bytes'] )
	) {
		return agent_backup_guarded_plugin_update_failure( 'activation_options_changed', 'WordPress activation options changed during the guarded update.', $transaction_id, $plugin_file, $expected_from_version, $expected_target_version, $capability_version, $after_version, $messages, true );
	}

	$recovery = agent_backup_recovery_status_data( $transaction_id );
	if (
		'armed' !== (string) ( $recovery['status'] ?? '' )
		|| ! hash_equals( $expected_target_version, (string) ( $recovery['expected_target_version'] ?? '' ) )
		|| ! hash_equals( $after_version, (string) ( $recovery['installed_version'] ?? '' ) )
		|| empty( $recovery['runtime_active'] )
	) {
		return agent_backup_guarded_plugin_update_failure( 'recovery_postcheck_failed', 'Recovery state or runtime plugin status is inconsistent after the update.', $transaction_id, $plugin_file, $expected_from_version, $expected_target_version, $capability_version, $after_version, $messages, true, $recovery );
	}

	return array(
		'ok'                      => true,
		'status'                  => 'updated_awaiting_health',
		'error_code'              => '',
		'error_message'           => '',
		'messages'                => array_values( $messages ),
		'from_version'            => $expected_from_version,
		'to_version'              => $after_version,
		'transaction_id'          => $transaction_id,
		'plugin'                  => $plugin_file,
		'capability_version'      => AGENT_BACKUP_RECOVERY_CAPABILITY_VERSION,
		'expected_from_version'   => $expected_from_version,
		'expected_target_version' => $expected_target_version,
		'upgrader_started'        => true,
		'mutation_started'        => true,
		'requires_health_check'   => true,
		'postcheck'               => array(
			'target_version_exact'     => true,
			'activation_options_exact' => true,
			'recovery_state_armed'     => true,
		),
		'recovery'                => $recovery,
	);
}

/**
 * Restore the activation state of a plugin after a single update.
 *
 * WordPress deactivates active plugins before single-plugin upgrades.
 * The maintenance flow preserves the previous activation state so operators
 * do not need to reactivate plugins manually after a successful update.
 */
function agent_backup_restore_plugin_activation_state( $plugin_file, $was_active, $was_network_active ) {
	if ( ! $was_active ) {
		return true;
	}

	if ( is_plugin_active( $plugin_file ) ) {
		return true;
	}

	return activate_plugin( $plugin_file, '', (bool) $was_network_active, true );
}

/**
 * Update a single theme.
 */
function agent_backup_execute_theme_update( $stylesheet ) {
	if ( '' === $stylesheet ) {
		return agent_backup_failed_maintenance_result( 'missing_theme', 'No theme identifier was supplied.' );
	}

	delete_site_transient( 'update_themes' );
	wp_update_themes();

	$themes = wp_get_themes();
	if ( ! isset( $themes[ $stylesheet ] ) ) {
		return agent_backup_failed_maintenance_result( 'unknown_theme', 'The requested theme is not installed.' );
	}

	$before_version = (string) $themes[ $stylesheet ]->get( 'Version' );
	$current        = get_site_transient( 'update_themes' );
	if ( ! isset( $current->response[ $stylesheet ] ) ) {
		return agent_backup_ok_maintenance_result(
			'noop',
			$before_version,
			$before_version,
			array( 'The theme is already up to date.' )
		);
	}

	$skin     = new Automatic_Upgrader_Skin();
	$upgrader = new Theme_Upgrader( $skin );
	$result   = $upgrader->upgrade( $stylesheet, array( 'clear_update_cache' => true ) );
	$messages = agent_backup_maintenance_messages( $skin );

	if ( is_wp_error( $result ) ) {
		return agent_backup_failed_maintenance_result(
			$result->get_error_code(),
			$result->get_error_message(),
			$before_version,
			'',
			$messages
		);
	}

	if ( false === $result ) {
		return agent_backup_failed_maintenance_result(
			'filesystem_access_failed',
			agent_backup_filesystem_update_error_message(),
			$before_version,
			'',
			$messages
		);
	}

	wp_clean_themes_cache( true );
	delete_site_transient( 'update_themes' );
	wp_update_themes();
	$themes        = wp_get_themes();
	$after_version = isset( $themes[ $stylesheet ] ) ? (string) $themes[ $stylesheet ]->get( 'Version' ) : '';

	return agent_backup_ok_maintenance_result(
		'succeeded',
		$before_version,
		$after_version,
		$messages
	);
}

/**
 * Update all plugins with currently available updates.
 */
function agent_backup_execute_plugin_update_all() {
	delete_site_transient( 'update_plugins' );
	wp_update_plugins();

	$current = get_site_transient( 'update_plugins' );
	$targets = array_keys( isset( $current->response ) && is_array( $current->response ) ? $current->response : array() );
	if ( empty( $targets ) ) {
		return agent_backup_ok_maintenance_result(
			'noop',
			'',
			'',
			array( 'All plugins are already up to date.' )
		);
	}

	$plugins         = get_plugins();
	$target_versions = array();
	foreach ( $targets as $plugin_file ) {
		if ( isset( $current->response[ $plugin_file ]->new_version ) ) {
			$target_versions[ $plugin_file ] = (string) $current->response[ $plugin_file ]->new_version;
		}
	}

	$skin     = new Automatic_Upgrader_Skin();
	$upgrader = new Plugin_Upgrader( $skin );
	$result   = $upgrader->bulk_upgrade(
		$targets,
		array(
			'clear_update_cache' => true,
		)
	);
	$messages = agent_backup_maintenance_messages( $skin );

	if ( is_wp_error( $result ) ) {
		return agent_backup_failed_maintenance_result(
			$result->get_error_code(),
			$result->get_error_message(),
			'',
			'',
			$messages
		);
	}

	if ( false === $result ) {
		return agent_backup_failed_maintenance_result(
			'filesystem_access_failed',
			agent_backup_filesystem_update_error_message(),
			'',
			'',
			$messages
		);
	}

	wp_clean_plugins_cache( true );
	delete_site_transient( 'update_plugins' );
	wp_update_plugins();

	return agent_backup_finalize_bulk_plugin_result( $targets, $plugins, $target_versions, is_array( $result ) ? $result : array(), $messages );
}

/**
 * Update all themes with currently available updates.
 */
function agent_backup_execute_theme_update_all() {
	delete_site_transient( 'update_themes' );
	wp_update_themes();

	$current = get_site_transient( 'update_themes' );
	$targets = array_keys( isset( $current->response ) && is_array( $current->response ) ? $current->response : array() );
	if ( empty( $targets ) ) {
		return agent_backup_ok_maintenance_result(
			'noop',
			'',
			'',
			array( 'All themes are already up to date.' )
		);
	}

	$themes          = wp_get_themes();
	$target_versions = array();
	foreach ( $targets as $stylesheet ) {
		if ( isset( $current->response[ $stylesheet ]['new_version'] ) ) {
			$target_versions[ $stylesheet ] = (string) $current->response[ $stylesheet ]['new_version'];
		}
	}

	$skin     = new Automatic_Upgrader_Skin();
	$upgrader = new Theme_Upgrader( $skin );
	$result   = $upgrader->bulk_upgrade(
		$targets,
		array(
			'clear_update_cache' => true,
		)
	);
	$messages = agent_backup_maintenance_messages( $skin );

	if ( is_wp_error( $result ) ) {
		return agent_backup_failed_maintenance_result(
			$result->get_error_code(),
			$result->get_error_message(),
			'',
			'',
			$messages
		);
	}

	if ( false === $result ) {
		return agent_backup_failed_maintenance_result(
			'filesystem_access_failed',
			agent_backup_filesystem_update_error_message(),
			'',
			'',
			$messages
		);
	}

	wp_clean_themes_cache( true );
	delete_site_transient( 'update_themes' );
	wp_update_themes();

	return agent_backup_finalize_bulk_theme_result( $targets, $themes, $target_versions, is_array( $result ) ? $result : array(), $messages );
}

/**
 * Update WordPress core.
 */
function agent_backup_execute_core_update() {
	delete_site_transient( 'update_core' );
	wp_version_check();

	$core_updates = get_core_updates(
		array(
			'available' => true,
			'dismissed' => false,
		)
	);
	if ( ! is_array( $core_updates ) || empty( $core_updates ) || ! is_object( $core_updates[0] ) ) {
		$current_version = (string) get_bloginfo( 'version' );
		return agent_backup_ok_maintenance_result(
			'noop',
			$current_version,
			$current_version,
			array( 'WordPress core is already up to date.' )
		);
	}

	$offer          = $core_updates[0];
	$before_version = (string) get_bloginfo( 'version' );
	$skin           = new Automatic_Upgrader_Skin();
	$upgrader       = new Core_Upgrader( $skin );
	$result         = $upgrader->upgrade(
		$offer,
		array(
			'attempt_rollback' => true,
		)
	);
	$messages       = agent_backup_maintenance_messages( $skin );

	if ( is_wp_error( $result ) ) {
		return agent_backup_failed_maintenance_result(
			$result->get_error_code(),
			$result->get_error_message(),
			$before_version,
			'',
			$messages
		);
	}

	if ( false === $result ) {
		return agent_backup_failed_maintenance_result(
			'filesystem_access_failed',
			agent_backup_filesystem_update_error_message(),
			$before_version,
			'',
			$messages
		);
	}

	$after_version = is_string( $result ) && '' !== $result ? $result : (string) get_bloginfo( 'version' );

	return agent_backup_ok_maintenance_result(
		'succeeded',
		$before_version,
		$after_version,
		$messages
	);
}

/**
 * Normalize upgrade skin messages.
 */
function agent_backup_maintenance_messages( $skin ) {
	if ( ! $skin instanceof Automatic_Upgrader_Skin ) {
		return array();
	}

	$messages = $skin->get_upgrade_messages();
	if ( ! is_array( $messages ) ) {
		return array();
	}

	return array_values(
		array_filter(
			array_map(
				static function ( $message ) {
					return trim( wp_strip_all_tags( (string) $message ) );
				},
				$messages
			)
		)
	);
}

/**
 * Generic success payload for maintenance actions.
 */
function agent_backup_ok_maintenance_result( $status, $from_version, $to_version, $messages = array() ) {
	return array(
		'ok'            => true,
		'status'        => $status,
		'error_code'    => '',
		'error_message' => '',
		'messages'      => array_values( $messages ),
		'from_version'  => (string) $from_version,
		'to_version'    => (string) $to_version,
	);
}

/**
 * Generic failure payload for maintenance actions.
 */
function agent_backup_failed_maintenance_result( $error_code, $error_message, $from_version = '', $to_version = '', $messages = array() ) {
	return array(
		'ok'            => false,
		'status'        => 'failed',
		'error_code'    => (string) $error_code,
		'error_message' => (string) $error_message,
		'messages'      => array_values( $messages ),
		'from_version'  => (string) $from_version,
		'to_version'    => (string) $to_version,
	);
}

/**
 * Summarize the result of a bulk plugin update run.
 */
function agent_backup_finalize_bulk_plugin_result( $targets, $plugins_before, $target_versions, $result_map, $messages ) {
	$plugins_after = get_plugins();
	$summary       = agent_backup_summarize_bulk_results( $targets, $plugins_before, $plugins_after, $target_versions, $result_map, 'Version' );
	return agent_backup_bulk_maintenance_result( 'plugin', $summary, $messages );
}

/**
 * Summarize the result of a bulk theme update run.
 */
function agent_backup_finalize_bulk_theme_result( $targets, $themes_before, $target_versions, $result_map, $messages ) {
	$themes_after = wp_get_themes();
	$summary      = agent_backup_summarize_bulk_results( $targets, $themes_before, $themes_after, $target_versions, $result_map, 'Version' );
	return agent_backup_bulk_maintenance_result( 'theme', $summary, $messages );
}

/**
 * Build a normalized bulk update summary across plugins and themes.
 */
function agent_backup_summarize_bulk_results( $targets, $before_items, $after_items, $target_versions, $result_map, $version_field ) {
	$succeeded = array();
	$failed    = array();
	$unchanged = array();

	foreach ( $targets as $target_ref ) {
		$before_version = '';
		if ( isset( $before_items[ $target_ref ] ) ) {
			if ( is_array( $before_items[ $target_ref ] ) ) {
				$before_version = isset( $before_items[ $target_ref ][ $version_field ] ) ? (string) $before_items[ $target_ref ][ $version_field ] : '';
			} elseif ( is_object( $before_items[ $target_ref ] ) && is_callable( array( $before_items[ $target_ref ], 'get' ) ) ) {
				$before_version = (string) $before_items[ $target_ref ]->get( $version_field );
			}
		}

		$after_version = '';
		$after_item     = isset( $after_items[ $target_ref ] ) ? $after_items[ $target_ref ] : null;

		$target_version = isset( $target_versions[ $target_ref ] ) ? (string) $target_versions[ $target_ref ] : '';
		$result_value   = isset( $result_map[ $target_ref ] ) ? $result_map[ $target_ref ] : null;

		if ( is_wp_error( $result_value ) ) {
			$failed[] = sprintf( '%s (%s)', $target_ref, $result_value->get_error_message() );
			continue;
		}

		if ( false === $result_value ) {
			$failed[] = sprintf( '%s (%s)', $target_ref, agent_backup_filesystem_update_error_message() );
			continue;
		}

		if ( is_array( $after_item ) ) {
			$after_version = isset( $after_item[ $version_field ] ) ? (string) $after_item[ $version_field ] : '';
		} elseif ( is_object( $after_item ) && is_callable( array( $after_item, 'get' ) ) ) {
			$after_version = (string) $after_item->get( $version_field );
		}

		if ( '' !== $target_version && '' !== $after_version && version_compare( $after_version, $target_version, '>=' ) ) {
			$succeeded[] = $target_ref;
			continue;
		}

		if ( '' !== $before_version && '' !== $after_version && version_compare( $after_version, $before_version, '>' ) ) {
			$succeeded[] = $target_ref;
			continue;
		}

		$unchanged[] = $target_ref;
	}

	return array(
		'succeeded' => $succeeded,
		'failed'    => $failed,
		'unchanged' => $unchanged,
	);
}

/**
 * Convert a bulk update summary into the standard maintenance response shape.
 */
function agent_backup_bulk_maintenance_result( $type, $summary, $messages ) {
	$succeeded_count = count( $summary['succeeded'] );
	$failed_count    = count( $summary['failed'] );
	$unchanged_count = count( $summary['unchanged'] );
	$total           = $succeeded_count + $failed_count + $unchanged_count;
	$label           = 'plugin' === $type ? 'plugins' : 'themes';

	$summary_messages = array();
	$summary_messages[] = sprintf(
		'Processed %d %s: %d updated, %d unchanged, %d failed.',
		$total,
		$label,
		$succeeded_count,
		$unchanged_count,
		$failed_count
	);
	if ( ! empty( $summary['failed'] ) ) {
		$summary_messages[] = 'Failed items: ' . implode( ', ', array_slice( $summary['failed'], 0, 10 ) );
	}

	$merged_messages = array_values( array_filter( array_merge( $summary_messages, $messages ) ) );

	if ( 0 === $failed_count && 0 === $succeeded_count ) {
		return agent_backup_ok_maintenance_result(
			'noop',
			'',
			'',
			$merged_messages
		);
	}

	if ( 0 === $failed_count ) {
		return agent_backup_ok_maintenance_result(
			'succeeded',
			'',
			'',
			$merged_messages
		);
	}

	if ( 0 === $succeeded_count ) {
		return agent_backup_failed_maintenance_result(
			'bulk_update_failed',
			sprintf( 'All selected %s failed to update.', $label ),
			'',
			'',
			$merged_messages
		);
	}

	return array(
		'ok'            => true,
		'status'        => 'warning',
		'error_code'    => 'bulk_update_partial_failure',
		'error_message' => sprintf( 'Some %s failed to update.', $label ),
		'messages'      => $merged_messages,
		'from_version'  => '',
		'to_version'    => '',
	);
}

/**
 * User-facing message when WordPress cannot write files directly.
 */
function agent_backup_filesystem_update_error_message() {
	return 'The update could not start. This host likely requires filesystem credentials or blocks direct WordPress writes.';
}
