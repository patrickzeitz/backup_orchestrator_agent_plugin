<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Build a maintenance inventory payload for the orchestrator.
 */
function agent_backup_get_maintenance_inventory( $force = false ) {
	require_once ABSPATH . 'wp-admin/includes/plugin.php';
	require_once ABSPATH . 'wp-admin/includes/update.php';
	require_once ABSPATH . 'wp-admin/includes/theme.php';

	if ( $force ) {
		delete_site_transient( 'update_core' );
		delete_site_transient( 'update_plugins' );
		delete_site_transient( 'update_themes' );
	}

	wp_version_check();
	wp_update_plugins();
	wp_update_themes();

	$current_version = (string) get_bloginfo( 'version' );
	$core_updates = get_core_updates(
		array(
			'available' => true,
			'dismissed' => false,
		)
	);
	$core_update  = null;
	if ( is_array( $core_updates ) && ! empty( $core_updates ) ) {
		$candidate = $core_updates[0];
		if ( is_object( $candidate ) && ! empty( $candidate->current ) ) {
			$target_version   = (string) $candidate->current;
			$has_real_upgrade = '' !== $target_version && version_compare( $target_version, $current_version, '>' );
			$core_update = array(
				'update_available' => $has_real_upgrade,
				'current_version'  => $current_version,
				'update_version'   => $has_real_upgrade ? $target_version : '',
				'locale'           => isset( $candidate->locale ) ? (string) $candidate->locale : '',
				'response'         => isset( $candidate->response ) ? (string) $candidate->response : '',
				'package_available'=> $has_real_upgrade && ! empty( $candidate->download ),
			);
		}
	}
	if ( null === $core_update ) {
		$core_update = array(
			'update_available' => false,
			'current_version'  => $current_version,
			'update_version'   => '',
			'locale'           => '',
			'response'         => 'latest',
			'package_available'=> false,
		);
	}

	$active_plugins  = get_option( 'active_plugins', array() );
	$plugin_updates  = get_plugin_updates();
	$plugins         = array();
	foreach ( get_plugins() as $plugin_file => $plugin_data ) {
		$update = isset( $plugin_updates[ $plugin_file ] ) ? $plugin_updates[ $plugin_file ]->update : null;
		$slug   = dirname( $plugin_file );
		if ( '.' === $slug || '' === $slug ) {
			$slug = basename( $plugin_file, '.php' );
		}
		$plugins[] = array(
			'file'             => $plugin_file,
			'slug'             => $slug,
			'name'             => isset( $plugin_data['Name'] ) ? (string) $plugin_data['Name'] : $plugin_file,
			'version'          => isset( $plugin_data['Version'] ) ? (string) $plugin_data['Version'] : '',
			'active'           => in_array( $plugin_file, $active_plugins, true ) || is_plugin_active_for_network( $plugin_file ),
			'network_active'   => is_plugin_active_for_network( $plugin_file ),
			'update_available' => is_object( $update ) && ! empty( $update->new_version ),
			'update_version'   => is_object( $update ) && ! empty( $update->new_version ) ? (string) $update->new_version : '',
		);
	}
	usort(
		$plugins,
		static function ( $left, $right ) {
			return strcasecmp( $left['name'], $right['name'] );
		}
	);

	$stylesheet     = get_stylesheet();
	$template       = get_template();
	$theme_updates  = get_theme_updates();
	$themes         = array();
	foreach ( wp_get_themes() as $theme_stylesheet => $theme ) {
		$update = isset( $theme_updates[ $theme_stylesheet ] ) ? $theme_updates[ $theme_stylesheet ]->update : null;
		$themes[] = array(
			'stylesheet'       => $theme_stylesheet,
			'name'             => (string) $theme->get( 'Name' ),
			'version'          => (string) $theme->get( 'Version' ),
			'active'           => $theme_stylesheet === $stylesheet || $theme_stylesheet === $template,
			'template'         => (string) $theme->get_template(),
			'update_available' => is_array( $update ) && ! empty( $update['new_version'] ),
			'update_version'   => is_array( $update ) && ! empty( $update['new_version'] ) ? (string) $update['new_version'] : '',
		);
	}
	usort(
		$themes,
		static function ( $left, $right ) {
			return strcasecmp( $left['name'], $right['name'] );
		}
	);

	return array(
		'checked_at'        => gmdate( 'c' ),
		'wordpress_version' => get_bloginfo( 'version' ),
		'php_version'       => PHP_VERSION,
		'core'              => $core_update,
		'plugins'           => $plugins,
		'themes'            => $themes,
		'counts'            => array(
			'plugins_total'        => count( $plugins ),
			'plugins_with_updates' => count(
				array_filter(
					$plugins,
					static function ( $plugin ) {
						return ! empty( $plugin['update_available'] );
					}
				)
			),
			'themes_total'         => count( $themes ),
			'themes_with_updates'  => count(
				array_filter(
					$themes,
					static function ( $theme ) {
						return ! empty( $theme['update_available'] );
					}
				)
			),
		),
	);
}

/**
 * REST route callback for maintenance inventory.
 */
function agent_backup_route_maintenance( WP_REST_Request $request ) {
	$force = (bool) $request->get_param( 'force' );

	return new WP_REST_Response(
		array(
			'ok'            => true,
			'ts'            => time(),
			'site'          => home_url(),
			'agent_version' => AGENT_BACKUP_VERSION,
			'maintenance'   => agent_backup_get_maintenance_inventory( $force ),
		),
		200
	);
}

/**
 * REST route callback for maintenance actions.
 */
function agent_backup_route_maintenance_action( WP_REST_Request $request ) {
	$action = sanitize_key( (string) $request->get_param( 'action' ) );

	try {
		$result = agent_backup_execute_maintenance_action( $action, $request );
	} catch ( Throwable $error ) {
		agent_backup_log( sprintf( 'Maintenance action crashed: %s', $error->getMessage() ) );
		$result = array(
			'ok'            => false,
			'status'        => 'failed',
			'error_code'    => 'maintenance_action_crash',
			'error_message' => $error->getMessage(),
			'messages'      => array(),
			'from_version'  => '',
			'to_version'    => '',
		);
	}

	return new WP_REST_Response(
		array(
			'ok'            => ! empty( $result['ok'] ),
			'ts'            => time(),
			'site'          => home_url(),
			'agent_version' => AGENT_BACKUP_VERSION,
			'result'        => $result,
			'maintenance'   => agent_backup_get_maintenance_inventory( true ),
		),
		200
	);
}

/**
 * Execute a maintenance action via WordPress core upgraders.
 */
function agent_backup_execute_maintenance_action( $action, WP_REST_Request $request ) {
	agent_backup_require_maintenance_upgrader_dependencies();

	switch ( $action ) {
		case 'refresh_update_checks':
			return agent_backup_execute_refresh_update_checks();
		case 'core_update':
			return agent_backup_execute_core_update();
		case 'plugin_update':
			return agent_backup_execute_plugin_update( sanitize_text_field( (string) $request->get_param( 'plugin' ) ) );
		case 'plugin_update_all':
			return agent_backup_execute_plugin_update_all();
		case 'theme_update':
			return agent_backup_execute_theme_update( sanitize_text_field( (string) $request->get_param( 'theme' ) ) );
		case 'theme_update_all':
			return agent_backup_execute_theme_update_all();
		default:
			return agent_backup_failed_maintenance_result(
				'invalid_action',
				'Unsupported maintenance action.'
			);
	}
}

/**
 * Refresh core, plugin, and theme update caches without installing anything.
 */
function agent_backup_execute_refresh_update_checks() {
	delete_site_transient( 'update_core' );
	delete_site_transient( 'update_plugins' );
	delete_site_transient( 'update_themes' );

	wp_version_check();
	wp_update_plugins();
	wp_update_themes();

	$core_updates   = get_core_updates( array( 'dismissed' => false ) );
	$plugin_updates = get_site_transient( 'update_plugins' );
	$theme_updates  = get_site_transient( 'update_themes' );

	$core_count   = is_array( $core_updates ) ? count( $core_updates ) : 0;
	$plugin_count = ( is_object( $plugin_updates ) && ! empty( $plugin_updates->response ) && is_array( $plugin_updates->response ) )
		? count( $plugin_updates->response )
		: 0;
	$theme_count = ( is_object( $theme_updates ) && ! empty( $theme_updates->response ) && is_array( $theme_updates->response ) )
		? count( $theme_updates->response )
		: 0;

	return agent_backup_ok_maintenance_result(
		'succeeded',
		'',
		'',
		array(
			sprintf(
				'WordPress update checks refreshed. Core: %d, plugins: %d, themes: %d.',
				$core_count,
				$plugin_count,
				$theme_count
			),
		)
	);
}

/**
 * Load the upgrader classes needed for maintenance actions.
 */
function agent_backup_require_maintenance_upgrader_dependencies() {
	require_once ABSPATH . 'wp-admin/includes/plugin.php';
	require_once ABSPATH . 'wp-admin/includes/update.php';
	require_once ABSPATH . 'wp-admin/includes/theme.php';
	require_once ABSPATH . 'wp-admin/includes/class-wp-upgrader.php';
	require_once ABSPATH . 'wp-admin/includes/class-automatic-upgrader-skin.php';
	require_once ABSPATH . 'wp-admin/includes/class-plugin-upgrader.php';
	require_once ABSPATH . 'wp-admin/includes/class-theme-upgrader.php';
	require_once ABSPATH . 'wp-admin/includes/class-core-upgrader.php';
}

/**
 * Update a single plugin.
 */
function agent_backup_execute_plugin_update( $plugin_file ) {
	if ( '' === $plugin_file ) {
		return agent_backup_failed_maintenance_result( 'missing_plugin', 'No plugin identifier was supplied.' );
	}

	delete_site_transient( 'update_plugins' );
	wp_update_plugins();

	$plugins = get_plugins();
	if ( ! isset( $plugins[ $plugin_file ] ) ) {
		return agent_backup_failed_maintenance_result( 'unknown_plugin', 'The requested plugin is not installed.' );
	}

	$before_version = isset( $plugins[ $plugin_file ]['Version'] ) ? (string) $plugins[ $plugin_file ]['Version'] : '';
	$was_network_active = is_plugin_active_for_network( $plugin_file );
	$was_active         = is_plugin_active( $plugin_file );
	$current        = get_site_transient( 'update_plugins' );
	if ( ! isset( $current->response[ $plugin_file ] ) ) {
		return agent_backup_ok_maintenance_result(
			'noop',
			$before_version,
			$before_version,
			array( 'The plugin is already up to date.' )
		);
	}

	$skin     = new Automatic_Upgrader_Skin();
	$upgrader = new Plugin_Upgrader( $skin );
	$result   = $upgrader->upgrade( $plugin_file, array( 'clear_update_cache' => true ) );
	$messages = agent_backup_maintenance_messages( $skin );

	if ( is_wp_error( $result ) ) {
		return agent_backup_failed_maintenance_result(
			$result->get_error_code(),
			$result->get_error_message(),
			$before_version,
			'',
			$messages
		);
	}

	if ( false === $result ) {
		return agent_backup_failed_maintenance_result(
			'filesystem_access_failed',
			agent_backup_filesystem_update_error_message(),
			$before_version,
			'',
			$messages
		);
	}

	wp_clean_plugins_cache( true );
	delete_site_transient( 'update_plugins' );
	wp_update_plugins();
	$plugins       = get_plugins();
	$after_version = isset( $plugins[ $plugin_file ]['Version'] ) ? (string) $plugins[ $plugin_file ]['Version'] : '';
	$reactivation  = agent_backup_restore_plugin_activation_state( $plugin_file, $was_active, $was_network_active );
	if ( is_wp_error( $reactivation ) ) {
		$messages[] = sprintf(
			'Plugin update succeeded, but reactivation failed: %s',
			$reactivation->get_error_message()
		);
		return array(
			'ok'            => true,
			'status'        => 'warning',
			'error_code'    => 'plugin_reactivation_failed',
			'error_message' => 'The plugin update succeeded, but the plugin could not be reactivated automatically.',
			'messages'      => array_values( $messages ),
			'from_version'  => (string) $before_version,
			'to_version'    => (string) $after_version,
		);
	}

	return agent_backup_ok_maintenance_result(
		'succeeded',
		$before_version,
		$after_version,
		$messages
	);
}

/**
 * Restore the activation state of a plugin after a single update.
 *
 * WordPress deactivates active plugins before single-plugin upgrades.
 * The maintenance flow preserves the previous activation state so operators
 * do not need to reactivate plugins manually after a successful update.
 */
function agent_backup_restore_plugin_activation_state( $plugin_file, $was_active, $was_network_active ) {
	if ( ! $was_active ) {
		return true;
	}

	if ( is_plugin_active( $plugin_file ) ) {
		return true;
	}

	return activate_plugin( $plugin_file, '', (bool) $was_network_active, true );
}

/**
 * Update a single theme.
 */
function agent_backup_execute_theme_update( $stylesheet ) {
	if ( '' === $stylesheet ) {
		return agent_backup_failed_maintenance_result( 'missing_theme', 'No theme identifier was supplied.' );
	}

	delete_site_transient( 'update_themes' );
	wp_update_themes();

	$themes = wp_get_themes();
	if ( ! isset( $themes[ $stylesheet ] ) ) {
		return agent_backup_failed_maintenance_result( 'unknown_theme', 'The requested theme is not installed.' );
	}

	$before_version = (string) $themes[ $stylesheet ]->get( 'Version' );
	$current        = get_site_transient( 'update_themes' );
	if ( ! isset( $current->response[ $stylesheet ] ) ) {
		return agent_backup_ok_maintenance_result(
			'noop',
			$before_version,
			$before_version,
			array( 'The theme is already up to date.' )
		);
	}

	$skin     = new Automatic_Upgrader_Skin();
	$upgrader = new Theme_Upgrader( $skin );
	$result   = $upgrader->upgrade( $stylesheet, array( 'clear_update_cache' => true ) );
	$messages = agent_backup_maintenance_messages( $skin );

	if ( is_wp_error( $result ) ) {
		return agent_backup_failed_maintenance_result(
			$result->get_error_code(),
			$result->get_error_message(),
			$before_version,
			'',
			$messages
		);
	}

	if ( false === $result ) {
		return agent_backup_failed_maintenance_result(
			'filesystem_access_failed',
			agent_backup_filesystem_update_error_message(),
			$before_version,
			'',
			$messages
		);
	}

	wp_clean_themes_cache( true );
	delete_site_transient( 'update_themes' );
	wp_update_themes();
	$themes        = wp_get_themes();
	$after_version = isset( $themes[ $stylesheet ] ) ? (string) $themes[ $stylesheet ]->get( 'Version' ) : '';

	return agent_backup_ok_maintenance_result(
		'succeeded',
		$before_version,
		$after_version,
		$messages
	);
}

/**
 * Update all plugins with currently available updates.
 */
function agent_backup_execute_plugin_update_all() {
	delete_site_transient( 'update_plugins' );
	wp_update_plugins();

	$current = get_site_transient( 'update_plugins' );
	$targets = array_keys( isset( $current->response ) && is_array( $current->response ) ? $current->response : array() );
	if ( empty( $targets ) ) {
		return agent_backup_ok_maintenance_result(
			'noop',
			'',
			'',
			array( 'All plugins are already up to date.' )
		);
	}

	$plugins         = get_plugins();
	$target_versions = array();
	foreach ( $targets as $plugin_file ) {
		if ( isset( $current->response[ $plugin_file ]->new_version ) ) {
			$target_versions[ $plugin_file ] = (string) $current->response[ $plugin_file ]->new_version;
		}
	}

	$skin     = new Automatic_Upgrader_Skin();
	$upgrader = new Plugin_Upgrader( $skin );
	$result   = $upgrader->bulk_upgrade(
		$targets,
		array(
			'clear_update_cache' => true,
		)
	);
	$messages = agent_backup_maintenance_messages( $skin );

	if ( is_wp_error( $result ) ) {
		return agent_backup_failed_maintenance_result(
			$result->get_error_code(),
			$result->get_error_message(),
			'',
			'',
			$messages
		);
	}

	if ( false === $result ) {
		return agent_backup_failed_maintenance_result(
			'filesystem_access_failed',
			agent_backup_filesystem_update_error_message(),
			'',
			'',
			$messages
		);
	}

	wp_clean_plugins_cache( true );
	delete_site_transient( 'update_plugins' );
	wp_update_plugins();

	return agent_backup_finalize_bulk_plugin_result( $targets, $plugins, $target_versions, is_array( $result ) ? $result : array(), $messages );
}

/**
 * Update all themes with currently available updates.
 */
function agent_backup_execute_theme_update_all() {
	delete_site_transient( 'update_themes' );
	wp_update_themes();

	$current = get_site_transient( 'update_themes' );
	$targets = array_keys( isset( $current->response ) && is_array( $current->response ) ? $current->response : array() );
	if ( empty( $targets ) ) {
		return agent_backup_ok_maintenance_result(
			'noop',
			'',
			'',
			array( 'All themes are already up to date.' )
		);
	}

	$themes          = wp_get_themes();
	$target_versions = array();
	foreach ( $targets as $stylesheet ) {
		if ( isset( $current->response[ $stylesheet ]['new_version'] ) ) {
			$target_versions[ $stylesheet ] = (string) $current->response[ $stylesheet ]['new_version'];
		}
	}

	$skin     = new Automatic_Upgrader_Skin();
	$upgrader = new Theme_Upgrader( $skin );
	$result   = $upgrader->bulk_upgrade(
		$targets,
		array(
			'clear_update_cache' => true,
		)
	);
	$messages = agent_backup_maintenance_messages( $skin );

	if ( is_wp_error( $result ) ) {
		return agent_backup_failed_maintenance_result(
			$result->get_error_code(),
			$result->get_error_message(),
			'',
			'',
			$messages
		);
	}

	if ( false === $result ) {
		return agent_backup_failed_maintenance_result(
			'filesystem_access_failed',
			agent_backup_filesystem_update_error_message(),
			'',
			'',
			$messages
		);
	}

	wp_clean_themes_cache( true );
	delete_site_transient( 'update_themes' );
	wp_update_themes();

	return agent_backup_finalize_bulk_theme_result( $targets, $themes, $target_versions, is_array( $result ) ? $result : array(), $messages );
}

/**
 * Update WordPress core.
 */
function agent_backup_execute_core_update() {
	delete_site_transient( 'update_core' );
	wp_version_check();

	$core_updates = get_core_updates(
		array(
			'available' => true,
			'dismissed' => false,
		)
	);
	if ( ! is_array( $core_updates ) || empty( $core_updates ) || ! is_object( $core_updates[0] ) ) {
		$current_version = (string) get_bloginfo( 'version' );
		return agent_backup_ok_maintenance_result(
			'noop',
			$current_version,
			$current_version,
			array( 'WordPress core is already up to date.' )
		);
	}

	$offer          = $core_updates[0];
	$before_version = (string) get_bloginfo( 'version' );
	$skin           = new Automatic_Upgrader_Skin();
	$upgrader       = new Core_Upgrader( $skin );
	$result         = $upgrader->upgrade(
		$offer,
		array(
			'attempt_rollback' => true,
		)
	);
	$messages       = agent_backup_maintenance_messages( $skin );

	if ( is_wp_error( $result ) ) {
		return agent_backup_failed_maintenance_result(
			$result->get_error_code(),
			$result->get_error_message(),
			$before_version,
			'',
			$messages
		);
	}

	if ( false === $result ) {
		return agent_backup_failed_maintenance_result(
			'filesystem_access_failed',
			agent_backup_filesystem_update_error_message(),
			$before_version,
			'',
			$messages
		);
	}

	$after_version = is_string( $result ) && '' !== $result ? $result : (string) get_bloginfo( 'version' );

	return agent_backup_ok_maintenance_result(
		'succeeded',
		$before_version,
		$after_version,
		$messages
	);
}

/**
 * Normalize upgrade skin messages.
 */
function agent_backup_maintenance_messages( $skin ) {
	if ( ! $skin instanceof Automatic_Upgrader_Skin ) {
		return array();
	}

	$messages = $skin->get_upgrade_messages();
	if ( ! is_array( $messages ) ) {
		return array();
	}

	return array_values(
		array_filter(
			array_map(
				static function ( $message ) {
					return trim( wp_strip_all_tags( (string) $message ) );
				},
				$messages
			)
		)
	);
}

/**
 * Generic success payload for maintenance actions.
 */
function agent_backup_ok_maintenance_result( $status, $from_version, $to_version, $messages = array() ) {
	return array(
		'ok'            => true,
		'status'        => $status,
		'error_code'    => '',
		'error_message' => '',
		'messages'      => array_values( $messages ),
		'from_version'  => (string) $from_version,
		'to_version'    => (string) $to_version,
	);
}

/**
 * Generic failure payload for maintenance actions.
 */
function agent_backup_failed_maintenance_result( $error_code, $error_message, $from_version = '', $to_version = '', $messages = array() ) {
	return array(
		'ok'            => false,
		'status'        => 'failed',
		'error_code'    => (string) $error_code,
		'error_message' => (string) $error_message,
		'messages'      => array_values( $messages ),
		'from_version'  => (string) $from_version,
		'to_version'    => (string) $to_version,
	);
}

/**
 * Summarize the result of a bulk plugin update run.
 */
function agent_backup_finalize_bulk_plugin_result( $targets, $plugins_before, $target_versions, $result_map, $messages ) {
	$plugins_after = get_plugins();
	$summary       = agent_backup_summarize_bulk_results( $targets, $plugins_before, $plugins_after, $target_versions, $result_map, 'Version' );
	return agent_backup_bulk_maintenance_result( 'plugin', $summary, $messages );
}

/**
 * Summarize the result of a bulk theme update run.
 */
function agent_backup_finalize_bulk_theme_result( $targets, $themes_before, $target_versions, $result_map, $messages ) {
	$themes_after = wp_get_themes();
	$summary      = agent_backup_summarize_bulk_results( $targets, $themes_before, $themes_after, $target_versions, $result_map, 'Version' );
	return agent_backup_bulk_maintenance_result( 'theme', $summary, $messages );
}

/**
 * Build a normalized bulk update summary across plugins and themes.
 */
function agent_backup_summarize_bulk_results( $targets, $before_items, $after_items, $target_versions, $result_map, $version_field ) {
	$succeeded = array();
	$failed    = array();
	$unchanged = array();

	foreach ( $targets as $target_ref ) {
		$before_version = '';
		if ( isset( $before_items[ $target_ref ] ) ) {
			if ( is_array( $before_items[ $target_ref ] ) ) {
				$before_version = isset( $before_items[ $target_ref ][ $version_field ] ) ? (string) $before_items[ $target_ref ][ $version_field ] : '';
			} elseif ( is_object( $before_items[ $target_ref ] ) && is_callable( array( $before_items[ $target_ref ], 'get' ) ) ) {
				$before_version = (string) $before_items[ $target_ref ]->get( $version_field );
			}
		}

		$after_version = '';
		$after_item     = isset( $after_items[ $target_ref ] ) ? $after_items[ $target_ref ] : null;

		$target_version = isset( $target_versions[ $target_ref ] ) ? (string) $target_versions[ $target_ref ] : '';
		$result_value   = isset( $result_map[ $target_ref ] ) ? $result_map[ $target_ref ] : null;

		if ( is_wp_error( $result_value ) ) {
			$failed[] = sprintf( '%s (%s)', $target_ref, $result_value->get_error_message() );
			continue;
		}

		if ( false === $result_value ) {
			$failed[] = sprintf( '%s (%s)', $target_ref, agent_backup_filesystem_update_error_message() );
			continue;
		}

		if ( is_array( $after_item ) ) {
			$after_version = isset( $after_item[ $version_field ] ) ? (string) $after_item[ $version_field ] : '';
		} elseif ( is_object( $after_item ) && is_callable( array( $after_item, 'get' ) ) ) {
			$after_version = (string) $after_item->get( $version_field );
		}

		if ( '' !== $target_version && '' !== $after_version && version_compare( $after_version, $target_version, '>=' ) ) {
			$succeeded[] = $target_ref;
			continue;
		}

		if ( '' !== $before_version && '' !== $after_version && version_compare( $after_version, $before_version, '>' ) ) {
			$succeeded[] = $target_ref;
			continue;
		}

		$unchanged[] = $target_ref;
	}

	return array(
		'succeeded' => $succeeded,
		'failed'    => $failed,
		'unchanged' => $unchanged,
	);
}

/**
 * Convert a bulk update summary into the standard maintenance response shape.
 */
function agent_backup_bulk_maintenance_result( $type, $summary, $messages ) {
	$succeeded_count = count( $summary['succeeded'] );
	$failed_count    = count( $summary['failed'] );
	$unchanged_count = count( $summary['unchanged'] );
	$total           = $succeeded_count + $failed_count + $unchanged_count;
	$label           = 'plugin' === $type ? 'plugins' : 'themes';

	$summary_messages = array();
	$summary_messages[] = sprintf(
		'Processed %d %s: %d updated, %d unchanged, %d failed.',
		$total,
		$label,
		$succeeded_count,
		$unchanged_count,
		$failed_count
	);
	if ( ! empty( $summary['failed'] ) ) {
		$summary_messages[] = 'Failed items: ' . implode( ', ', array_slice( $summary['failed'], 0, 10 ) );
	}

	$merged_messages = array_values( array_filter( array_merge( $summary_messages, $messages ) ) );

	if ( 0 === $failed_count && 0 === $succeeded_count ) {
		return agent_backup_ok_maintenance_result(
			'noop',
			'',
			'',
			$merged_messages
		);
	}

	if ( 0 === $failed_count ) {
		return agent_backup_ok_maintenance_result(
			'succeeded',
			'',
			'',
			$merged_messages
		);
	}

	if ( 0 === $succeeded_count ) {
		return agent_backup_failed_maintenance_result(
			'bulk_update_failed',
			sprintf( 'All selected %s failed to update.', $label ),
			'',
			'',
			$merged_messages
		);
	}

	return array(
		'ok'            => true,
		'status'        => 'warning',
		'error_code'    => 'bulk_update_partial_failure',
		'error_message' => sprintf( 'Some %s failed to update.', $label ),
		'messages'      => $merged_messages,
		'from_version'  => '',
		'to_version'    => '',
	);
}

/**
 * User-facing message when WordPress cannot write files directly.
 */
function agent_backup_filesystem_update_error_message() {
	return 'The update could not start. This host likely requires filesystem credentials or blocks direct WordPress writes.';
}
