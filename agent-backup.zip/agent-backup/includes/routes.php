<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

add_filter(
	'rest_pre_serve_request',
	function ( $served, $result, $request, $server ) {
		$payload = $result;
		if ( $result instanceof WP_HTTP_Response ) {
			$payload = $result->get_data();
		}

		if ( $payload instanceof Agent_Backup_Stream_Response ) {
			if ( ! headers_sent() ) {
				foreach ( $payload->headers as $name => $value ) {
					header( $name . ': ' . $value );
				}
				http_response_code( $payload->status );
			}
			call_user_func( $payload->streamer );
			return true;
		}
		return $served;
	},
	10,
	4
);

add_action(
	'rest_api_init',
	function () {
		add_filter(
			'rest_request_after_callbacks',
			function ( $response, $handler, $request ) {
				if ( ! $request instanceof WP_REST_Request ) {
					return $response;
				}
				if ( false === strpos( $request->get_route(), '/agent-backup/v1' ) ) {
					return $response;
				}
				if ( is_wp_error( $response ) ) {
					$status  = 500;
					$data    = $response->get_error_data();
					if ( is_array( $data ) && isset( $data['status'] ) ) {
						$status = (int) $data['status'];
					}
					$code    = $response->get_error_code();
					$message = $response->get_error_message();
					agent_backup_log( sprintf( 'REST error %d %s: %s', $status, $code, $message ) );
				}
				return $response;
			},
			10,
			3
		);

		register_rest_route(
			'agent-backup/v1',
			'/status',
			array(
				'methods'             => 'GET',
				'callback'            => function () {
					return new WP_REST_Response(
						array(
							'ok'            => true,
							'ts'            => time(),
							'site'          => home_url(),
							'agent_version' => AGENT_BACKUP_VERSION,
						),
						200
					);
				},
				'permission_callback' => 'agent_backup_authenticate_request',
			)
		);

		register_rest_route(
			'agent-backup/v1',
			'/files',
			array(
				'methods'             => 'GET',
				'callback'            => 'agent_backup_route_files',
				'permission_callback' => 'agent_backup_authenticate_request',
				'args'                => array(
					'cursor' => array(
						'type'              => 'integer',
						'default'           => 0,
						'sanitize_callback' => 'absint',
					),
					'limit'  => array(
						'type'              => 'integer',
						'default'           => agent_backup_get_settings()['default_limit'],
						'sanitize_callback' => 'absint',
					),
					'root'   => array(
						'type'              => 'string',
						'default'           => 'wp-content',
						'sanitize_callback' => 'sanitize_text_field',
					),
					'include_hashes' => array(
						'type'              => 'boolean',
						'default'           => false,
						'sanitize_callback' => static function ( $value ) {
							return (bool) intval( $value );
						},
					),
				),
			)
		);

		register_rest_route(
			'agent-backup/v1',
			'/file',
			array(
				'methods'             => 'GET',
				'callback'            => 'agent_backup_route_file',
				'permission_callback' => 'agent_backup_authenticate_request',
				'args'                => array(
					'path'   => array(
						'type'              => 'string',
						'required'          => true,
						'sanitize_callback' => 'sanitize_text_field',
					),
					'offset' => array(
						'type'              => 'integer',
						'default'           => 0,
						'sanitize_callback' => 'absint',
					),
					'length' => array(
						'type'              => 'integer',
						'default'           => 5 * 1024 * 1024,
						'sanitize_callback' => 'absint',
					),
					'verify_hash' => array(
						'type'              => 'boolean',
						'default'           => false,
						'sanitize_callback' => static function ( $value ) {
							return (bool) intval( $value );
						},
					),
				),
			)
		);

		register_rest_route(
			'agent-backup/v1',
			'/admin-login/users',
			array(
				'methods'             => 'GET',
				'callback'            => 'agent_backup_route_admin_login_users',
				'permission_callback' => 'agent_backup_authenticate_request',
			)
		);

		register_rest_route(
			'agent-backup/v1',
			'/admin-login',
			array(
				'methods'             => 'POST',
				'callback'            => 'agent_backup_route_admin_login_create',
				'permission_callback' => 'agent_backup_authenticate_request',
				'args'                => array(
					'user_login' => array(
						'type'              => 'string',
						'required'          => true,
						'sanitize_callback' => 'sanitize_user',
					),
				),
			)
		);

		register_rest_route(
			'agent-backup/v1',
			'/db',
			array(
				'methods'             => 'GET',
				'callback'            => 'agent_backup_route_db',
				'permission_callback' => 'agent_backup_authenticate_request',
				'args'                => array(
					'gzip' => array(
						'type'              => 'boolean',
						'default'           => true,
						'sanitize_callback' => static function ( $value ) {
							return (bool) intval( $value );
						},
					),
				),
			)
		);

		register_rest_route(
			'agent-backup/v1',
			'/rescan',
			array(
				'methods'             => 'POST',
				'callback'            => function () {
					do_action( 'agent_backup_rescan' );
					return new WP_REST_Response(
						array(
							'ok' => true,
						),
						200
					);
				},
				'permission_callback' => 'agent_backup_authenticate_request',
			)
		);

		register_rest_route(
			'agent-backup/v1',
			'/maintenance',
			array(
				'methods'             => 'GET',
				'callback'            => 'agent_backup_route_maintenance',
				'permission_callback' => 'agent_backup_authenticate_request',
				'args'                => array(
					'force' => array(
						'type'              => 'boolean',
						'default'           => false,
						'sanitize_callback' => static function ( $value ) {
							return (bool) intval( $value );
						},
					),
				),
			)
		);

		register_rest_route(
			'agent-backup/v1',
			'/maintenance/action',
			array(
				'methods'             => 'POST',
				'callback'            => 'agent_backup_route_maintenance_action',
				'permission_callback' => 'agent_backup_authenticate_request',
				'args'                => array(
					'action' => array(
						'type'              => 'string',
						'required'          => true,
						'sanitize_callback' => 'sanitize_text_field',
					),
					'plugin' => array(
						'type'              => 'string',
						'required'          => false,
						'sanitize_callback' => 'sanitize_text_field',
					),
					'theme'  => array(
						'type'              => 'string',
						'required'          => false,
						'sanitize_callback' => 'sanitize_text_field',
					),
				),
			)
		);
	}
);
