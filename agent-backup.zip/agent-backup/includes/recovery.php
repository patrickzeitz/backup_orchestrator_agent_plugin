<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'AGENT_BACKUP_RECOVERY_SCHEMA_VERSION', 1 );
define( 'AGENT_BACKUP_RECOVERY_CAPABILITY_VERSION', 1 );
define( 'AGENT_BACKUP_RECOVERY_GUARD_ASSET_VERSION', '1.2.0' );
define( 'AGENT_BACKUP_RECOVERY_DEFAULT_TTL', 1800 );
define( 'AGENT_BACKUP_RECOVERY_MAX_TTL', 3600 );
define( 'AGENT_BACKUP_RECOVERY_MAX_STATE_BYTES', 16384 );

/**
 * Register the authenticated recovery endpoints without overloading maintenance routes.
 */
function agent_backup_register_recovery_routes() {
	$permission = 'agent_backup_authenticate_recovery_request';

	register_rest_route(
		'agent-backup/v1',
		'/recovery/readiness',
		array(
			'methods'             => 'POST',
			'callback'            => 'agent_backup_route_recovery_readiness',
			'permission_callback' => $permission,
		)
	);

	register_rest_route(
		'agent-backup/v1',
		'/recovery/guard/install',
		array(
			'methods'             => 'POST',
			'callback'            => 'agent_backup_route_recovery_guard_install',
			'permission_callback' => $permission,
		)
	);

	register_rest_route(
		'agent-backup/v1',
		'/recovery/arm',
		array(
			'methods'             => 'POST',
			'callback'            => 'agent_backup_route_recovery_arm',
			'permission_callback' => $permission,
			'args'                => array(
				'capability_version'      => array(
					'type'     => 'integer',
					'required' => true,
				),
				'transaction_id' => array(
					'type'     => 'string',
					'required' => true,
				),
				'plugin'         => array(
					'type'     => 'string',
					'required' => true,
				),
				'ttl_seconds'    => array(
					'type'    => 'integer',
					'default' => AGENT_BACKUP_RECOVERY_DEFAULT_TTL,
				),
				'expected_from_version'   => array(
					'type'     => 'string',
					'required' => true,
				),
				'expected_target_version' => array(
					'type'     => 'string',
					'required' => true,
				),
			),
		)
	);

	register_rest_route(
		'agent-backup/v1',
		'/recovery/status',
		array(
			'methods'             => 'GET',
			'callback'            => 'agent_backup_route_recovery_status',
			'permission_callback' => $permission,
			'args'                => array(
				'transaction_id' => array(
					'type'     => 'string',
					'required' => false,
				),
			),
		)
	);

	register_rest_route(
		'agent-backup/v1',
		'/recovery/clear',
		array(
			'methods'             => 'POST',
			'callback'            => 'agent_backup_route_recovery_clear',
			'permission_callback' => $permission,
			'args'                => array(
				'transaction_id' => array(
					'type'     => 'string',
					'required' => true,
				),
			),
		)
	);
}
add_action( 'rest_api_init', 'agent_backup_register_recovery_routes' );

/**
 * Authenticate recovery requests without initializing or normalizing settings.
 */
function agent_backup_authenticate_recovery_request( WP_REST_Request $request ) {
	$stored = get_option( AGENT_BACKUP_OPTION_SETTINGS, array() );
	if ( ! is_array( $stored ) ) {
		$stored = array();
	}
	$settings              = wp_parse_args( $stored, agent_backup_default_settings() );
	$settings['allow_ips'] = agent_backup_merge_default_allow_ips( $settings['allow_ips'] ?? array() );
	if ( empty( $settings['token'] ) || empty( $settings['secret'] ) ) {
		return new WP_Error( 'recovery_not_paired', 'Recovery endpoints require an already paired agent.', array( 'status' => 401 ) );
	}

	return agent_backup_authenticate_signed_request(
		strtoupper( $request->get_method() ),
		'/wp-json' . $request->get_route(),
		$request->get_query_params(),
		static function ( $name ) use ( $request ) {
			return $request->get_header( $name );
		},
		$settings
	);
}

/**
 * Fixed recovery paths. None of these accept request-controlled path fragments.
 */
function agent_backup_recovery_state_directory() {
	return trailingslashit( WP_CONTENT_DIR ) . '.agent-backup-recovery';
}

function agent_backup_recovery_mu_directory() {
	return trailingslashit( WP_CONTENT_DIR ) . 'mu-plugins';
}

function agent_backup_recovery_guard_source_path() {
	return AGENT_BACKUP_PATH . 'assets/agent-backup-recovery-guard.php';
}

function agent_backup_recovery_guard_target_path() {
	return trailingslashit( agent_backup_recovery_mu_directory() ) . 'agent-backup-recovery-guard.php';
}

function agent_backup_recovery_state_path( $kind ) {
	if ( 'armed' === $kind ) {
		return trailingslashit( agent_backup_recovery_state_directory() ) . 'armed.json';
	}
	if ( 'quarantine' === $kind ) {
		return trailingslashit( agent_backup_recovery_state_directory() ) . 'quarantine.json';
	}
	return '';
}

/**
 * Return structured errors rather than WP_Error from callbacks. The agent's existing
 * REST error logger persists WP_Error responses in the database, which recovery avoids.
 */
function agent_backup_recovery_error_response( $code, $message, $status = 400, $extra = array() ) {
	return new WP_REST_Response(
		array_merge(
			array(
				'ok'            => false,
				'error_code'    => (string) $code,
				'error_message' => (string) $message,
			),
			(array) $extra
		),
		(int) $status
	);
}

/**
 * Read the already-paired HMAC secret without invoking the settings helper, whose
 * initialization behavior may persist defaults.
 */
function agent_backup_recovery_hmac_secret() {
	$option_name = defined( 'AGENT_BACKUP_OPTION_SETTINGS' ) ? AGENT_BACKUP_OPTION_SETTINGS : 'agent_backup_settings';
	$settings    = get_option( $option_name, array() );
	if ( ! is_array( $settings ) || ! isset( $settings['secret'] ) ) {
		return '';
	}
	return trim( (string) $settings['secret'] );
}

/**
 * Canonical representation shared with the standalone MU guard.
 */
function agent_backup_recovery_state_message( $state ) {
	$canonical = (array) $state;
	unset( $canonical['hmac'] );
	ksort( $canonical, SORT_STRING );
	$encoded = json_encode( $canonical, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE );
	return is_string( $encoded ) ? $encoded : '';
}

function agent_backup_recovery_sign_state( $state, $secret ) {
	$message = agent_backup_recovery_state_message( $state );
	if ( '' === $message || '' === $secret ) {
		return array();
	}
	$state['hmac'] = hash_hmac( 'sha256', $message, $secret );
	return $state;
}

function agent_backup_recovery_version_is_safe( $version ) {
	$version = (string) $version;
	return '' !== $version
		&& $version === trim( $version )
		&& strlen( $version ) <= 64
		&& ! preg_match( '/[\x00-\x1F\x7F]/', $version );
}

/**
 * Match an already verified state against one exact guarded update contract.
 */
function agent_backup_recovery_state_matches_update( $state, $transaction_id, $plugin, $expected_from_version, $expected_target_version, $capability_version ) {
	return is_array( $state )
		&& AGENT_BACKUP_RECOVERY_CAPABILITY_VERSION === (int) $capability_version
		&& AGENT_BACKUP_RECOVERY_CAPABILITY_VERSION === (int) ( $state['capability_version'] ?? 0 )
		&& hash_equals( (string) ( $state['transaction_id'] ?? '' ), (string) $transaction_id )
		&& hash_equals( (string) ( $state['plugin'] ?? '' ), (string) $plugin )
		&& hash_equals( (string) ( $state['expected_from_version'] ?? '' ), (string) $expected_from_version )
		&& hash_equals( (string) ( $state['expected_target_version'] ?? '' ), (string) $expected_target_version );
}

function agent_backup_recovery_verify_state( $state, $kind, $secret ) {
	if ( ! is_array( $state ) || '' === $secret ) {
		return false;
	}
	if ( AGENT_BACKUP_RECOVERY_SCHEMA_VERSION !== (int) ( $state['schema'] ?? 0 ) ) {
		return false;
	}
	if ( $kind !== (string) ( $state['kind'] ?? '' ) ) {
		return false;
	}
	$provided = strtolower( (string) ( $state['hmac'] ?? '' ) );
	if ( ! preg_match( '/^[a-f0-9]{64}$/', $provided ) ) {
		return false;
	}
	$message = agent_backup_recovery_state_message( $state );
	if ( '' === $message ) {
		return false;
	}
	$expected = hash_hmac( 'sha256', $message, $secret );
	if ( ! hash_equals( $expected, $provided ) ) {
		return false;
	}
	if (
		! agent_backup_recovery_plugin_basename_is_safe( (string) ( $state['plugin'] ?? '' ) )
		|| ! agent_backup_recovery_transaction_id_is_safe( (string) ( $state['transaction_id'] ?? '' ) )
		|| AGENT_BACKUP_RECOVERY_CAPABILITY_VERSION !== (int) ( $state['capability_version'] ?? 0 )
		|| ! agent_backup_recovery_version_is_safe( (string) ( $state['expected_from_version'] ?? '' ) )
		|| ! agent_backup_recovery_version_is_safe( (string) ( $state['expected_target_version'] ?? '' ) )
	) {
		return false;
	}

	$issued_at = (int) ( $state['issued_at'] ?? 0 );
	if ( $issued_at <= 0 ) {
		return false;
	}
	if ( 'armed' === $kind ) {
		$expires_at = (int) ( $state['expires_at'] ?? 0 );
		return $expires_at >= $issued_at && ( $expires_at - $issued_at ) <= AGENT_BACKUP_RECOVERY_MAX_TTL;
	}
	if ( 'quarantine' === $kind ) {
		return (int) ( $state['quarantined_at'] ?? 0 ) >= $issued_at;
	}
	return false;
}

/**
 * Read one bounded JSON state file and verify its local HMAC.
 */
function agent_backup_recovery_read_state( $kind ) {
	$path = agent_backup_recovery_state_path( $kind );
	if ( '' === $path || ! file_exists( $path ) ) {
		return array(
			'status' => 'missing',
			'state'  => null,
			'error'  => '',
		);
	}

	$size = @filesize( $path );
	if ( false === $size || $size <= 0 || $size > AGENT_BACKUP_RECOVERY_MAX_STATE_BYTES ) {
		return array(
			'status' => 'invalid',
			'state'  => null,
			'error'  => 'State file size is invalid.',
		);
	}

	$raw = @file_get_contents( $path );
	if ( ! is_string( $raw ) || '' === $raw ) {
		return array(
			'status' => 'invalid',
			'state'  => null,
			'error'  => 'State file is not readable.',
		);
	}
	$state  = json_decode( $raw, true );
	$secret = agent_backup_recovery_hmac_secret();
	if ( ! agent_backup_recovery_verify_state( $state, $kind, $secret ) ) {
		return array(
			'status' => 'invalid',
			'state'  => null,
			'error'  => 'State signature or schema is invalid.',
		);
	}

	return array(
		'status' => 'valid',
		'state'  => $state,
		'error'  => '',
	);
}

function agent_backup_recovery_plugin_basename_is_safe( $plugin ) {
	$plugin = (string) $plugin;
	if ( '' === $plugin || $plugin !== trim( $plugin ) || false !== strpos( $plugin, "\0" ) ) {
		return false;
	}
	if ( false !== strpos( $plugin, '\\' ) || '/' === substr( $plugin, 0, 1 ) ) {
		return false;
	}
	if ( 0 !== validate_file( $plugin ) || '.php' !== strtolower( substr( $plugin, -4 ) ) ) {
		return false;
	}
	return ! preg_match( '/[\x00-\x1F\x7F]/', $plugin );
}

function agent_backup_recovery_transaction_id_is_safe( $transaction_id ) {
	return 1 === preg_match( '/^[A-Za-z0-9][A-Za-z0-9._:-]{15,127}$/', (string) $transaction_id );
}

/**
 * Ensure only the two fixed recovery directories can be created.
 */
function agent_backup_recovery_ensure_directory( $directory ) {
	$allowed = array(
		agent_backup_recovery_mu_directory(),
		agent_backup_recovery_state_directory(),
	);
	if ( ! in_array( $directory, $allowed, true ) ) {
		return new WP_Error( 'recovery_path_rejected', 'Recovery directory is not allowlisted.' );
	}
	if ( is_dir( $directory ) ) {
		return true;
	}
	if ( ! wp_mkdir_p( $directory ) || ! is_dir( $directory ) ) {
		return new WP_Error( 'recovery_directory_create_failed', 'The recovery directory could not be created.' );
	}
	@chmod( $directory, 0700 );
	return true;
}

/**
 * Atomically replace only one of the fixed guard/state files.
 */
function agent_backup_recovery_atomic_write( $path, $contents, $mode = 0600 ) {
	$allowed = array(
		agent_backup_recovery_guard_target_path(),
		agent_backup_recovery_state_path( 'armed' ),
		agent_backup_recovery_state_path( 'quarantine' ),
	);
	if ( ! in_array( $path, $allowed, true ) ) {
		return new WP_Error( 'recovery_path_rejected', 'Recovery file is not allowlisted.' );
	}

	try {
		$suffix = bin2hex( random_bytes( 8 ) );
	} catch ( Throwable $error ) {
		$suffix = str_replace( '-', '', wp_generate_uuid4() );
	}
	$temp_path = $path . '.' . $suffix . '.tmp';
	$written   = @file_put_contents( $temp_path, $contents, LOCK_EX );
	if ( ! is_int( $written ) || $written !== strlen( $contents ) ) {
		if ( file_exists( $temp_path ) ) {
			@unlink( $temp_path );
		}
		return new WP_Error( 'recovery_write_failed', 'Recovery file could not be written.' );
	}
	@chmod( $temp_path, $mode );
	if ( ! @rename( $temp_path, $path ) ) {
		@unlink( $temp_path );
		return new WP_Error( 'recovery_rename_failed', 'Recovery file could not be installed atomically.' );
	}
	clearstatcache( true, $path );
	return true;
}

function agent_backup_recovery_write_state( $kind, $state ) {
	$path      = agent_backup_recovery_state_path( $kind );
	$secret    = agent_backup_recovery_hmac_secret();
	$signed    = agent_backup_recovery_sign_state( $state, $secret );
	$directory = agent_backup_recovery_ensure_directory( agent_backup_recovery_state_directory() );
	if ( is_wp_error( $directory ) ) {
		return $directory;
	}
	if ( empty( $signed ) ) {
		return new WP_Error( 'recovery_secret_missing', 'The paired agent HMAC secret is unavailable.' );
	}
	$encoded = json_encode( $signed, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE );
	if ( ! is_string( $encoded ) || strlen( $encoded ) > AGENT_BACKUP_RECOVERY_MAX_STATE_BYTES ) {
		return new WP_Error( 'recovery_state_encode_failed', 'Recovery state could not be encoded safely.' );
	}
	$result = agent_backup_recovery_atomic_write( $path, $encoded, 0600 );
	if ( is_wp_error( $result ) ) {
		return $result;
	}
	$verified = agent_backup_recovery_read_state( $kind );
	if ( 'valid' !== $verified['status'] ) {
		return new WP_Error( 'recovery_state_verify_failed', 'Recovery state failed verification after writing.' );
	}
	return $verified['state'];
}

/**
 * Probe every required filesystem operation in one random, isolated directory.
 */
function agent_backup_recovery_filesystem_probe( $parent_directory ) {
	$result = array(
		'parent_exists'   => is_dir( $parent_directory ),
		'parent_writable' => is_dir( $parent_directory ) && is_writable( $parent_directory ),
		'create'          => false,
		'write'           => false,
		'read'            => false,
		'hash'            => false,
		'rename'          => false,
		'delete'          => false,
		'rmdir'           => false,
		'cleanup'         => false,
		'ok'              => false,
		'errors'          => array(),
	);
	if ( ! $result['parent_exists'] ) {
		$result['cleanup'] = true;
		$result['errors'][] = array( 'operation' => 'create', 'message' => 'Parent directory does not exist.' );
		return $result;
	}

	try {
		$suffix = bin2hex( random_bytes( 8 ) );
	} catch ( Throwable $error ) {
		$suffix = str_replace( '-', '', wp_generate_uuid4() );
	}
	$probe_directory = trailingslashit( $parent_directory ) . '.agent-backup-probe-' . $suffix;
	$source_path     = trailingslashit( $probe_directory ) . 'source.bin';
	$renamed_path    = trailingslashit( $probe_directory ) . 'renamed.bin';
	$payload         = 'agent-backup-readiness-' . $suffix;

	$result['create'] = @mkdir( $probe_directory, 0700 );
	if ( ! $result['create'] ) {
		$result['cleanup'] = ! is_dir( $probe_directory );
		$result['errors'][] = array( 'operation' => 'create', 'message' => 'Probe directory could not be created.' );
		return $result;
	}

	$written         = @file_put_contents( $source_path, $payload, LOCK_EX );
	$result['write'] = is_int( $written ) && $written === strlen( $payload );
	if ( ! $result['write'] ) {
		$result['errors'][] = array( 'operation' => 'write', 'message' => 'Probe file could not be written.' );
	}

	if ( $result['write'] ) {
		$read           = @file_get_contents( $source_path );
		$result['read'] = is_string( $read ) && hash_equals( $payload, $read );
		if ( ! $result['read'] ) {
			$result['errors'][] = array( 'operation' => 'read', 'message' => 'Probe file contents could not be read back.' );
		}
		$hash           = @hash_file( 'sha256', $source_path );
		$result['hash'] = is_string( $hash ) && hash_equals( hash( 'sha256', $payload ), $hash );
		if ( ! $result['hash'] ) {
			$result['errors'][] = array( 'operation' => 'hash', 'message' => 'Probe file hash did not match.' );
		}
		$result['rename'] = @rename( $source_path, $renamed_path );
		if ( ! $result['rename'] ) {
			$result['errors'][] = array( 'operation' => 'rename', 'message' => 'Probe file could not be renamed.' );
		}
	}

	if ( $result['rename'] ) {
		$result['delete'] = @unlink( $renamed_path );
		if ( ! $result['delete'] ) {
			$result['errors'][] = array( 'operation' => 'delete', 'message' => 'Renamed probe file could not be deleted.' );
		}
	}

	if ( file_exists( $source_path ) ) {
		@unlink( $source_path );
	}
	if ( file_exists( $renamed_path ) ) {
		@unlink( $renamed_path );
	}
	$result['rmdir']   = @rmdir( $probe_directory );
	$result['cleanup'] = ! file_exists( $source_path ) && ! file_exists( $renamed_path ) && ! is_dir( $probe_directory );
	if ( ! $result['rmdir'] ) {
		$result['errors'][] = array( 'operation' => 'rmdir', 'message' => 'Probe directory could not be removed.' );
	}
	if ( ! $result['cleanup'] ) {
		$result['errors'][] = array( 'operation' => 'cleanup', 'message' => 'Probe cleanup left an artifact behind.' );
	}

	$result['ok'] = $result['create'] && $result['write'] && $result['read'] && $result['hash']
		&& $result['rename'] && $result['delete'] && $result['rmdir'] && $result['cleanup'];
	return $result;
}

function agent_backup_recovery_skipped_probe( $reason ) {
	return array(
		'parent_exists'   => false,
		'parent_writable' => false,
		'create'          => false,
		'write'           => false,
		'read'            => false,
		'hash'            => false,
		'rename'          => false,
		'delete'          => false,
		'rmdir'           => false,
		'cleanup'         => true,
		'ok'              => false,
		'skipped'         => true,
		'errors'          => array( array( 'operation' => 'skipped', 'message' => (string) $reason ) ),
	);
}

function agent_backup_recovery_guard_info() {
	$source_path  = agent_backup_recovery_guard_source_path();
	$target_path  = agent_backup_recovery_guard_target_path();
	$source_hash  = is_file( $source_path ) ? @hash_file( 'sha256', $source_path ) : false;
	$target_hash  = is_file( $target_path ) ? @hash_file( 'sha256', $target_path ) : false;
	$source_hash  = is_string( $source_hash ) ? strtolower( $source_hash ) : null;
	$target_hash  = is_string( $target_hash ) ? strtolower( $target_hash ) : null;
	$current      = null !== $source_hash && null !== $target_hash && hash_equals( $source_hash, $target_hash );

	return array(
		'installed'       => is_file( $target_path ),
		'current'         => $current,
		'installable'     => false,
		'version'         => AGENT_BACKUP_RECOVERY_GUARD_ASSET_VERSION,
		'source_sha256'   => $source_hash,
		'installed_sha256'=> $target_hash,
	);
}

/**
 * Non-destructive capability probe. It touches only random files it creates itself.
 */
function agent_backup_route_recovery_readiness( WP_REST_Request $request ) {
	$disallow_file_mods = defined( 'DISALLOW_FILE_MODS' ) && DISALLOW_FILE_MODS;
	$filesystem_method  = defined( 'FS_METHOD' ) ? (string) FS_METHOD : '';
	$guard              = agent_backup_recovery_guard_info();
	$failures           = array();

	if ( $disallow_file_mods ) {
		$probes = array(
			'wp_content' => agent_backup_recovery_skipped_probe( 'WordPress file modifications are disabled.' ),
			'mu_plugins' => agent_backup_recovery_skipped_probe( 'WordPress file modifications are disabled.' ),
			'state_dir'  => agent_backup_recovery_skipped_probe( 'WordPress file modifications are disabled.' ),
		);
		$status = 'blocked';
	} else {
		require_once ABSPATH . 'wp-admin/includes/file.php';
		$filesystem_method = (string) get_filesystem_method( array(), WP_CONTENT_DIR );
		$content_probe     = agent_backup_recovery_filesystem_probe( WP_CONTENT_DIR );
		$mu_directory      = agent_backup_recovery_mu_directory();
		$state_directory   = agent_backup_recovery_state_directory();
		$mu_probe          = is_dir( $mu_directory )
			? agent_backup_recovery_filesystem_probe( $mu_directory )
			: array_merge( $content_probe, array( 'exists' => false, 'basis' => 'wp_content' ) );
		$state_probe       = is_dir( $state_directory )
			? agent_backup_recovery_filesystem_probe( $state_directory )
			: array_merge( $content_probe, array( 'exists' => false, 'basis' => 'wp_content' ) );
		$probes            = array(
			'wp_content' => $content_probe,
			'mu_plugins' => $mu_probe,
			'state_dir'  => $state_probe,
		);

		$guard['installable'] = null !== $guard['source_sha256'] && $content_probe['ok'] && $mu_probe['ok'] && $state_probe['ok'];
		$cleanup_failed       = ! $content_probe['cleanup'] || ! $mu_probe['cleanup'] || ! $state_probe['cleanup'];
		if ( $cleanup_failed ) {
			$status = 'cleanup_failed';
		} elseif ( 'direct' !== $filesystem_method || ! $content_probe['ok'] ) {
			$status = 'update_unavailable';
		} elseif ( $guard['current'] && $state_probe['ok'] ) {
			$status = 'ready';
		} elseif ( $guard['installable'] ) {
			$status = 'guard_install_required';
		} else {
			$status = 'manual_install_required';
		}
	}

	foreach ( $probes as $scope => $probe ) {
		foreach ( (array) ( $probe['errors'] ?? array() ) as $error ) {
			$failures[] = array(
				'scope'     => $scope,
				'operation' => (string) ( $error['operation'] ?? 'unknown' ),
				'message'   => (string) ( $error['message'] ?? 'Filesystem probe failed.' ),
			);
		}
	}
	if ( null === $guard['source_sha256'] ) {
		$failures[] = array(
			'scope'     => 'guard',
			'operation' => 'source',
			'message'   => 'Bundled guard asset is missing or unreadable.',
		);
	}

	$state_ready = ! $disallow_file_mods && ! empty( $probes['state_dir']['ok'] );
	return new WP_REST_Response(
		array(
			'ok'                 => true,
			'status'             => $status,
			'checked_at'         => gmdate( 'c' ),
			'capability_version' => AGENT_BACKUP_RECOVERY_CAPABILITY_VERSION,
			'policy'             => array(
				'disallow_file_mods' => $disallow_file_mods,
				'filesystem_method'  => $filesystem_method,
			),
			'guard'        => $guard,
			'probes'       => $probes,
			'capabilities' => array(
				'unattended_update'      => ! $disallow_file_mods && 'direct' === $filesystem_method && ! empty( $probes['wp_content']['ok'] ),
				'runtime_quarantine'     => $guard['current'] && $state_ready,
				'automatic_guard_install'=> ! $disallow_file_mods && ! empty( $guard['installable'] ),
			),
			'failures'     => $failures,
		),
		200
	);
}

/**
 * Install only the bundled, checksum-verifiable guard at its fixed MU-plugin path.
 */
function agent_backup_route_recovery_guard_install( WP_REST_Request $request ) {
	if ( defined( 'DISALLOW_FILE_MODS' ) && DISALLOW_FILE_MODS ) {
		return agent_backup_recovery_error_response( 'file_modifications_disabled', 'WordPress file modifications are disabled.', 403 );
	}
	$source_path = agent_backup_recovery_guard_source_path();
	$contents    = is_file( $source_path ) ? @file_get_contents( $source_path ) : false;
	if ( ! is_string( $contents ) || '' === $contents ) {
		return agent_backup_recovery_error_response( 'guard_asset_missing', 'Bundled recovery guard is missing or unreadable.', 500 );
	}

	foreach ( array( agent_backup_recovery_mu_directory(), agent_backup_recovery_state_directory() ) as $directory ) {
		$created = agent_backup_recovery_ensure_directory( $directory );
		if ( is_wp_error( $created ) ) {
			return agent_backup_recovery_error_response( $created->get_error_code(), $created->get_error_message(), 500 );
		}
	}

	$written = agent_backup_recovery_atomic_write( agent_backup_recovery_guard_target_path(), $contents, 0644 );
	if ( is_wp_error( $written ) ) {
		return agent_backup_recovery_error_response( $written->get_error_code(), $written->get_error_message(), 500 );
	}
	$guard = agent_backup_recovery_guard_info();
	if ( ! $guard['current'] ) {
		return agent_backup_recovery_error_response( 'guard_checksum_mismatch', 'Installed recovery guard checksum does not match the bundled asset.', 500 );
	}
	$guard['installable'] = true;

	return new WP_REST_Response(
		array(
			'ok'     => true,
			'status' => 'installed',
			'guard'  => $guard,
		),
		200
	);
}

/**
 * Arm exactly one installed and active plugin for one short-lived transaction.
 */
function agent_backup_route_recovery_arm( WP_REST_Request $request ) {
	if ( defined( 'DISALLOW_FILE_MODS' ) && DISALLOW_FILE_MODS ) {
		return agent_backup_recovery_error_response( 'file_modifications_disabled', 'WordPress file modifications are disabled.', 403 );
	}
	$guard = agent_backup_recovery_guard_info();
	if ( ! $guard['current'] ) {
		return agent_backup_recovery_error_response( 'guard_not_current', 'The current recovery guard must be installed before arming.', 409 );
	}

	$capability_version      = (int) $request->get_param( 'capability_version' );
	$transaction_id         = (string) $request->get_param( 'transaction_id' );
	$plugin                 = (string) $request->get_param( 'plugin' );
	$expected_from_version   = (string) $request->get_param( 'expected_from_version' );
	$expected_target_version = (string) $request->get_param( 'expected_target_version' );
	if ( AGENT_BACKUP_RECOVERY_CAPABILITY_VERSION !== $capability_version ) {
		return agent_backup_recovery_error_response( 'unsupported_capability_version', 'Recovery capability version is not supported.', 409 );
	}
	if ( ! agent_backup_recovery_transaction_id_is_safe( $transaction_id ) ) {
		return agent_backup_recovery_error_response( 'invalid_transaction_id', 'Transaction identifier is invalid.', 400 );
	}
	if ( ! agent_backup_recovery_plugin_basename_is_safe( $plugin ) ) {
		return agent_backup_recovery_error_response( 'invalid_plugin', 'Plugin must be an exact, safe plugin basename.', 400 );
	}
	if ( defined( 'AGENT_BACKUP_BASENAME' ) && hash_equals( AGENT_BACKUP_BASENAME, $plugin ) ) {
		return agent_backup_recovery_error_response( 'agent_plugin_not_allowed', 'The Agent Backup plugin cannot quarantine itself.', 400 );
	}
	if ( ! agent_backup_recovery_version_is_safe( $expected_from_version ) ) {
		return agent_backup_recovery_error_response( 'invalid_expected_from_version', 'Expected installed version is invalid.', 400 );
	}
	if ( ! agent_backup_recovery_version_is_safe( $expected_target_version ) ) {
		return agent_backup_recovery_error_response( 'invalid_expected_target_version', 'Expected target version is invalid.', 400 );
	}

	require_once ABSPATH . 'wp-admin/includes/plugin.php';
	$plugins = get_plugins();
	if ( ! array_key_exists( $plugin, $plugins ) ) {
		return agent_backup_recovery_error_response( 'unknown_plugin', 'The exact plugin basename is not installed.', 404 );
	}
	if ( ! is_plugin_active( $plugin ) && ! is_plugin_active_for_network( $plugin ) ) {
		return agent_backup_recovery_error_response( 'plugin_not_active', 'Only an active plugin can be armed.', 409 );
	}
	$installed_version = isset( $plugins[ $plugin ]['Version'] ) ? (string) $plugins[ $plugin ]['Version'] : '';
	if ( ! hash_equals( $expected_from_version, $installed_version ) ) {
		return agent_backup_recovery_error_response(
			'installed_version_drift',
			'Installed plugin version no longer matches the requested recovery contract.',
			409,
			array(
				'expected_from_version' => $expected_from_version,
				'installed_version'     => $installed_version,
			)
		);
	}

	$quarantine = agent_backup_recovery_read_state( 'quarantine' );
	if ( 'invalid' === $quarantine['status'] ) {
		return agent_backup_recovery_error_response( 'quarantine_state_invalid', $quarantine['error'], 409 );
	}
	if ( 'valid' === $quarantine['status'] ) {
		return agent_backup_recovery_error_response(
			'plugin_already_quarantined',
			'A quarantined plugin must be reviewed and cleared before another transaction can be armed.',
			409,
			array(
				'transaction_id' => $quarantine['state']['transaction_id'],
				'plugin'         => $quarantine['state']['plugin'],
			)
		);
	}

	$armed = agent_backup_recovery_read_state( 'armed' );
	if ( 'invalid' === $armed['status'] ) {
		return agent_backup_recovery_error_response( 'armed_state_invalid', $armed['error'], 409 );
	}
	if ( 'valid' === $armed['status'] && (int) $armed['state']['expires_at'] >= time() ) {
		if ( agent_backup_recovery_state_matches_update( $armed['state'], $transaction_id, $plugin, $expected_from_version, $expected_target_version, $capability_version ) ) {
			return new WP_REST_Response(
				array(
					'ok'                      => true,
					'status'                  => 'armed',
					'capability_version'      => $capability_version,
					'transaction_id'          => $transaction_id,
					'plugin'                  => $plugin,
					'expected_from_version'   => $expected_from_version,
					'expected_target_version' => $expected_target_version,
					'issued_at'               => (int) $armed['state']['issued_at'],
					'expires_at'              => (int) $armed['state']['expires_at'],
				),
				200
			);
		}
		return agent_backup_recovery_error_response( 'recovery_transaction_active', 'Another recovery transaction is already armed.', 409 );
	}

	$ttl = (int) $request->get_param( 'ttl_seconds' );
	if ( $ttl <= 0 ) {
		$ttl = AGENT_BACKUP_RECOVERY_DEFAULT_TTL;
	}
	$ttl       = min( AGENT_BACKUP_RECOVERY_MAX_TTL, max( 60, $ttl ) );
	$issued_at = time();
	$state     = array(
		'schema'                  => AGENT_BACKUP_RECOVERY_SCHEMA_VERSION,
		'kind'                    => 'armed',
		'capability_version'      => $capability_version,
		'transaction_id'          => $transaction_id,
		'plugin'                  => $plugin,
		'expected_from_version'   => $expected_from_version,
		'expected_target_version' => $expected_target_version,
		'issued_at'               => $issued_at,
		'expires_at'              => $issued_at + $ttl,
	);
	$stored = agent_backup_recovery_write_state( 'armed', $state );
	if ( is_wp_error( $stored ) ) {
		return agent_backup_recovery_error_response( $stored->get_error_code(), $stored->get_error_message(), 500 );
	}

	return new WP_REST_Response(
		array(
			'ok'                      => true,
			'status'                  => 'armed',
			'capability_version'      => $capability_version,
			'transaction_id'          => $transaction_id,
			'plugin'                  => $plugin,
			'expected_from_version'   => $expected_from_version,
			'expected_target_version' => $expected_target_version,
			'issued_at'               => (int) $stored['issued_at'],
			'expires_at'              => (int) $stored['expires_at'],
		),
		200
	);
}

/**
 * Build a read-only status payload for both the REST endpoint and strict postchecks.
 */
function agent_backup_recovery_status_data( $requested_transaction = '' ) {
	$guard         = agent_backup_recovery_guard_info();
	$guard_payload = array(
		'installed' => $guard['installed'],
		'current'   => $guard['current'],
		'version'   => $guard['version'],
	);
	$quarantine = agent_backup_recovery_read_state( 'quarantine' );
	$armed      = agent_backup_recovery_read_state( 'armed' );

	if ( 'invalid' === $quarantine['status'] || 'invalid' === $armed['status'] ) {
		return array(
			'ok'                      => true,
			'status'                  => 'invalid',
			'capability_version'      => AGENT_BACKUP_RECOVERY_CAPABILITY_VERSION,
			'transaction_id'          => null,
			'plugin'                  => null,
			'expected_from_version'   => null,
			'expected_target_version' => null,
			'installed_version'       => null,
			'runtime_active'          => null,
			'runtime_site_active'     => null,
			'runtime_network_active'  => null,
			'issued_at'               => null,
			'expires_at'              => null,
			'quarantined_at'          => null,
			'error_type'              => null,
			'guard'                   => $guard_payload,
		);
	}

	$state  = null;
	$status = 'none';
	if ( 'valid' === $quarantine['status'] ) {
		$state  = $quarantine['state'];
		$status = 'quarantined';
	} elseif ( 'valid' === $armed['status'] ) {
		$state  = $armed['state'];
		$status = (int) $state['expires_at'] >= time() ? 'armed' : 'expired';
	}
	if ( null !== $state && '' !== $requested_transaction && ! hash_equals( (string) $state['transaction_id'], $requested_transaction ) ) {
		$status = 'mismatch';
	}

	$installed_version      = null;
	$runtime_site_active    = null;
	$runtime_network_active = null;
	if ( null !== $state ) {
		require_once ABSPATH . 'wp-admin/includes/plugin.php';
		$plugin                  = (string) $state['plugin'];
		$plugins                 = get_plugins();
		$runtime_plugins         = get_option( 'active_plugins', array() );
		$installed_version       = isset( $plugins[ $plugin ]['Version'] ) ? (string) $plugins[ $plugin ]['Version'] : '';
		$runtime_site_active     = is_array( $runtime_plugins ) && in_array( $plugin, $runtime_plugins, true );
		$runtime_network_active  = is_plugin_active_for_network( $plugin );
	}

	return array(
		'ok'                      => true,
		'status'                  => $status,
		'capability_version'      => AGENT_BACKUP_RECOVERY_CAPABILITY_VERSION,
		'transaction_id'          => null !== $state ? (string) $state['transaction_id'] : null,
		'plugin'                  => null !== $state ? (string) $state['plugin'] : null,
		'expected_from_version'   => null !== $state ? (string) $state['expected_from_version'] : null,
		'expected_target_version' => null !== $state ? (string) $state['expected_target_version'] : null,
		'installed_version'       => $installed_version,
		'runtime_active'          => null !== $state ? ( $runtime_site_active || $runtime_network_active ) : null,
		'runtime_site_active'     => $runtime_site_active,
		'runtime_network_active'  => $runtime_network_active,
		'issued_at'               => null !== $state ? (int) ( $state['issued_at'] ?? 0 ) : null,
		'expires_at'              => null !== $state && isset( $state['expires_at'] ) ? (int) $state['expires_at'] : null,
		'quarantined_at'          => null !== $state && isset( $state['quarantined_at'] ) ? (int) $state['quarantined_at'] : null,
		'error_type'              => null !== $state && isset( $state['error_type'] ) ? (int) $state['error_type'] : null,
		'guard'                   => $guard_payload,
	);
}

function agent_backup_route_recovery_status( WP_REST_Request $request ) {
	$requested_transaction = (string) $request->get_param( 'transaction_id' );
	if ( '' !== $requested_transaction && ! agent_backup_recovery_transaction_id_is_safe( $requested_transaction ) ) {
		return agent_backup_recovery_error_response( 'invalid_transaction_id', 'Transaction identifier is invalid.', 400 );
	}
	return new WP_REST_Response( agent_backup_recovery_status_data( $requested_transaction ), 200 );
}

/**
 * Clear only state belonging to the exact transaction. This neither activates nor
 * deactivates a plugin and deliberately leaves all WordPress options unchanged.
 */
function agent_backup_route_recovery_clear( WP_REST_Request $request ) {
	$transaction_id = trim( (string) $request->get_param( 'transaction_id' ) );
	if ( ! agent_backup_recovery_transaction_id_is_safe( $transaction_id ) ) {
		return agent_backup_recovery_error_response( 'invalid_transaction_id', 'Transaction identifier is invalid.', 400 );
	}

	$armed      = agent_backup_recovery_read_state( 'armed' );
	$quarantine = agent_backup_recovery_read_state( 'quarantine' );
	foreach ( array( $armed, $quarantine ) as $record ) {
		if ( 'invalid' === $record['status'] ) {
			return agent_backup_recovery_error_response( 'recovery_state_invalid', $record['error'], 409 );
		}
		if ( 'valid' === $record['status'] && ! hash_equals( (string) $record['state']['transaction_id'], $transaction_id ) ) {
			return agent_backup_recovery_error_response( 'transaction_mismatch', 'Recovery state belongs to a different transaction.', 409 );
		}
	}

	$plugin  = null;
	$cleared = false;
	// Remove the armed marker first. If quarantine removal fails, the site remains safely quarantined.
	foreach ( array( 'armed' => $armed, 'quarantine' => $quarantine ) as $kind => $record ) {
		if ( 'valid' !== $record['status'] ) {
			continue;
		}
		$plugin = (string) $record['state']['plugin'];
		$path   = agent_backup_recovery_state_path( $kind );
		if ( ! @unlink( $path ) ) {
			return agent_backup_recovery_error_response( 'recovery_state_clear_failed', 'Recovery state could not be cleared.', 500 );
		}
		$cleared = true;
	}

	return new WP_REST_Response(
		array(
			'ok'             => true,
			'status'         => $cleared ? 'cleared' : 'none',
			'cleared'        => $cleared,
			'transaction_id' => $transaction_id,
			'plugin'         => $plugin,
		),
		200
	);
}
