<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

function agent_backup_admin_menu() {
	add_options_page(
		__( 'Agent Backup', 'agent-backup' ),
		__( 'Agent Backup', 'agent-backup' ),
		'manage_options',
		'agent-backup',
		'agent_backup_render_settings_page'
	);
}
add_action( 'admin_menu', 'agent_backup_admin_menu' );

/**
 * Redirect directly to the plugin settings page after activation.
 */
function agent_backup_handle_activation_redirect() {
	if ( ! is_admin() || ! current_user_can( 'manage_options' ) ) {
		return;
	}

	if ( ! get_option( AGENT_BACKUP_ACTIVATION_REDIRECT_OPTION ) ) {
		return;
	}

	delete_option( AGENT_BACKUP_ACTIVATION_REDIRECT_OPTION );

	if ( wp_doing_ajax() || is_network_admin() || ! empty( $_GET['activate-multi'] ) ) {
		return;
	}

	wp_safe_redirect( admin_url( 'options-general.php?page=agent-backup' ) );
	exit;
}
add_action( 'admin_init', 'agent_backup_handle_activation_redirect' );

/**
 * Settings page renderer.
 */
function agent_backup_render_settings_page() {
	if ( ! current_user_can( 'manage_options' ) ) {
		return;
	}

	$settings = agent_backup_get_settings();
	$pairing  = agent_backup_get_pairing_state();
	$server_now_utc = gmdate( 'Y-m-d H:i:s \\U\\T\\C' );
	$server_now_wp  = wp_date( 'Y-m-d H:i:s T' );
	$timezone_name  = wp_timezone_string();
	if ( '' === $timezone_name ) {
		$timezone_name = 'UTC';
	}

	if ( isset( $_POST['agent_backup_settings_nonce'] ) && wp_verify_nonce( sanitize_key( $_POST['agent_backup_settings_nonce'] ), 'agent_backup_save_settings' ) ) {
		$settings['allow_ips'] = array_filter(
			array_map( 'trim', explode( "\n", wp_unslash( $_POST['allow_ips'] ?? '' ) ) )
		);
		$settings['excludes'] = array_filter(
			array_map( 'trim', explode( "\n", wp_unslash( $_POST['excludes'] ?? '' ) ) )
		);
		$settings['trust_proxy']   = ! empty( $_POST['trust_proxy'] );
		$settings['debug_db_log']  = ! empty( $_POST['debug_db_log'] );
		$settings['update_metadata_url'] = esc_url_raw( trim( wp_unslash( $_POST['update_metadata_url'] ?? '' ) ) );
		$settings['log_retention'] = max( 1, absint( $_POST['log_retention'] ?? $settings['log_retention'] ) );
		$settings['timestamp_window'] = max( 60, absint( $_POST['timestamp_window'] ?? $settings['timestamp_window'] ) );
		$settings['default_limit'] = max( 1, absint( $_POST['default_limit'] ?? $settings['default_limit'] ) );
		$settings['max_limit']     = max( $settings['default_limit'], absint( $_POST['max_limit'] ?? $settings['max_limit'] ) );
		$max_file_mb               = max( 1, absint( $_POST['max_file_length_mb'] ?? ceil( $settings['max_file_length'] / 1048576 ) ) );
		$settings['max_file_length'] = $max_file_mb * 1048576; // store in bytes

		if ( isset( $_POST['rotate_token'] ) ) {
			$settings['token'] = wp_generate_password( 64, false, false );
		}
		if ( isset( $_POST['rotate_secret'] ) ) {
			$settings['secret'] = wp_generate_password( 64, true, true );
		}
		if ( isset( $_POST['clear_logs'] ) ) {
			update_option( AGENT_BACKUP_LOG_OPTION, array(), false );
		}

		$settings = agent_backup_save_settings( $settings );
		if ( isset( $_POST['complete_pairing'] ) ) {
			agent_backup_attempt_pairing( 'manual' );
			$pairing = agent_backup_get_pairing_state();
			$settings = agent_backup_get_settings();
		}
		add_settings_error( 'agent_backup', 'saved', __( 'Settings saved', 'agent-backup' ), 'updated' );
	}

	settings_errors( 'agent_backup' );

	$logs = get_option( AGENT_BACKUP_LOG_OPTION, array() );
	$resolved_update_metadata_url = agent_backup_get_update_metadata_url();
	?>
	<div class="wrap">
		<h1><?php esc_html_e( 'Agent Backup', 'agent-backup' ); ?></h1>
		<form method="post">
			<?php wp_nonce_field( 'agent_backup_save_settings', 'agent_backup_settings_nonce' ); ?>
			<table class="form-table" role="presentation">
				<tr>
					<th scope="row"><?php esc_html_e( 'Pairing status', 'agent-backup' ); ?></th>
					<td>
						<p><strong><?php echo esc_html( ucfirst( $pairing['status'] ) ); ?></strong></p>
						<?php if ( ! empty( $pairing['last_message'] ) ) : ?>
							<p class="description"><?php echo esc_html( $pairing['last_message'] ); ?></p>
						<?php endif; ?>
						<?php if ( ! empty( $pairing['paired_at'] ) ) : ?>
							<p class="description"><?php echo esc_html( sprintf( __( 'Paired at %s', 'agent-backup' ), $pairing['paired_at'] ) ); ?></p>
						<?php endif; ?>
						<?php if ( agent_backup_read_pairing_manifest() ) : ?>
							<p><button class="button button-secondary" name="complete_pairing" value="1"><?php esc_html_e( 'Connect to Orchestrator', 'agent-backup' ); ?></button></p>
						<?php else : ?>
							<p class="description"><?php esc_html_e( 'This installation does not include a site-specific pairing manifest.', 'agent-backup' ); ?></p>
						<?php endif; ?>
					</td>
				</tr>
				<tr>
					<th scope="row"><?php esc_html_e( 'Current time', 'agent-backup' ); ?></th>
					<td>
						<p><strong><?php esc_html_e( 'WordPress/site time:', 'agent-backup' ); ?></strong> <?php echo esc_html( $server_now_wp ); ?></p>
						<p><strong><?php esc_html_e( 'UTC time:', 'agent-backup' ); ?></strong> <?php echo esc_html( $server_now_utc ); ?></p>
						<p class="description"><?php echo esc_html( sprintf( __( 'Detected site timezone: %s', 'agent-backup' ), $timezone_name ) ); ?></p>
					</td>
				</tr>
				<tr>
					<th scope="row"><?php esc_html_e( 'Native update source', 'agent-backup' ); ?></th>
					<td>
						<input type="url" name="update_metadata_url" class="large-text code" value="<?php echo esc_attr( $settings['update_metadata_url'] ); ?>" placeholder="https://orchestrator.example.internal/agent-plugin/update" />
						<p class="description"><?php esc_html_e( 'Optional override. Leave empty to use the public GitHub-hosted update metadata. Use this only when you intentionally want a different feed.', 'agent-backup' ); ?></p>
						<?php if ( '' !== $resolved_update_metadata_url ) : ?>
							<p class="description"><strong><?php esc_html_e( 'Resolved feed:', 'agent-backup' ); ?></strong> <?php echo esc_html( $resolved_update_metadata_url ); ?></p>
						<?php else : ?>
							<p class="description"><?php esc_html_e( 'No update feed is currently resolved. Enter a direct metadata URL.', 'agent-backup' ); ?></p>
						<?php endif; ?>
					</td>
				</tr>
				<tr>
					<th scope="row"><?php esc_html_e( 'Agent Token', 'agent-backup' ); ?></th>
					<td>
						<input type="text" readonly class="regular-text" value="<?php echo esc_attr( $settings['token'] ); ?>" />
						<p><button class="button" name="rotate_token" value="1"><?php esc_html_e( 'Rotate Token', 'agent-backup' ); ?></button></p>
					</td>
				</tr>
				<tr>
					<th scope="row"><?php esc_html_e( 'HMAC Secret', 'agent-backup' ); ?></th>
					<td>
						<input type="text" readonly class="regular-text" value="<?php echo esc_attr( $settings['secret'] ); ?>" />
						<p><button class="button" name="rotate_secret" value="1"><?php esc_html_e( 'Rotate Secret', 'agent-backup' ); ?></button></p>
					</td>
				</tr>
				<tr>
					<th scope="row"><?php esc_html_e( 'Allowlisted IPs', 'agent-backup' ); ?></th>
					<td>
						<textarea name="allow_ips" class="large-text code" rows="5"><?php echo esc_textarea( implode( "\n", (array) $settings['allow_ips'] ) ); ?></textarea>
						<p class="description"><?php esc_html_e( 'One IP per line.', 'agent-backup' ); ?></p>
					</td>
				</tr>
				<tr>
					<th scope="row"><?php esc_html_e( 'Trust Proxy (X-Forwarded-For)', 'agent-backup' ); ?></th>
					<td>
						<label><input type="checkbox" name="trust_proxy" value="1" <?php checked( $settings['trust_proxy'] ); ?> /> <?php esc_html_e( 'Enable if running behind trusted proxy/CDN.', 'agent-backup' ); ?></label>
					</td>
				</tr>
				<tr>
					<th scope="row"><?php esc_html_e( 'Exclude prefixes', 'agent-backup' ); ?></th>
					<td>
						<textarea name="excludes" class="large-text code" rows="5"><?php echo esc_textarea( implode( "\n", (array) $settings['excludes'] ) ); ?></textarea>
						<p class="description"><?php esc_html_e( 'Paths starting with these prefixes will be excluded from /files.', 'agent-backup' ); ?></p>
					</td>
				</tr>
				<tr>
					<th scope="row"><?php esc_html_e( '/files default limit', 'agent-backup' ); ?></th>
					<td>
						<input type="number" name="default_limit" value="<?php echo esc_attr( $settings['default_limit'] ); ?>" min="1" />
						<p class="description"><?php esc_html_e( 'Items per page; lower if your host times out. Max is capped below.', 'agent-backup' ); ?></p>
					</td>
				</tr>
				<tr>
					<th scope="row"><?php esc_html_e( '/files max limit', 'agent-backup' ); ?></th>
					<td>
						<input type="number" name="max_limit" value="<?php echo esc_attr( $settings['max_limit'] ); ?>" min="<?php echo esc_attr( $settings['default_limit'] ); ?>" />
						<p class="description"><?php esc_html_e( 'Upper bound accepted by /files.', 'agent-backup' ); ?></p>
					</td>
				</tr>
				<tr>
					<th scope="row"><?php esc_html_e( '/file max chunk (MB)', 'agent-backup' ); ?></th>
					<td>
						<input type="number" name="max_file_length_mb" value="<?php echo esc_attr( ceil( $settings['max_file_length'] / 1048576 ) ); ?>" min="1" />
						<p class="description"><?php esc_html_e( 'Caps requested length per /file call.', 'agent-backup' ); ?></p>
					</td>
				</tr>
				<tr>
					<th scope="row"><?php esc_html_e( 'Debug DB Logging', 'agent-backup' ); ?></th>
					<td>
						<label><input type="checkbox" name="debug_db_log" value="1" <?php checked( $settings['debug_db_log'] ); ?> /> <?php esc_html_e( 'Write /db debug messages to PHP error log (no secrets).', 'agent-backup' ); ?></label>
					</td>
				</tr>
				<tr>
					<th scope="row"><?php esc_html_e( 'Log retention (days)', 'agent-backup' ); ?></th>
					<td>
						<input type="number" name="log_retention" value="<?php echo esc_attr( $settings['log_retention'] ); ?>" min="1" />
					</td>
				</tr>
				<tr>
					<th scope="row"><?php esc_html_e( 'Timestamp window (seconds)', 'agent-backup' ); ?></th>
					<td>
						<input type="number" name="timestamp_window" value="<?php echo esc_attr( $settings['timestamp_window'] ); ?>" min="60" step="60" />
						<p class="description"><?php esc_html_e( 'Allowed clock drift for signed requests. Increase this only if the orchestrator and webserver clocks cannot be kept closely in sync.', 'agent-backup' ); ?></p>
					</td>
				</tr>
			</table>
			<?php submit_button(); ?>
			<button class="button" name="clear_logs" value="1"><?php esc_html_e( 'Clear Logs', 'agent-backup' ); ?></button>
		</form>

		<h2><?php esc_html_e( 'Logs', 'agent-backup' ); ?></h2>
		<table class="widefat striped">
			<thead>
				<tr>
					<th><?php esc_html_e( 'Timestamp', 'agent-backup' ); ?></th>
					<th><?php esc_html_e( 'Message', 'agent-backup' ); ?></th>
				</tr>
			</thead>
			<tbody>
			<?php if ( empty( $logs ) ) : ?>
				<tr><td colspan="2"><?php esc_html_e( 'No logs yet.', 'agent-backup' ); ?></td></tr>
			<?php else : ?>
				<?php foreach ( array_reverse( $logs ) as $entry ) : ?>
					<tr>
						<td><?php echo esc_html( date_i18n( 'Y-m-d H:i:s', $entry['ts'] ) ); ?></td>
						<td><?php echo esc_html( $entry['msg'] ); ?></td>
					</tr>
				<?php endforeach; ?>
			<?php endif; ?>
			</tbody>
		</table>
	</div>
	<?php
}
